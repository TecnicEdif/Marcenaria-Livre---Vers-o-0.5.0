# Materiais e texturas

O catálogo atual usa cores e veios aproximados. As dez novas opções de vidro também são aproximações visuais. Elas não equivalem a arquivos de textura oficiais nem a amostras de cor certificadas.

O editor de materiais aceita uma imagem PNG local. Escolha o material e use **Importar PNG**. A renderização reduz a imagem para até 512 × 512 pixels; o sentido do veio também orienta a amostra. Leve as imagens junto com o projeto quando transferi-lo. Alterações externas na mesma imagem podem exigir reiniciar o aplicativo para limpar o cache.

## Fontes oficiais consultadas

- [Downloads Arauco](https://arauco.com.br/downloads/): catálogos, chapas e biblioteca de materiais.
- [Downloads Berneck](https://berneck.com.br/bnk-channel/downloads): pacote de padrões BP para projetos.

A disponibilidade para download não foi tratada como autorização de redistribuição dentro deste software. Não há 200 texturas oficiais incorporadas nesta entrega. A integração completa dos catálogos Arauco, Berneck, Duratex, Eucatex, Guararapes, Sudati, Fibraplac e Greenplac permanece pendente de arquivos adequados e condições de uso verificadas.
