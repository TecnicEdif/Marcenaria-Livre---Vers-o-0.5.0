# Public user guides: PT, EN, ES.
TITLE=['Manual do usuário', 'User guide', 'Manual del usuario']
SUBTITLE=['Do primeiro ambiente à lista de fabricação', 'From your first room to the manufacturing list', 'Del primer ambiente a la lista de fabricación']
SECTIONS=[(['1. Comece por aqui', '1. Start here', '1. Empiece aquí'],
  None,
  [['O Marcenaria Livre 0.5.0 é uma ferramenta para projetar ambientes e móveis, gerar listas de peças, orçamento e pranchas. As medidas '
    'do projeto são em milímetros. Esta edição é uma versão em desenvolvimento: confira medidas, ferragens e encaixes antes de fabricar.',
    'Marcenaria Livre 0.5.0 is a tool for designing rooms and furniture and producing parts lists, estimates and drawing sheets. Project '
    'dimensions are in millimetres. This is a development release: check dimensions, hardware and joints before manufacturing.',
    'Marcenaria Livre 0.5.0 permite diseñar ambientes y muebles y generar listas de piezas, presupuestos y láminas. Las medidas del '
    'proyecto están en milímetros. Esta es una versión en desarrollo: revise medidas, herrajes y ensambles antes de fabricar.'],
   ['Linux: escolha um pacote compatível na pasta dist. No AppImage, abra Propriedades → Permissões e permita executar como programa. O '
    'pacote .deb é instalado pelo gerenciador de pacotes; o .flatpak requer Flatpak e o runtime Freedesktop 25.08. Os binários desta '
    'entrega usam glibc 2.39 ou superior.',
    'Linux: choose a compatible package in dist. For the AppImage, open Properties → Permissions and allow execution as a program. Install '
    'the .deb with your package manager. The .flatpak requires Flatpak and the Freedesktop 25.08 runtime. These binaries require glibc '
    '2.39 or later.',
    'Linux: elija un paquete compatible en dist. Para AppImage, abra Propiedades → Permisos y permita ejecutarlo como programa. Instale el '
    '.deb con el gestor de paquetes. El .flatpak requiere Flatpak y el runtime Freedesktop 25.08. Estos binarios requieren glibc 2.39 o '
    'superior.'],
   ['Abra um projeto .mar existente ou use Arquivo → Novo ambiente. Salve uma cópia com um nome novo antes de experimentar mudanças '
    'grandes. O arquivo .mar guarda o projeto editável; PDF, CSV, PNG e IFC são saídas para outros usos.',
    'Open an existing .mar project or use File → New room. Save a copy under a new name before trying major changes. The .mar file stores '
    'the editable project; PDF, CSV, PNG and IFC are outputs for other purposes.',
    'Abra un proyecto .mar existente o use Archivo → Nuevo ambiente. Guarde una copia con otro nombre antes de realizar cambios '
    'importantes. El archivo .mar conserva el proyecto editable; PDF, CSV, PNG e IFC son salidas para otros usos.'],
   ['Fluxo sugerido: ambiente → módulos → método construtivo → materiais → revisão das peças → orçamento → pranchas → exportação. Faça '
    'salvamentos durante cada etapa.',
    'Suggested workflow: room → modules → construction method → materials → parts review → estimate → sheets → export. Save your work '
    'throughout each stage.',
    'Flujo sugerido: ambiente → módulos → método constructivo → materiales → revisión de piezas → presupuesto → láminas → exportación. '
    'Guarde el trabajo durante cada etapa.']]),
 (['2. Conheça a interface e navegue', '2. Interface and navigation', '2. Interfaz y navegación'],
  'scene',
  [['As duas faixas superiores reúnem arquivos, seleção, movimento, vistas, paredes e ferramentas de acabamento. A biblioteca fica à '
    'esquerda. Ferramentas, Seleção e Ambiente ficam à direita. Os painéis laterais podem ser redimensionados e sua exibição pode ser '
    'alterada nas preferências.',
    'The two top rows contain file, selection, movement, view, wall and finishing tools. The library is on the left. Tools, Selection and '
    'Room are on the right. Side panels can be resized and their visibility changed in Preferences.',
    'Las dos filas superiores contienen archivos, selección, movimiento, vistas, paredes y herramientas de acabado. La biblioteca está a '
    'la izquierda. Herramientas, Selección y Ambiente están a la derecha. Puede redimensionar los paneles laterales y cambiar su '
    'visibilidad en Preferencias.'],
   ['No 3D: gire a roda para aproximar ou afastar; arraste com o botão do meio para orbitar; use Shift + botão do meio ou o botão direito '
    'para deslocar a vista. Clique com o esquerdo para selecionar. Arraste um módulo para movê-lo. Use Enquadrar seleção para localizar um '
    'móvel.',
    'In 3D: scroll to zoom, drag the middle mouse button to orbit, and use Shift + middle button or the right button to pan. Left-click to '
    'select. Drag a module to move it. Use Frame selection to locate furniture.',
    'En 3D: gire la rueda para acercar o alejar, arrastre el botón central para orbitar y use Mayús + botón central o el botón derecho '
    'para desplazar la vista. Haga clic izquierdo para seleccionar. Arrastre un módulo para moverlo. Use Encuadrar selección para '
    'localizar un mueble.'],
   ['Planta, Ortogonal e o menu Visualizar permitem mudar de vista. Na cena, escolha Texturas, Cores, Sem textura ou Wireframe. O contorno '
    'preto ajuda a distinguir as peças. A seleção recebe uma indicação verde.',
    'Plan, Orthographic and the View menu change the view. In the scene, choose Textures, Colors, Untextured or Wireframe. Black edges '
    'distinguish parts. Selection has a green indicator.',
    'Planta, Ortogonal y el menú Ver permiten cambiar la vista. En la escena, elija Texturas, Colores, Sin textura o Alámbrico. Los '
    'contornos negros distinguen las piezas. La selección tiene un indicador verde.']]),
 (['3. Construa o ambiente', '3. Build the room', '3. Construya el ambiente'],
  'plan',
  [['Na Planta, ajuste espessura e altura. Parede reta usa dois cliques; Parede contínua prolonga trechos. Parede curva usa três pontos: '
    'início, ponto intermediário e final. O arco é calculado e dividido em trechos de até 2 graus, agrupados. Ainda não há uma entidade '
    'curva única com raio editável, nem portas atravessando vários trechos do arco. Esc cancela.',
    'In Plan, set wall thickness and height. Straight walls use two clicks; continuous walls extend successive runs. Curved walls use '
    'three points: start, intermediate point and end. The calculated arc is tessellated into grouped segments of up to 2 degrees. A single '
    'editable-radius arc entity and openings spanning several arc segments are not supported. Esc cancels.',
    'En Planta, defina espesor y altura. Las paredes rectas usan dos clics; las continuas prolongan tramos. Las curvas usan tres puntos: '
    'inicio, punto intermedio y final. El arco calculado se divide en segmentos agrupados de hasta 2 grados. No hay una entidad curva '
    'única con radio editable ni aberturas que atraviesen varios segmentos. Esc cancela.'],
   ['Ative o encaixe na malha e escolha o passo em milímetros. Os snaps ortogonal, perpendicular e angular orientam a construção. Para '
    'medidas exatas, configure comprimento e direção antes de inserir. Selecione uma parede em planta para ajustar ou excluir com Delete; '
    'excluir a parede também remove seus vãos.',
    'Enable grid snapping and choose the spacing in millimetres. Orthogonal, perpendicular and angular snaps guide construction. For exact '
    'measurements, set length and direction before insertion. Select a wall in plan to edit it or press Delete; deleting a wall also '
    'removes its openings.',
    'Active el ajuste a la cuadrícula y elija el paso en milímetros. Los ajustes ortogonal, perpendicular y angular guían la construcción. '
    'Para medidas exactas, configure longitud y dirección antes de insertar. Seleccione una pared en planta para editarla o eliminarla con '
    'Supr; también se eliminan sus vanos.'],
   ['Escolha Porta ou Janela, o modelo e as medidas; clique junto à parede. O vão é criado na parede hospedeira. Altura, largura, peitoril '
    'e material podem ser ajustados. Os modelos têm representação simplificada, com batentes e folhas; não equivalem a um catálogo de '
    'esquadrias de fabricante.',
    'Choose Door or Window, a model and dimensions, then click by the wall. An opening is created in the host wall. Height, width, sill '
    'and material can be edited. Models use simplified frames and leaves; they are not a manufacturer’s detailed joinery catalogue.',
    'Elija Puerta o Ventana, un modelo y sus medidas; haga clic junto a la pared. Se crea un vano en la pared anfitriona. Puede ajustar '
    'altura, ancho, antepecho y material. Los modelos tienen marcos y hojas simplificados; no equivalen a un catálogo detallado de '
    'fabricante.'],
   ['Rebaixo de gesso cria uma geometria retangular por dois cantos em planta. Ajuste rebaixo e espessura. O teto automático cobre o '
    'retângulo do ambiente. Piso e seus acabamentos são definidos em Ambiente.',
    'Plaster soffit creates rectangular geometry from two plan corners. Adjust drop and thickness. Automatic ceiling covers the room '
    'rectangle. Floor finishes are set under Room.',
    'Falso techo crea una geometría rectangular mediante dos esquinas en planta. Ajuste descenso y espesor. El techo automático cubre el '
    'rectángulo del ambiente. Los acabados del piso se definen en Ambiente.']]),
 (['4. Camadas e proteção do projeto', '4. Layers and project protection', '4. Capas y protección del proyecto'],
  'layers',
  [['Clique em Camadas na faixa superior. As categorias são Paredes, Tetos e gesso, Pisos, Janelas, Portas do ambiente, Móveis e painéis e '
    'Decoração. Desmarque Mostrar para ocultar e marque Bloquear para proteger uma categoria. As configurações são salvas no .mar e '
    'participam do histórico de desfazer.',
    'Click Layers at the top. Categories are Walls, Ceilings and plaster, Floors, Windows, Room doors, Furniture and panels, and '
    'Decoration. Clear Show to hide and check Lock to protect a category. Settings are saved in .mar and included in undo history.',
    'Haga clic en Capas en la parte superior. Las categorías son Paredes, Techos y yeso, Pisos, Ventanas, Puertas del ambiente, Muebles y '
    'paneles y Decoración. Desmarque Mostrar para ocultar y marque Bloquear para proteger una categoría. La configuración se guarda en '
    '.mar y en el historial de deshacer.'],
   ['Ocultar não apaga o objeto, não retira peças do orçamento e não desativa a colisão. Ocultar uma parede também oculta suas esquadrias '
    'na vista. Mostrar todas as camadas recupera a visibilidade por categoria; Mostrar todos também recupera elementos ocultados '
    'individualmente.',
    'Hiding does not delete objects, remove parts from estimates or disable collision checks. Hiding a wall also hides its joinery in the '
    'view. Show all layers restores category visibility; Show all also restores individually hidden elements.',
    'Ocultar no borra objetos, no elimina piezas del presupuesto ni desactiva las colisiones. Ocultar una pared también oculta sus '
    'carpinterías en la vista. Mostrar todas las capas restaura la visibilidad por categoría; Mostrar todos también recupera elementos '
    'ocultados individualmente.'],
   ['O bloqueio atual protege toda a edição e exclusão dos objetos da categoria, além da transformação. Desbloqueie a camada para alterar '
    'seus objetos. As categorias são fixas nesta versão; não há criação de camadas arbitrárias.',
    'The current lock protects all editing and deletion of objects in the category, as well as transformations. Unlock the layer to change '
    'its objects. Categories are fixed in this release; arbitrary custom layers are not available.',
    'El bloqueo actual protege toda edición y eliminación de los objetos de la categoría, además de las transformaciones. Desbloquee la '
    'capa para cambiarlos. Las categorías son fijas en esta versión; no se pueden crear capas arbitrarias.'],
   ['A proteção impede novos cruzamentos entre os volumes externos de móveis, painéis, decoração, gesso e paredes. Encostar é permitido. O '
    'trajeto de translação também é verificado. Afaste o módulo antes de mudar de parede. O sistema é conservador: não modela todos os '
    'vãos internos nem verifica a trajetória de abertura das folhas.',
    'Protection prevents new overlaps between outer volumes of furniture, panels, decoration, plaster and walls. Contact is allowed. '
    'Translation paths are also checked. Move furniture away before changing walls. The system is conservative: it does not model every '
    'internal void or check door-opening trajectories.',
    'La protección impide nuevos cruces entre los volúmenes exteriores de muebles, paneles, decoración, yeso y paredes. Se permite el '
    'contacto. También se verifica el trayecto de traslación. Aleje el mueble antes de cambiar de pared. El sistema es conservador: no '
    'modela todos los huecos internos ni verifica la trayectoria de apertura de las hojas.']]),
 (['5. Crie e ajuste os módulos', '5. Create and edit modules', '5. Cree y ajuste los módulos'],
  'builder',
  [['Escolha um módulo pronto na biblioteca ou abra Criador de módulos. Defina largura, altura, profundidade, espessura, quantidade de '
    'portas, prateleiras, divisórias e gavetas. Use a prévia para conferir a composição antes de posicionar. Há categorias para cozinha, '
    'banheiro, dormitório, escritório, loja, estantes, guarda-roupas e painéis.',
    'Choose a library module or open Module builder. Set width, height, depth, thickness, door, shelf, divider and drawer counts. Check '
    'the preview before placement. Categories include kitchen, bathroom, bedroom, office, store, shelving, wardrobes and panels.',
    'Elija un módulo de la biblioteca o abra Creador de módulos. Defina ancho, altura, profundidad, espesor y cantidades de puertas, '
    'estantes, divisiones y cajones. Revise la vista previa antes de colocarlo. Hay categorías para cocina, baño, dormitorio, oficina, '
    'tienda, estanterías, armarios y paneles.'],
   ['Para orientar o fundo, clique em Parede de fundo e selecione a parede em planta. O arraste e as inserções procuram encaixar o módulo '
    'nessa parede. Limpe a parede escolhida para voltar à parede mais próxima. Alt durante o movimento ignora o encaixe, mas não a '
    'proteção contra colisões.',
    'To orient the back, click Target wall and select a wall in plan. Dragging and insertion attempt to snap the module to it. Clear the '
    'target to return to the nearest wall. Alt during movement bypasses snapping, but not collision protection.',
    'Para orientar el fondo, haga clic en Pared de fondo y seleccione una pared en planta. El arrastre y la inserción intentan encajar el '
    'módulo en ella. Quite la selección para volver a la pared más cercana. Alt durante el movimiento ignora el ajuste, pero no la '
    'protección contra colisiones.'],
   ['Em composições que não sejam Gaveteiro, a quantidade de gavetas cria caixas internas na zona inferior. Defina a altura dessa zona; as '
    'prateleiras ficam acima e as portas externas permanecem. Escolha chapa superior inteira, sem topo ou duas travessas. Confira a prévia '
    'e as peças antes de fabricar; folgas e espessuras do método construtivo ainda exigem revisão de compatibilidade com a representação.',
    'For compositions other than Drawer unit, the drawer count creates internal boxes in the lower zone. Set its height; shelves stay '
    'above and external doors remain. Choose a full top, no top or two cross rails. Check the preview and parts before manufacturing; '
    'construction-method clearances and thicknesses still need a consistency review against the visual representation.',
    'En composiciones distintas de Cajonera, la cantidad de cajones crea cajas internas en la zona inferior. Defina su altura; los '
    'estantes quedan arriba y se conservan las puertas exteriores. Elija tapa completa, sin tapa o dos travesaños. Revise la vista previa '
    'y las piezas; las holguras y espesores del método aún requieren comprobar su coherencia con la representación.']]),
 (['6. Frentes, puxadores e materiais', '6. Fronts, handles and materials', '6. Frentes, tiradores y materiales'],
  None,
  [['Selecione o módulo e abra Seleção. Os estilos de frente incluem lisa, provençal, perfil horizontal, perfil vertical, cava, vidro e '
    'alumínio com vidro. Aplique o estilo global ou edite folhas individualmente. As representações são geométricas e simplificadas; '
    'texturas de madeira são procedurais.',
    'Select a module and open Selection. Front styles include plain, raised panel, horizontal profile, vertical profile, recessed grip, '
    'glass and aluminium with glass. Apply a global style or edit individual leaves. Geometry is simplified and wood textures are '
    'procedural.',
    'Seleccione un módulo y abra Selección. Los estilos incluyen liso, provenzal, perfil horizontal, perfil vertical, uñero, vidrio y '
    'aluminio con vidrio. Aplique un estilo general o edite cada hoja. La geometría es simplificada y las texturas de madera son '
    'procedimentales.'],
   ['Em Posicionar puxadores, cada Frente é numerada. Escolha a dobradiça à esquerda ou à direita e use Abrir esta porta para conferir o '
    'sentido no 3D. Feche a abertura geral do módulo antes do controle individual. Posição do puxador, orientação, comprimento e distância '
    'da borda são configuráveis. Alterar a dobradiça não reposiciona automaticamente um puxador personalizado.',
    'In Handle placement, each Front is numbered. Choose left or right hinge and use Open this door to inspect the swing in 3D. Close the '
    'module’s global opening before using individual control. Handle position, orientation, length and edge offset are editable. Changing '
    'the hinge does not automatically reposition a custom handle.',
    'En Posicionar tiradores, cada Frente está numerado. Elija bisagra izquierda o derecha y use Abrir esta puerta para revisar el sentido '
    'en 3D. Cierre la apertura general del módulo antes del control individual. Puede configurar posición, orientación, longitud y '
    'distancia del borde del tirador. Cambiar la bisagra no recoloca automáticamente un tirador personalizado.'],
   ['Materiais separa marcenaria e decoração. Cadastre nome, preço por metro quadrado, cor e características disponíveis. Escolha se a '
    'aplicação vai ao corpo, às frentes ou a todos os componentes suportados. Copiar material recolhe o acabamento de um elemento; Pintar '
    'material aplica o acabamento escolhido.',
    'Materials separates woodworking from decoration. Enter a name, price per square metre, colour and available characteristics. Choose '
    'whether to apply it to the body, fronts or all supported components. Copy material samples an element’s finish; Paint material '
    'applies the selected finish.',
    'Materiales separa carpintería y decoración. Introduzca nombre, precio por metro cuadrado, color y características disponibles. Elija '
    'si se aplica al cuerpo, los frentes o todos los componentes compatibles. Copiar material toma el acabado de un elemento; Pintar '
    'material aplica el acabado elegido.'],
   ['O veio afeta a orientação visual e o plano de corte. Revise o sentido peça a peça na lista de fabricação. Os nomes de catálogos e '
    'dados de projeto podem permanecer em português ao mudar o idioma da interface.',
    'Grain affects visual orientation and the cutting layout. Review each part’s grain direction in the manufacturing list. Catalogue '
    'names and project data may remain in Portuguese when changing the interface language.',
    'La veta afecta la orientación visual y el plan de corte. Revise el sentido de cada pieza en la lista de fabricación. Los nombres del '
    'catálogo y los datos del proyecto pueden permanecer en portugués al cambiar el idioma de la interfaz.']]),
 (['7. Fabricação, ferragens e orçamento', '7. Manufacturing, hardware and estimates', '7. Fabricación, herrajes y presupuesto'],
  None,
  [['No Método construtivo, configure espessuras, folgas, recuo e montagem do fundo, componentes e critérios de fitamento. A prévia da '
    'lista de peças permite conferir o resultado. Os parâmetros de fabricação calculam a lista; nem todo detalhe de usinagem é reproduzido '
    'no 3D.',
    'In Construction method, configure thicknesses, gaps, back setback and assembly, components and edge-banding rules. Review the '
    'resulting parts list. Manufacturing settings calculate the list; not every machining detail is reproduced in 3D.',
    'En Método constructivo, configure espesores, holguras, retranqueo y montaje del fondo, componentes y criterios de canteado. Revise el '
    'resultado en la lista de piezas. Los parámetros calculan la lista; no todos los detalles de mecanizado se reproducen en 3D.'],
   ['A lista inclui peças e ferragens estimadas, como parafusos, pregos, dobradiças e pares de corrediças. Essas quantidades vêm de regras '
    'gerais, não de um sistema certificado de furação de fabricante. O CSV geral inclui ferragens; o CSV de corte contém apenas peças de '
    'chapa.',
    'The list includes parts and estimated hardware such as screws, nails, hinges and slide pairs. Quantities follow general rules, not a '
    'certified manufacturer drilling system. The general CSV includes hardware; the cutting CSV contains only board parts.',
    'La lista incluye piezas y herrajes estimados, como tornillos, clavos, bisagras y pares de correderas. Las cantidades siguen reglas '
    'generales, no un sistema certificado de perforación del fabricante. El CSV general incluye herrajes; el CSV de corte contiene solo '
    'piezas de tablero.'],
   ['Cadastre preços de materiais e fita de borda. No orçamento, ajuste mão de obra, perdas, ferragens, impostos e multiplicador. '
    'Decoração e acabamentos do ambiente ficam fora do orçamento de marcenaria. Um preço zero precisa ser revisado; não significa material '
    'gratuito.',
    'Enter material and edge-banding prices. In the estimate, adjust labour, waste, hardware, taxes and multiplier. Decoration and room '
    'finishes are excluded from woodworking estimates. Review zero prices; they do not mean free material.',
    'Introduzca precios de materiales y cantos. En el presupuesto, ajuste mano de obra, desperdicio, herrajes, impuestos y multiplicador. '
    'La decoración y los acabados del ambiente quedan fuera del presupuesto de carpintería. Revise los precios cero; no significan '
    'material gratuito.']]),
 (['8. Plano de corte e CSV', '8. Cutting layout and CSV', '8. Plan de corte y CSV'],
  'cut',
  [['Abra Plano de corte. Configure dimensões da chapa, margem e espessura do corte da serra. A distribuição separa materiais e espessuras '
    'e respeita o veio configurado. Peças maiores que a chapa são apontadas para revisão.',
    'Open Cutting layout. Set board dimensions, margin and saw kerf. Layout separates materials and thicknesses and respects configured '
    'grain. Parts larger than the board are flagged for review.',
    'Abra Plan de corte. Configure dimensiones del tablero, margen y ancho de corte de sierra. La distribución separa materiales y '
    'espesores y respeta la veta configurada. Se señalan las piezas mayores que el tablero para revisión.'],
   ['Exporte a lista CSV e os desenhos SVG das chapas. O algoritmo é heurístico e não garante o melhor aproveitamento possível. Confira '
    'tamanhos, quantidade, orientação, margem e kerf antes de cortar.',
    'Export the CSV list and SVG board drawings. The algorithm is heuristic and does not guarantee optimal yield. Check dimensions, '
    'quantity, orientation, margin and kerf before cutting.',
    'Exporte la lista CSV y los dibujos SVG de los tableros. El algoritmo es heurístico y no garantiza el aprovechamiento óptimo. Revise '
    'medidas, cantidades, orientación, margen y ancho de corte antes de cortar.'],
   ['O CSV é genérico. Para Cortecloud ou outro serviço, confirme o modelo de planilha e mapeie as colunas no importador. Esta entrega não '
    'comprova integração direta com Cortecloud nem compatibilidade com outros formatos proprietários.',
    'CSV is generic. For Cortecloud or another service, confirm the spreadsheet template and map columns in the importer. This release '
    'does not establish direct Cortecloud integration or compatibility with proprietary native formats.',
    'El CSV es genérico. Para Cortecloud u otro servicio, confirme la plantilla de hoja de cálculo y asigne las columnas en el importador. '
    'Esta entrega no acredita integración directa con Cortecloud ni compatibilidad con formatos propietarios.']]),
 (['9. Pranchas A4 e cotas', '9. A4 sheets and dimensions', '9. Láminas A4 y cotas'],
  'documentation',
  [['Abra Pranchas. Escolha orientação horizontal ou vertical. Preencha título, cliente, projetista, número, revisão e nota do carimbo. '
    'Adicione planta, elevação frontal, lateral ou vista 3D.',
    'Open Sheets. Choose landscape or portrait. Fill in title, client, designer, sheet number, revision and title block note. Add plan, '
    'front elevation, side elevation or 3D view.',
    'Abra Láminas. Elija orientación horizontal o vertical. Complete título, cliente, proyectista, número, revisión y nota del rótulo. '
    'Añada planta, elevación frontal, lateral o vista 3D.'],
   ['Arraste a vista para posicioná-la. Arraste o quadrado verde para mudar o quadro. As vistas ortogonais permanecem em 1:25: aumentar o '
    'quadro mostra uma área maior, sem mudar a escala. Desloque o desenho dentro do quadro pelos campos próprios. Observe avisos de '
    'recorte e limite da folha.',
    'Drag a view to position it. Drag the green square to resize its frame. Orthographic views remain at 1:25: enlarging the frame reveals '
    'more area without changing scale. Use the offset fields to pan the drawing within its frame. Watch for cropping and page-boundary '
    'warnings.',
    'Arrastre una vista para colocarla. Arrastre el cuadrado verde para cambiar el marco. Las vistas ortogonales permanecen en 1:25: '
    'ampliar el marco muestra más área sin cambiar la escala. Use los campos de desplazamiento para mover el dibujo dentro del marco. '
    'Revise los avisos de recorte y límite de hoja.'],
   ['Ative cotas automáticas ou Cota por dois pontos. Nas vistas ortogonais, clique nos dois pontos a medir. Ajuste texto, espessura e '
    'afastamento. Cotas manuais não ficam vinculadas aos objetos: confira-as novamente depois de modificar o projeto. A vista 3D é '
    'ilustrativa e não serve para medir em escala.',
    'Enable automatic dimensions or two-point dimensioning. In an orthographic view, click the two points to measure. Adjust text, line '
    'weight and offset. Manual dimensions are not object-linked: review them again after project changes. The 3D view is illustrative and '
    'not suitable for scale measurements.',
    'Active cotas automáticas o Cota por dos puntos. En una vista ortogonal, haga clic en los puntos a medir. Ajuste texto, grosor y '
    'separación. Las cotas manuales no están vinculadas a objetos: revíselas tras cambiar el proyecto. La vista 3D es ilustrativa y no '
    'sirve para medir a escala.'],
   ['A tabela de módulos pode ser incluída; no PDF, listas longas continuam em páginas adicionais. Exporte PDF ou SVG e escolha o destino '
    'no diálogo. Ao imprimir, use tamanho real / 100%, sem ajustar à página, para conservar 1:25.',
    'You can include the module table; long PDF lists continue on additional pages. Export PDF or SVG and choose a location in the dialog. '
    'Print at actual size / 100%, without fit-to-page, to preserve 1:25.',
    'Puede incluir la tabla de módulos; las listas largas del PDF continúan en páginas adicionales. Exporte PDF o SVG y elija el destino '
    'en el diálogo. Imprima a tamaño real / 100%, sin ajustar a página, para conservar 1:25.']]),
 (['10. IFC e capturas', '10. IFC and view captures', '10. IFC y capturas'],
  None,
  [['Arquivo → Exportar IFC gera IFC4 com sólidos extrudados, móveis, paredes, portas, janelas, piso, gesso e painéis. Portas e janelas '
    'têm relações com os vãos da parede. Os móveis incluem medidas, materiais e propriedades do módulo. A visibilidade da vista não exclui '
    'elementos do IFC.',
    'File → Export IFC writes IFC4 with swept solids, furniture, walls, doors, windows, floor, plaster and panels. Doors and windows '
    'relate to wall openings. Furniture includes dimensions, materials and module properties. View visibility does not exclude elements '
    'from IFC.',
    'Archivo → Exportar IFC genera IFC4 con sólidos extruidos, muebles, paredes, puertas, ventanas, piso, yeso y paneles. Las puertas y '
    'ventanas se relacionan con los vanos de pared. Los muebles incluyen medidas, materiales y propiedades del módulo. La visibilidad de '
    'la vista no excluye elementos del IFC.'],
   ['O arquivo mantém parâmetros de sólidos e propriedades BIM. Isso não reconstrói automaticamente a árvore de operações do FreeCAD nem '
    'as regras de edição do Bonsai. Validação pelo IfcOpenShell verifica a estrutura e a reconstrução dos sólidos; confira também o modelo '
    'no aplicativo de destino.',
    'The file retains solid parameters and BIM properties. It does not automatically recreate FreeCAD’s feature tree or Bonsai editing '
    'rules. IfcOpenShell validation checks structure and solid reconstruction; also inspect the model in the destination application.',
    'El archivo conserva parámetros de sólidos y propiedades BIM. No reconstruye automáticamente el árbol de operaciones de FreeCAD ni las '
    'reglas de edición de Bonsai. La validación con IfcOpenShell verifica la estructura y la reconstrucción de sólidos; revise también el '
    'modelo en el programa de destino.'],
   ['Na cena, Exportar PNG salva uma imagem da vista atual. Salvar SVG produz a representação vetorial. Ajuste a câmera e a visibilidade '
    'das camadas antes de exportar. Guarde o .mar junto das entregas para continuar a edição.',
    'In the scene, Export PNG saves an image of the current view. Save SVG creates a vector representation. Set the camera and layer '
    'visibility before exporting. Keep the .mar alongside deliverables for continued editing.',
    'En la escena, Exportar PNG guarda una imagen de la vista actual. Guardar SVG genera una representación vectorial. Ajuste cámara y '
    'visibilidad de capas antes de exportar. Conserve el .mar junto con las entregas para continuar editando.']]),
 (['11. Preferências e recuperação', '11. Preferences and recovery', '11. Preferencias y recuperación'],
  'preferences',
  [['A interface usa tema claro. Em Preferências, escolha Português, English ou Español. A tradução desta edição cobre controles '
    'principais; há descrições e catálogos ainda em português. Escolha atalhos e a exibição dos painéis e das dicas de comando.',
    'The interface uses a light theme. In Preferences, choose Português, English or Español. Translation currently covers primary '
    'controls; some descriptions and catalogues remain in Portuguese. Configure shortcuts and the visibility of panels and command hints.',
    'La interfaz utiliza tema claro. En Preferencias, elija Português, English o Español. La traducción cubre los controles principales; '
    'algunas descripciones y catálogos siguen en portugués. Configure atajos y visibilidad de paneles y sugerencias de comandos.'],
   ['Ctrl+Z ou Desfazer volta à ação anterior. Esc cancela a ferramenta em andamento. Delete remove a seleção, respeitando os bloqueios de '
    'camadas. Ctrl+S salva e Ctrl+O abre projetos. As preferências de atalhos podem mudar essas associações.',
    'Ctrl+Z or Undo returns to the previous action. Esc cancels the active tool. Delete removes the selection, respecting layer locks. '
    'Ctrl+S saves and Ctrl+O opens projects. Shortcut preferences may change these mappings.',
    'Ctrl+Z o Deshacer vuelve a la acción anterior. Esc cancela la herramienta activa. Supr elimina la selección respetando los bloqueos '
    'de capas. Ctrl+S guarda y Ctrl+O abre proyectos. Las preferencias pueden cambiar estas asignaciones.'],
   ['Objeto não aparece? Confira Mostrar todos, as camadas, Ocultar paredes à frente e o enquadramento. Movimento não funciona? Confira a '
    'camada bloqueada, a parede de fundo e a mensagem de colisão. Arquivo não salva? Escolha uma pasta onde você tenha permissão de '
    'gravação.',
    'Object missing? Check Show all, layers, Hide front walls and framing. Movement blocked? Check layer locks, target wall and the '
    'collision message. Cannot save? Choose a folder where you have write permission.',
    '¿No aparece un objeto? Revise Mostrar todos, las capas, Ocultar paredes frontales y el encuadre. ¿No puede moverlo? Revise bloqueos, '
    'pared de fondo y mensaje de colisión. ¿No puede guardar? Elija una carpeta con permiso de escritura.']]),
 (['12. Seleção, cópias e matriz', '12. Selection, copies and arrays', '12. Selección, copias y matrices'],
  None,
  [['Use Ctrl+clique para compor uma seleção. Ctrl+A seleciona objetos visíveis de camadas desbloqueadas. Ctrl+C copia, Ctrl+V cola com '
    'deslocamento de 1000 mm no eixo X. Os atalhos não atuam enquanto você digita em um campo. Use Editar para acessar os mesmos comandos.',
    'Use Ctrl+click to build a selection. Ctrl+A selects visible objects on unlocked layers. Ctrl+C copies; Ctrl+V pastes with a 1000 mm X '
    'offset. These shortcuts do not act while typing in a field. The Edit menu exposes the same actions.',
    'Use Ctrl+clic para componer una selección. Ctrl+A selecciona objetos visibles en capas desbloqueadas. Ctrl+C copia y Ctrl+V pega con '
    'desplazamiento de 1000 mm en X. Los atajos no actúan mientras escribe en un campo. El menú Editar contiene las mismas acciones.'],
   ['Ctrl+G agrupa e Shift+G desagrupa. Grupos são salvos no .mar e participam do desfazer. O deslocamento de um módulo selecionado '
    'propaga a translação à seleção. Rotação e redimensionamento conjuntos ainda não são operações de grupo.',
    'Ctrl+G groups and Shift+G ungroups. Groups are saved in .mar and included in undo history. Moving a selected module propagates its '
    'translation to the selection. Group rotation and resizing are not supported.',
    'Ctrl+G agrupa y Shift+G desagrupa. Los grupos se guardan en .mar y participan en deshacer. Mover un módulo seleccionado propaga su '
    'traslación a la selección. No hay rotación ni cambio de tamaño conjuntos.'],
   ['Matriz abre os campos de quantidade adicional e passo X, Y, Z. O limite é 200 cópias por operação. Paredes copiadas levam suas '
    'aberturas e criam novos identificadores. Cópias que colidem podem ser canceladas; use um passo suficiente para separar os volumes.',
    'Array opens additional-copy count and X, Y, Z spacing. The limit is 200 copies per operation. Copied walls retain openings with new '
    'identifiers. Colliding copies may be cancelled; choose enough spacing to separate their volumes.',
    'Matriz abre la cantidad adicional y los pasos X, Y, Z. El límite es 200 copias por operación. Las paredes copiadas conservan sus '
    'aberturas con nuevos identificadores. Las copias con colisión pueden cancelarse; deje suficiente separación.']]),
 (['13. Painel ripado e painel para TV', '13. Slatted and TV panels', '13. Paneles de listones y TV'],
  'panels',
  [['As duas ferramentas superiores abrem criadores independentes. Ajuste largura, altura, espessura, posição, material e sentido do veio. '
    'No ripado, configure largura de ripa, vão e chapa de fundo. A prévia mostra a distribuição antes da criação.',
    'The two top tools open independent builders. Set width, height, thickness, position, material and grain direction. For slats, set '
    'slat width, gap and backing board. The preview shows the layout before creation.',
    'Las dos herramientas superiores abren creadores independientes. Defina ancho, altura, espesor, posición, material y veta. Para '
    'listones, defina ancho, separación y tablero de fondo. La vista previa muestra la distribución.'],
   ['As peças são agrupadas e entram na fabricação. No painel TV, o retângulo verde é uma referência visual, não um televisor incluído no '
    'projeto. A posição inicial é numérica; ajuste as peças selecionadas na planta ou nas propriedades.',
    'Pieces are grouped and included in manufacturing. The green TV rectangle is only a visual reference, not a television inserted in the '
    'project. Initial placement is numeric; adjust selected pieces in plan or properties.',
    'Las piezas se agrupan y entran en fabricación. El rectángulo verde de TV es una referencia visual, no un televisor incluido. La '
    'posición inicial es numérica; ajuste las piezas seleccionadas en planta o propiedades.']]),
 (['14. Gesso e rodapé decorativo', '14. Ceiling finishes and skirting', '14. Yeso y zócalos decorativos'],
  'finishes',
  [['Rebaixo de gesso oferece placa lisa, sanca perimetral e sanca escalonada. Informe área, faixa, rebaixo e espessura. O corte é '
    'esquemático; a cena mostra as peças construídas. Os componentes ficam agrupados e fora do orçamento de marcenaria.',
    'Ceiling finish offers a plain slab, perimeter cove and stepped cove. Enter area, band width, drop and thickness. The section is '
    'schematic; the scene displays the generated pieces. Components are grouped and excluded from joinery estimates.',
    'El acabado de yeso ofrece placa lisa, foseado perimetral y escalonado. Indique área, franja, descenso y espesor. La sección es '
    'esquemática; la escena muestra las piezas generadas. Se agrupan y quedan fuera del presupuesto de carpintería.'],
   ['Rodapé decorativo oferece três perfis, altura, projeção e posição inferior ou superior. Usa a parede selecionada ou todas as paredes '
    'quando nenhuma está selecionada. As extremidades são recuadas para reduzir colisões nos cantos; encontros, vãos de portas e junções '
    'precisam de revisão manual.',
    'Decorative skirting offers three profiles, height, projection and floor or ceiling placement. It uses the selected wall or all walls '
    'if none is selected. Ends are inset to reduce corner collisions; junctions and door openings require manual review.',
    'El zócalo decorativo ofrece tres perfiles, altura, proyección y posición inferior o superior. Usa la pared seleccionada o todas si no '
    'hay selección. Los extremos se retranquean para reducir colisiones; encuentros y vanos de puertas requieren revisión manual.']]),
 (['15. Geometria decorativa', '15. Decorative geometry', '15. Geometría decorativa'],
  'geometry',
  [['Clique na grade para marcar os vértices de uma forma. Use Fechar contorno; linhas cruzadas são recusadas. Arraste a prévia '
    'verticalmente para alterar a extrusão, ou digite a altura. Ajuste largura, profundidade e posição e crie o sólido.',
    'Click the grid to place outline vertices. Choose Close outline; crossing edges are rejected. Drag vertically in the preview to change '
    'extrusion or type its height. Set width, depth and position, then create the solid.',
    'Haga clic en la cuadrícula para marcar vértices. Use Cerrar contorno; se rechazan líneas cruzadas. Arrastre verticalmente la vista '
    'previa para cambiar la extrusión o escriba su altura. Defina ancho, profundidad y posición y cree el sólido.'],
   ['A ferramenta aceita contornos simples, inclusive côncavos, e uma extrusão vertical. Não faz furos, operações booleanas nem edição '
    'independente de faces. É decoração, não gera peças de móveis. O IFC usa um perfil fechado extrudado. As colisões continuam usando o '
    'volume externo conservador.',
    'The tool accepts simple outlines, including concave shapes, with one vertical extrusion. It does not support holes, Boolean '
    'operations or independent face editing. It is decoration and generates no furniture parts. IFC uses an extruded closed profile. '
    'Collisions still use a conservative outer volume.',
    'La herramienta admite contornos simples, incluso cóncavos, con una extrusión vertical. No admite huecos, operaciones booleanas ni '
    'edición independiente de caras. Es decoración y no genera piezas de muebles. IFC usa un perfil cerrado extruido. Las colisiones '
    'siguen usando un volumen exterior conservador.']]),
 (['16. Catálogos e imagens de materiais', '16. Libraries and material images', '16. Bibliotecas e imágenes de materiales'],
  None,
  [['Foram acrescentados 15 inferiores sem topo para cozinha, 15 para banheiro, 10 nichos de forno e 20 módulos de escritório. Decoração '
    'tem categorias internas e mais 200 variações dimensionais de mesas, bancos, aparadores, pedestais, expositores, estantes, puffs e '
    'mesas laterais. São modelos paramétricos simplificados.',
    'The library adds 15 kitchen base units without tops, 15 bathroom units, 10 oven niches and 20 office modules. Decoration has internal '
    'categories and 200 more dimensional variants of tables, benches, sideboards, pedestals, displays, shelves, poufs and side tables. '
    'These are simplified parametric models.',
    'La biblioteca añade 15 módulos inferiores sin tapa de cocina, 15 de baño, 10 nichos de horno y 20 módulos de oficina. Decoración '
    'incluye categorías y 200 variantes dimensionales adicionales de mesas, bancos, aparadores, pedestales, expositores, estantes, pufs y '
    'mesas laterales. Son modelos paramétricos simplificados.'],
   ['Há dez novas opções aproximadas de vidro e frentes de vidro com perfil horizontal ou vertical. Em Materiais, Importar PNG associa uma '
    'imagem local ao material. A imagem é referenciada pelo caminho e deve acompanhar o projeto quando ele for transferido. A renderização '
    'usa uma amostra de até 512 × 512 pixels.',
    'There are ten new approximate glass finishes and glass fronts with horizontal or vertical profiles. In Materials, Import PNG links a '
    'local image to a material. Images are referenced by path and must accompany a transferred project. Rendering uses a sample of up to '
    '512 × 512 pixels.',
    'Hay diez acabados aproximados de vidrio nuevos y frentes con perfil horizontal o vertical. En Materiales, Importar PNG vincula una '
    'imagen local. Se referencia su ruta y debe acompañar al proyecto al transferirlo. La representación usa una muestra de hasta 512 × '
    '512 píxeles.'],
   ['As cores e veios padrão são aproximações. Não foram incluídas 200 texturas oficiais de fabricantes: não há pacote com redistribuição '
    'autorizada nesta entrega. Use imagens que você tenha autorização para utilizar. As propriedades brilho e reflexo não constituem um '
    'renderizador físico.',
    'Default colours and grain are approximations. This release does not include 200 official manufacturer textures: no '
    'redistribution-authorized package is supplied. Use images you are allowed to use. Gloss and reflectivity settings do not constitute a '
    'physically based renderer.',
    'Los colores y vetas predeterminados son aproximaciones. No se incluyen 200 texturas oficiales de fabricantes: no hay un paquete '
    'autorizado para redistribución. Use imágenes que tenga permiso de utilizar. Brillo y reflexión no constituyen un renderizador '
    'físico.']]),
 (['17. Distribuição e limites', '17. Distribution and limitations', '17. Distribución y limitaciones'],
  None,
  [['Os complementos de programas externos foram retirados desta versão. A pasta packaging contém código de preparação para Windows e '
    'macOS, sem binários testados nessas plataformas. Os seletores de arquivos Linux ainda precisam de adaptação para esses sistemas.',
    'External-program addons have been removed from this release. The packaging folder contains Windows and macOS preparation code, '
    'without tested binaries for those platforms. Linux file pickers still need adaptation for those systems.',
    'Se retiraron los complementos de programas externos. La carpeta packaging contiene código de preparación para Windows y macOS, sin '
    'binarios probados para esas plataformas. Los selectores de archivos Linux aún necesitan adaptación.'],
   ['Esta é uma versão em desenvolvimento. A troca de modelos de esquadrias altera a representação, ainda simplificada; não há simulação '
    'completa de mecanismos. Grupos não oferecem todas as transformações. A colisão conservadora pode impedir encaixes internos legítimos. '
    'Consulte as notas da versão e revise antes de fabricar.',
    'This is a development release. Changing opening models changes their simplified representation; mechanisms are not fully simulated. '
    'Groups do not support every transformation. Conservative collisions may block legitimate internal placements. Read the release notes '
    'and review before manufacturing.',
    'Esta es una versión en desarrollo. Cambiar modelos de aberturas modifica su representación simplificada; no hay simulación completa '
    'de mecanismos. Los grupos no admiten todas las transformaciones. Las colisiones conservadoras pueden impedir encajes internos '
    'válidos. Consulte las notas y revise antes de fabricar.']])]
