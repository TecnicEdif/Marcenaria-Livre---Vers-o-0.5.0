"""Usage: python validate_ifc.py path.ifc (requires IfcOpenShell)."""
import sys
import ifcopenshell
import ifcopenshell.validate
import ifcopenshell.geom
model=ifcopenshell.open(sys.argv[1])
logger=ifcopenshell.validate.json_logger()
ifcopenshell.validate.validate(model,logger)
if logger.statements:
    for issue in logger.statements:print(issue['message'])
    raise SystemExit(1)
settings=ifcopenshell.geom.settings()
count=0
for product in model.by_type('IfcProduct'):
    if product.Representation:
        shape=ifcopenshell.geom.create_shape(settings,product)
        assert len(shape.geometry.verts)>0, product
        count+=1
assert model.by_type('IfcFurniture')
print(f'IFC4: zero erros de estrutura; {count} produtos com geometria reconstruída.')
