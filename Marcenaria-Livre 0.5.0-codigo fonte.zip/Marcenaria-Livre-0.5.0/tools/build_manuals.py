"""Generate the three public manuals with verified application screenshots."""
from pathlib import Path
import sys
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Image,PageBreak,KeepTogether
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'docs'))
from manual_content import TITLE,SUBTITLE,SECTIONS
OUT=ROOT/'output/pdf';OUT.mkdir(parents=True,exist_ok=True)
pdfmetrics.registerFont(TTFont('DejaVu','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuBold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
TEAL=colors.HexColor('#007f84');INK=colors.HexColor('#243536')
styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='BodyMAR',fontName='DejaVu',fontSize=10,leading=15,textColor=INK,spaceAfter=12))
styles.add(ParagraphStyle(name='TitleMAR',fontName='DejaVuBold',fontSize=29,leading=35,textColor=TEAL,spaceAfter=18))
styles.add(ParagraphStyle(name='HeadingMAR',fontName='DejaVuBold',fontSize=18,leading=24,textColor=TEAL,spaceAfter=18))
styles.add(ParagraphStyle(name='CaptionMAR',fontName='DejaVu',fontSize=8,leading=11,textColor=colors.HexColor('#526868'),spaceAfter=15))
def para(text,style='BodyMAR'):return Paragraph(escape(text),styles[style])
def footer(c,doc):
 c.saveState();c.setStrokeColor(TEAL);c.setLineWidth(.6);c.line(18*mm,16*mm,192*mm,16*mm);c.setFont('DejaVu',8);c.setFillColor(INK);c.drawString(18*mm,11*mm,'MARCENARIA LIVRE · 0.5.0');c.drawRightString(192*mm,11*mm,str(doc.page));c.restoreState()
for lang,code in enumerate(['PT','EN','ES']):
 path=OUT/f'Manual-Marcenaria-Livre-{code}.pdf'
 doc=SimpleDocTemplate(str(path),pagesize=A4,rightMargin=18*mm,leftMargin=18*mm,topMargin=19*mm,bottomMargin=23*mm,title=TITLE[lang]+' · Marcenaria Livre 0.5.0',author='Marcenaria Livre')
 story=[Spacer(1,20*mm),Image(str(ROOT/'assets/logo.png'),width=40*mm,height=40*mm),Spacer(1,15*mm),para('MARCENARIA LIVRE','TitleMAR'),para(TITLE[lang],'HeadingMAR'),para(SUBTITLE[lang]),Spacer(1,12*mm),para(['Versão 0.5.0 · Linux · 12 de outubro de 2026','Version 0.5.0 · Linux · 12 October 2026','Versión 0.5.0 · Linux · 12 de octubre de 2026'][lang]),para(['Guia da versão em desenvolvimento, com capturas reais do aplicativo e limites documentados.','Guide to the development release, with real application screenshots and documented limitations.','Guía de la versión en desarrollo, con capturas reales del programa y limitaciones documentadas.'][lang]),PageBreak(),para(['Conteúdo','Contents','Contenido'][lang],'HeadingMAR')]
 for title,_,_ in SECTIONS:story.append(para(title[lang]))
 story.append(PageBreak())
 for index,(title,image,paragraphs) in enumerate(SECTIONS):
  story.append(para(title[lang],'HeadingMAR'))
  if image:
   shot=ROOT/f'docs/screenshots/{image}{"_"+str(lang) if lang else ""}.png'
   if not shot.exists():raise FileNotFoundError(shot)
   from PIL import Image as PILImage
   with PILImage.open(shot) as im:w,h=im.size
   story.append(Image(str(shot),width=174*mm,height=174*mm*h/w))
   story.append(para(['Captura real da interface. Alguns textos ainda estão em português.','Actual interface screenshot. Some text remains in Portuguese.','Captura real de la interfaz. Algunos textos siguen en portugués.'][lang],'CaptionMAR'))
  for p in paragraphs:story.append(para(p[lang]))
  if index<len(SECTIONS)-1:story.append(PageBreak())
 doc.build(story,onFirstPage=footer,onLaterPages=footer)
 print(path)
