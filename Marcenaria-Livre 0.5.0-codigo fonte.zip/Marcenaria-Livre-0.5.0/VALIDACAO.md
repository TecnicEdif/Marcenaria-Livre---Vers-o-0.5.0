# Verificação da versão 0.5.0

Data: 12 de outubro de 2026.

- 52 testes Rust passaram, em compilação otimizada.
- Compilação Linux concluída. Existem avisos do compilador; não foram apresentados como erros resolvidos.
- Casos novos cobrem grupos no arquivo MAR/desfazer, cópias com novos IDs, aberturas de paredes copiadas, cancelamento atômico, bloqueios, arcos por três pontos, topos, gavetas internas, catálogos e polígonos côncavos.
- IfcOpenShell: zero erros de estrutura e oito produtos com geometria reconstruída no projeto de verificação que inclui contorno extrudado. Não é certificação de interoperabilidade nem validação de todas as regras EXPRESS.
- Renderização de 100 módulos / 6.225 faces, imagem 480 × 320: aproximadamente 47 ms neste ambiente. Não representa taxa de quadros garantida em tela cheia.
- Capturas reais da interface geradas em tela virtual Linux. Não substituem ensaio completo de usabilidade ou fabricação.
- Instalação em Windows/macOS não executada. Snap não construído. As respectivas receitas não são instaladores testados.

Consulte README e manuais para limitações funcionais. Texturas oficiais de fabricantes não foram redistribuídas.

## Pacotes Linux

AppImage, Debian e Flatpak foram gerados. O executável de cada pacote produziu a mesma captura de teste (SHA-256 `8db00647e7d13e9074a2fd58231452398669e187f7e3745b3b5bfaaa9a1d1b6e`). O AppImage abriu a interface em tela virtual. O Debian foi extraído para execução; não foi instalado no sistema. O Flatpak foi executado pelo runtime a partir da árvore de construção; o bundle não foi instalado no perfil do usuário.
