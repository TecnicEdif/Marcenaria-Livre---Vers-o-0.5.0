# Marcenaria Livre 0.5.0

Aplicativo de projeto de ambientes e marcenaria em Rust, com interface gráfica, fabricação, orçamento, plano de corte e pranchas. Versão em desenvolvimento, com limitações descritas abaixo.

## Começar

Use o AppImage, Debian `.deb` ou Flatpak em `dist` na entrega completa. Os binários Linux x86_64 desta entrega exigem glibc 2.39 ou superior. O Flatpak usa Freedesktop 25.08. Salve projetos editáveis em `.mar`. Os manuais em português, inglês e espanhol ficam em `docs/manuais`.

## Novidades

- Ctrl+C, Ctrl+V, Ctrl+A, Ctrl+G e Shift+G; seleção com Ctrl+clique; menu Editar e matriz com até 200 cópias por operação. Grupos persistem no projeto e no desfazer.
- Painel ripado e painel para TV com criadores separados, prévia, medidas, posição e material. Peças de ripados entram na lista de fabricação.
- Gesso liso, perimetral e escalonado; rodapés decorativos com três perfis, posicionamento superior/inferior, medidas e corte esquemático.
- Geometria decorativa por contorno simples e extrusão vertical, com prévia e arraste para alterar a altura; exportação de perfil extrudado em IFC.
- Módulos com portas externas, gavetas internas inferiores e prateleiras superiores; topo completo, sem topo ou duas travessas.
- Mais 15 inferiores de cozinha sem topo, 15 de banheiro sem topo, 10 nichos para forno e 20 módulos de escritório.
- Decoração organizada em categorias, com mais 200 variações dimensionais de oito famílias paramétricas. Modelos de mesas, bancos e estantes dessas famílias possuem peças representadas separadamente.
- Dez novos acabamentos aproximados de vidro; frentes de vidro com perfis horizontais e verticais.
- Importação local de texturas PNG para materiais de módulos e painéis. As imagens são referenciadas pelo caminho, não embutidas no `.mar`; acompanhe os arquivos ao transferir um projeto.
- Troca de modelos decorativos de portas/janelas nas propriedades, posição na parede por valor e arraste em planta/3D. Representação simplificada de venezianas, perfis, frentes provençais e travessas.
- Parede curva calculada por três pontos e dividida em trechos de até 2 graus, agrupados.
- Seleção 3D por faces para módulos, paredes, aberturas, painéis, decoração e gesso. Contornos de seleção múltipla, ampliação da faixa de zoom e reaproveitamento de imagens sem alterações. Resolução temporariamente reduzida durante movimento.
- Código de preparação de builds Windows/macOS em `packaging`, sem binários compilados nessas plataformas. Complementos externos removidos do código ativo e desta entrega.

## Limites e pontos ainda pendentes

- Não foram incorporadas as 200 texturas oficiais dos fabricantes solicitados. Não há pacote de imagens autorizado para redistribuição. Materiais padrão são cores e veios aproximados; não são texturas oficiais. Consulte `docs/MATERIAIS.md`.
- A modelagem decorativa é uma extrusão de contorno simples; não é modelagem livre de cada face, não faz furos nem operações booleanas.
- Grupos propagam translação a partir de módulos, painéis ou decoração. Rotação e escala conjuntas ainda não são implementadas. A matriz é linear no vetor X/Y/Z, não circular nem uma grade independente de linhas e colunas.
- O arco usa trechos; ainda falta uma entidade curva única com raio editável. Uma abertura não atravessa vários trechos de curva.
- Rodapés possuem extremidades recuadas. Encontros de cantos e recortes em portas exigem revisão manual; a ferramenta não resolve automaticamente todas as junções.
- Colisões usam volumes externos conservadores, não cavidades internas. Podem impedir encaixes legítimos de objetos dentro de nichos. Portas em movimento não possuem simulação física completa.
- Os modelos de esquadrias são simplificados. A troca de modelo não simula todos os mecanismos reais. Bibliotecas contêm variações paramétricas, não centenas de modelos artísticos independentes.
- Espessuras, folgas, montagem do fundo e regras de fabricação precisam ser conferidas em relação à representação 3D antes de produzir. Não há garantia de fabricação sem revisão.
- Reflexo e brilho não constituem um renderizador físico; paredes e pisos têm representação simplificada. Texturas PNG não são incorporadas ao IFC.
- Tradução da interface é parcial; os três manuais são traduzidos. Recursos recentes ainda exibem português na interface.
- CSV para serviços externos é genérico, com mapeamento de colunas e conferência necessários.
- O pacote Snap não foi construído; há uma receita. Windows/macOS incluem fontes e scripts não executados, com seletores de arquivos ainda dependentes do Linux.

## Compilar

Instale Rust/Cargo e bibliotecas gráficas Linux X11, xkbcommon e OpenGL. Execute `cargo build --release`; testes: `cargo test --release`. O seletor de arquivos usa Zenity. `cargo fmt` organiza o código.

O código está em `src`. `tools/validate_ifc.py` usa IfcOpenShell para validar estrutura e reconstruir sólidos. `tools/build_manuals.py` requer ReportLab, Pillow e fontes DejaVu. As receitas Linux estão em `packaging` e `snap`; scripts de portabilidade em `packaging/windows` e `packaging/macos`.

A entrega de código usa uma lista explícita de arquivos públicos e não inclui caches, credenciais, histórico de conversa nem projetos particulares. A licença e a identificação do autor estão em `LICENSE`. Instaladores devem ser anexados a uma release; a publicação no GitHub não foi feita automaticamente.
