use super::*;
const EDGES: [&str; 6] = [
    "PVC 0,4 mm",
    "PVC 1 mm",
    "PVC 2 mm",
    "ABS 1 mm",
    "ABS 2 mm",
    "Outra",
];
#[derive(Clone, Debug)]
pub struct Settings {
    pub prices: [f32; 6],
    pub length_edges: u32,
    pub width_edges: u32,
    pub width: u32,
    pub length: u32,
    pub kerf: u32,
    pub margin: u32,
    pub path: String,
}
impl Default for Settings {
    fn default() -> Self {
        Self {
            prices: [0.; 6],
            length_edges: 1,
            width_edges: 0,
            width: 1850,
            length: 2750,
            kerf: 3,
            margin: 10,
            path: "plano-corte.csv".into(),
        }
    }
}
impl Settings {
    pub fn fields(&self) -> Vec<String> {
        let mut v = vec![
            "PRODUCTION".into(),
            self.length_edges.to_string(),
            self.width_edges.to_string(),
            self.width.to_string(),
            self.length.to_string(),
            self.kerf.to_string(),
            self.margin.to_string(),
        ];
        v.extend(self.prices.iter().map(|p| p.to_string()));
        v
    }
    pub fn parse(f: &[&str]) -> Result<Self, String> {
        let mut v = Self::default();
        v.length_edges = mar_num::<u32>(f, 1)?.min(2);
        v.width_edges = mar_num::<u32>(f, 2)?.min(2);
        v.width = mar_num::<u32>(f, 3)?.clamp(100, 10000);
        v.length = mar_num::<u32>(f, 4)?.clamp(100, 10000);
        v.kerf = mar_num::<u32>(f, 5)?.min(30);
        v.margin = mar_num::<u32>(f, 6)?.min(100);
        for i in 0..6 {
            v.prices[i] = mar_num::<f32>(f, 7 + i)?.max(0.);
        }
        Ok(v)
    }
}
pub fn has_edge(p: &Part) -> bool {
    let s = p.edge.to_lowercase();
    p.thickness_mm > 0 && !s.contains("sem fita") && s != "—" && s != ""
}
pub fn edge_m(p: &Part, s: &Settings) -> f32 {
    if has_edge(p) {
        (p.length_mm as f32 * s.length_edges as f32 + p.width_mm as f32 * s.width_edges as f32)
            * p.quantity as f32
            / 1000.
    } else {
        0.
    }
}
pub fn edge_cost(parts: &[Part], s: &Settings) -> f32 {
    parts
        .iter()
        .map(|p| {
            let index = EDGES.iter().position(|e| *e == p.edge).unwrap_or(5);
            edge_m(p, s) * s.prices[index]
        })
        .sum()
}
pub fn edge_editor(app: &mut FurnitureApp, ui: &mut egui::Ui) {
    ui.collapsing("Fita de borda · preços por metro", |ui| {
        ui.label(i18n::tr(
            "Preencha os preços de compra. Valor zero significa preço ainda não cadastrado.",
        ));
        for (i, name) in EDGES.iter().enumerate() {
            ui.horizontal(|ui| {
                ui.label(*name);
                ui.add(
                    egui::DragValue::new(&mut app.production.prices[i])
                        .speed(0.1)
                        .clamp_range(0.0..=1000.0)
                        .prefix("R$ ")
                        .suffix(" / m"),
                );
            });
        }
        ui.label(i18n::tr(
            "Critério global de fitamento das peças marcadas com fita:",
        ));
        property_field(
            ui,
            "Bordas do comprimento",
            &mut app.production.length_edges,
            0..=2,
        );
        property_field(
            ui,
            "Bordas da largura",
            &mut app.production.width_edges,
            0..=2,
        );
        ui.small(i18n::tr(
            "O mesmo critério vale para todas essas peças. Confira o fitamento antes de fabricar.",
        ));
        let p = app.parts();
        ui.label(format!(
            "Total: {:.2} m · R$ {:.2}",
            p.iter().map(|p| edge_m(p, &app.production)).sum::<f32>(),
            edge_cost(&p, &app.production)
        ));
    });
}
#[derive(Clone, Debug)]
pub struct Placement {
    pub part: usize,
    pub x: u32,
    pub y: u32,
    pub w: u32,
    pub h: u32,
    pub rotated: bool,
}
#[derive(Clone, Debug)]
pub struct Sheet {
    pub material: String,
    pub thickness: u32,
    pub pieces: Vec<Placement>,
    free: Vec<(u32, u32, u32, u32)>,
}
pub fn layout(
    parts: &[Part],
    s: &Settings,
    materials: &[MaterialData],
) -> (Vec<Sheet>, Vec<usize>) {
    let mut sheets: Vec<Sheet> = vec![];
    let mut rejected = vec![];
    let mut indices: Vec<_> = (0..parts.len())
        .filter(|i| parts[*i].thickness_mm > 0 && parts[*i].length_mm > 0 && parts[*i].width_mm > 0)
        .collect();
    indices
        .sort_by_key(|i| std::cmp::Reverse(parts[*i].length_mm as u64 * parts[*i].width_mm as u64));
    let sw = s.width.saturating_sub(2 * s.margin);
    let sh = s.length.saturating_sub(2 * s.margin);
    for i in indices {
        let p = &parts[i];
        let mat = materials
            .iter()
            .filter(|m| p.material == m.name || p.material.starts_with(&format!("{} ", m.name)))
            .max_by_key(|m| m.name.len());
        let grained = mat.map(|m| m.has_grain).unwrap_or(true);
        let (pw, ph) = if grained && p.grain == Grain::Width.label() {
            (p.length_mm, p.width_mm)
        } else {
            (p.width_mm, p.length_mm)
        };
        let candidates = if grained {
            vec![(pw, ph, false)]
        } else {
            vec![(pw, ph, false), (ph, pw, true)]
        };
        if !candidates.iter().any(|(w, h, _)| *w <= sw && *h <= sh) {
            rejected.push(i);
            continue;
        }
        for _ in 0..p.quantity.min(10000) {
            let mut best = None;
            for (si, sheet) in sheets.iter().enumerate().filter(|(_, sheet)| {
                sheet.material == p.material && sheet.thickness == p.thickness_mm
            }) {
                for (fi, (_, _, fw, fh)) in sheet.free.iter().enumerate() {
                    for &(w, h, rotated) in &candidates {
                        if w <= *fw && h <= *fh {
                            let waste = *fw as u64 * *fh as u64 - w as u64 * h as u64;
                            if best.map(|(_, _, _, _, _, old)| waste < old).unwrap_or(true) {
                                best = Some((si, fi, w, h, rotated, waste));
                            }
                        }
                    }
                }
            }
            if best.is_none() {
                let (w, h, r) = candidates
                    .iter()
                    .find(|(w, h, _)| *w <= sw && *h <= sh)
                    .copied()
                    .unwrap();
                sheets.push(Sheet {
                    material: p.material.clone(),
                    thickness: p.thickness_mm,
                    pieces: vec![],
                    free: vec![(s.margin, s.margin, sw, sh)],
                });
                best = Some((sheets.len() - 1, 0, w, h, r, 0));
            }
            let (si, fi, w, h, rotated, _) = best.unwrap();
            let sheet = &mut sheets[si];
            let (x, y, fw, fh) = sheet.free.remove(fi);
            sheet.pieces.push(Placement {
                part: i,
                x,
                y,
                w,
                h,
                rotated,
            });
            let rw = fw.saturating_sub(w + s.kerf);
            let bh = fh.saturating_sub(h + s.kerf);
            if rw > 0 {
                sheet.free.push((x + w + s.kerf, y, rw, h));
            }
            if bh > 0 {
                sheet.free.push((x, y + h + s.kerf, fw, bh));
            }
        }
    }
    (sheets, rejected)
}
pub fn csv(parts: &[Part], s: &Settings) -> String {
    let mut out=String::from("ID;Módulo;Peça;Quantidade;Comprimento_mm;Largura_mm;Espessura_mm;Material;Veio;Bordas_comprimento;Bordas_largura;Fita;Fita_m\r\n");
    for (i, p) in parts
        .iter()
        .enumerate()
        .filter(|(_, p)| p.thickness_mm > 0 && p.length_mm > 0 && p.width_mm > 0)
    {
        out.push_str(&format!(
            "{};{};{};{};{};{};{};{};{};{};{};{};{:.3}\r\n",
            i + 1,
            csv_escape(&p.group),
            csv_escape(&p.name),
            p.quantity,
            p.length_mm,
            p.width_mm,
            p.thickness_mm,
            csv_escape(&p.material),
            csv_escape(&p.grain),
            if has_edge(p) { s.length_edges } else { 0 },
            if has_edge(p) { s.width_edges } else { 0 },
            csv_escape(&p.edge),
            edge_m(p, s)
        ));
    }
    out
}
pub fn svg(sheet: &Sheet, parts: &[Part], s: &Settings) -> String {
    let mut out=format!("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {} {}'><rect width='100%' height='100%' fill='white'/><text x='10' y='40' font-size='28'>{} · {} mm · corte {} mm</text><g transform='translate(0,70)'><rect width='{}' height='{}' fill='#eee' stroke='#222'/>",s.width,s.length+70,xml_escape(&sheet.material),sheet.thickness,s.kerf,s.width,s.length);
    for p in &sheet.pieces {
        out.push_str(&format!("<rect x='{}' y='{}' width='{}' height='{}' fill='#d9bc94' stroke='#333'/><text x='{}' y='{}' font-size='20'>{}: {} × {}</text>",p.x,p.y,p.w,p.h,p.x+4,p.y+24,p.part+1,p.w,p.h));
    }
    out.push_str("</g></svg>");
    let _ = parts;
    out
}
pub fn editor(app: &mut FurnitureApp, ui: &mut egui::Ui) {
    ui.heading(i18n::tr("Plano de corte · chapas e exportação"));
    ui.label(i18n::tr("As peças de marcenaria vêm diretamente do projeto. Ferragens e decoração não entram nas chapas."));
    ui.horizontal_wrapped(|ui| {
        property_field(ui, "Chapa largura", &mut app.production.width, 100..=10000);
        property_field(
            ui,
            "Chapa comprimento",
            &mut app.production.length,
            100..=10000,
        );
        property_field(ui, "Serra", &mut app.production.kerf, 0..=20);
        property_field(ui, "Margem", &mut app.production.margin, 0..=100);
    });
    edge_editor(app, ui);
    let parts = app.parts();
    let (sheets, rejected) = layout(&parts, &app.production, &app.materials);
    ui.label(format!(
        "{} chapas · {} tipos de peças fora da chapa",
        sheets.len(),
        rejected.len()
    ));
    ui.small(i18n::tr("Distribuição heurística por cortes retangulares; não garante aproveitamento ótimo. Veio acompanha o comprimento da chapa. CSV genérico, sem compatibilidade presumida com VDMax Cut ou Cortecloud."));
    ui.horizontal(|ui| {
        ui.label(i18n::tr("Destino CSV"));
        ui.text_edit_singleline(&mut app.production.path);
        if ui.button(i18n::tr("Escolher destino")).clicked() {
            if let Ok(o) = Command::new("zenity")
                .args([
                    "--file-selection",
                    "--save",
                    "--confirm-overwrite",
                    "--filename=plano-corte.csv",
                ])
                .output()
            {
                if o.status.success() {
                    app.production.path = String::from_utf8_lossy(&o.stdout).trim().into();
                }
            }
        }
    });
    if ui
        .add_enabled(
            rejected.is_empty() && !sheets.is_empty(),
            egui::Button::new(i18n::tr("Exportar peças CSV e desenhos das chapas SVG")),
        )
        .clicked()
    {
        let path = Path::new(&app.production.path).with_extension("csv");
        let result = (|| -> io::Result<()> {
            fs::write(&path, csv(&parts, &app.production))?;
            for (i, sheet) in sheets.iter().enumerate() {
                let stem = path.file_stem().unwrap_or_default().to_string_lossy();
                let p = path.with_file_name(format!("{stem}-chapa-{:03}.svg", i + 1));
                fs::write(p, svg(sheet, &parts, &app.production))?;
            }
            Ok(())
        })();
        match result {
            Ok(()) => {
                app.notice = format!(
                    "Lista e {} desenhos de chapas salvos junto de {}",
                    sheets.len(),
                    path.display()
                );
                app.notice_error = false;
            }
            Err(e) => {
                app.notice = e.to_string();
                app.notice_error = true;
            }
        }
    }
    for i in rejected {
        ui.colored_label(
            Color32::DARK_RED,
            format!(
                "Não cabe: {} · {} × {} mm",
                parts[i].name, parts[i].length_mm, parts[i].width_mm
            ),
        );
    }
    ui.label(&app.notice);
    egui::ScrollArea::vertical().show(ui, |ui| {
        for (index, sheet) in sheets.iter().enumerate() {
            ui.heading(format!("Chapa {} · {}", index + 1, sheet.material));
            let scale = (ui.available_width().min(500.) / app.production.width as f32).min(0.18);
            let (r, _) = ui.allocate_exact_size(
                Vec2::new(app.production.width as f32, app.production.length as f32) * scale,
                Sense::hover(),
            );
            ui.painter().rect_filled(r, 0., Color32::from_gray(230));
            for p in &sheet.pieces {
                let rect = Rect::from_min_size(
                    r.min + Vec2::new(p.x as f32, p.y as f32) * scale,
                    Vec2::new(p.w as f32, p.h as f32) * scale,
                );
                ui.painter()
                    .rect_filled(rect, 0., Color32::from_rgb(212, 184, 146));
                ui.painter()
                    .rect_stroke(rect, 0., Stroke::new(1., Color32::DARK_GRAY));
                ui.painter().text(
                    rect.center(),
                    egui::Align2::CENTER_CENTER,
                    (p.part + 1).to_string(),
                    egui::FontId::proportional(11.),
                    Color32::BLACK,
                );
            }
        }
    });
}
