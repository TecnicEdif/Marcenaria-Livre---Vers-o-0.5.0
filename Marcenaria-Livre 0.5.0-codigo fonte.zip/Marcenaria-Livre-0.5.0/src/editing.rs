use super::*;

#[derive(Clone)]
pub struct Clipboard {
    snapshot: ProjectSnapshot,
    ids: Vec<u32>,
}
#[derive(Clone)]
pub struct Editor {
    pub selection: Vec<u32>,
    pub clipboard: Option<Clipboard>,
    pub array_open: bool,
    pub count: u32,
    pub step: [i32; 3],
    pub curve_middle: Option<P2>,
}
impl Default for Editor {
    fn default() -> Self {
        Self {
            selection: vec![],
            clipboard: None,
            array_open: false,
            count: 3,
            step: [1000, 0, 0],
            curve_middle: None,
        }
    }
}
pub fn id(s: Selection) -> u32 {
    match s {
        Selection::Module(i)
        | Selection::Wall(i)
        | Selection::Opening(i)
        | Selection::Panel(i)
        | Selection::Gesso(i)
        | Selection::Decor(i) => i,
    }
}
impl FurnitureApp {
    pub fn all_selections(&self) -> Vec<Selection> {
        self.modules
            .iter()
            .map(|o| Selection::Module(o.id))
            .chain(self.walls.iter().map(|o| Selection::Wall(o.id)))
            .chain(self.openings.iter().map(|o| Selection::Opening(o.id)))
            .chain(self.panels.iter().map(|o| Selection::Panel(o.id)))
            .chain(self.gesso.iter().map(|o| Selection::Gesso(o.id)))
            .chain(self.decor.iter().map(|o| Selection::Decor(o.id)))
            .collect()
    }
    pub fn selection_ids(&self) -> Vec<u32> {
        let mut ids = if self
            .selected
            .map(|s| self.editing.selection.contains(&id(s)))
            .unwrap_or(false)
        {
            self.editing.selection.clone()
        } else {
            vec![]
        };
        if let Some(s) = self.selected {
            if !ids.contains(&id(s)) {
                ids.push(id(s));
            }
        }
        ids
    }
    pub fn choose_selection(&mut self, s: Option<Selection>, add: bool) {
        if !add {
            self.editing.selection.clear();
        }
        self.selected = s;
        if let Some(s) = s {
            let i = id(s);
            let members = self
                .groups
                .iter()
                .find(|g| g.contains(&i))
                .cloned()
                .unwrap_or(vec![i]);
            if add && members.iter().all(|v| self.editing.selection.contains(v)) {
                self.editing.selection.retain(|v| !members.contains(v));
                self.selected = self
                    .all_selections()
                    .into_iter()
                    .find(|s| self.editing.selection.contains(&id(*s)));
            } else {
                for v in members {
                    if !self.editing.selection.contains(&v) {
                        self.editing.selection.push(v);
                    }
                }
            }
        }
    }
    pub fn select_all_objects(&mut self) {
        let hidden = self.effective_hidden();
        self.editing.selection = self
            .all_selections()
            .iter()
            .map(|s| id(*s))
            .filter(|i| !hidden.contains(i) && !self.object_locked(*i))
            .collect();
        self.selected = self
            .all_selections()
            .into_iter()
            .find(|s| self.editing.selection.contains(&id(*s)));
        self.notice = format!(
            "{} objetos selecionados · Ctrl+A",
            self.editing.selection.len()
        );
    }
    pub fn group_selection(&mut self) {
        let mut ids = self.selection_ids();
        ids.retain(|i| !self.object_locked(*i));
        for g in &self.groups {
            if g.iter().any(|i| ids.contains(i)) {
                for i in g {
                    if !ids.contains(i) {
                        ids.push(*i);
                    }
                }
            }
        }
        if ids.len() < 2 {
            self.notice = "Selecione dois ou mais objetos com Ctrl+clique.".into();
            return;
        }
        self.groups.retain(|g| !g.iter().any(|i| ids.contains(i)));
        self.groups.push(ids.clone());
        self.editing.selection = ids;
        self.notice = "Objetos agrupados · Ctrl+G · Shift+G desagrupa".into();
    }
    pub fn ungroup_selection(&mut self) {
        let ids = self.selection_ids();
        self.groups.retain(|g| !g.iter().any(|i| ids.contains(i)));
        self.notice = "Seleção desagrupada · Shift+G".into();
    }
    pub fn copy_selection(&mut self) {
        let mut ids = self.selection_ids();
        ids.retain(|i| !self.object_locked(*i));
        for o in &self.openings {
            if ids.contains(&o.wall_id) && !ids.contains(&o.id) {
                ids.push(o.id);
            }
        }
        if ids.is_empty() {
            self.notice = "Selecione objetos para copiar.".into();
            return;
        }
        self.editing.clipboard = Some(Clipboard {
            snapshot: self.project_snapshot(),
            ids,
        });
        self.notice = "Seleção copiada · Ctrl+V cola · Matriz define as distâncias".into();
    }
    pub fn paste_copies(&mut self, count: u32, step: [i32; 3]) {
        let Some(clip) = self.editing.clipboard.clone() else {
            self.notice = "Copie uma seleção primeiro (Ctrl+C).".into();
            return;
        };
        let before = self.project_snapshot();
        let mut selected = vec![];
        for k in 1..=count.min(200) {
            let delta = step.map(|s| s as i64 * k as i64);
            let mut map = std::collections::HashMap::new();
            for old in &clip.ids {
                map.insert(*old, self.next_id);
                self.next_id += 1;
            }
            let shift = |v: u32, axis: usize| -> Option<u32> {
                let n = v as i64 + delta[axis];
                if n < 0 || n > 1000000 {
                    None
                } else {
                    Some(n as u32)
                }
            };
            let result = (|| -> Option<()> {
                macro_rules! clone_xyz {
                    ($field:ident) => {
                        for original in clip
                            .snapshot
                            .$field
                            .iter()
                            .filter(|o| clip.ids.contains(&o.id))
                        {
                            let mut o = original.clone();
                            o.id = map[&o.id];
                            o.x_mm = shift(o.x_mm, 0)?;
                            o.y_mm = shift(o.y_mm, 1)?;
                            o.z_mm = shift(o.z_mm, 2)?;
                            self.$field.push(o);
                        }
                    };
                }
                clone_xyz!(modules);
                clone_xyz!(panels);
                clone_xyz!(decor);
                for original in clip
                    .snapshot
                    .walls
                    .iter()
                    .filter(|o| clip.ids.contains(&o.id))
                {
                    if delta[1] != 0 {
                        return None;
                    }
                    let mut o = original.clone();
                    o.id = map[&o.id];
                    for p in [&mut o.start, &mut o.end] {
                        p.x += delta[0] as f32;
                        p.z += delta[2] as f32;
                        if p.x < 0. || p.z < 0. {
                            return None;
                        }
                    }
                    self.walls.push(o);
                }
                for original in clip
                    .snapshot
                    .gesso
                    .iter()
                    .filter(|o| clip.ids.contains(&o.id))
                {
                    let mut o = original.clone();
                    o.id = map[&o.id];
                    o.x_mm = shift(o.x_mm, 0)?;
                    o.z_mm = shift(o.z_mm, 2)?;
                    let drop = o.drop_mm as i64 - delta[1];
                    if drop < 0 || drop > 1000000 {
                        return None;
                    }
                    o.drop_mm = drop as u32;
                    self.gesso.push(o);
                }
                for original in clip
                    .snapshot
                    .openings
                    .iter()
                    .filter(|o| clip.ids.contains(&o.id))
                {
                    let mut o = original.clone();
                    o.id = map[&o.id];
                    if let Some(host) = map.get(&o.wall_id) {
                        o.wall_id = *host;
                    } else {
                        let w = self.walls.iter().find(|w| w.id == o.wall_id)?;
                        let len = w.start.distance(w.end);
                        let along = (delta[0] as f32 * (w.end.x - w.start.x)
                            + delta[2] as f32 * (w.end.z - w.start.z))
                            / len;
                        let center = o.center_mm as f32 + along;
                        if center < o.width_mm as f32 / 2. || center + o.width_mm as f32 / 2. > len
                        {
                            return None;
                        }
                        o.center_mm = center.round() as u32;
                        o.sill_mm = shift(o.sill_mm, 1)?;
                    }
                    self.openings.push(o);
                }
                Some(())
            })();
            if result.is_none() {
                self.restore_edit_model(&before);
                self.notice="Cópia cancelada: posição fora dos limites ou deslocamento incompatível com a parede.".into();
                self.notice_error = true;
                return;
            }
            for group in &clip.snapshot.groups {
                let g: Vec<u32> = group.iter().filter_map(|i| map.get(i).copied()).collect();
                if g.len() > 1 {
                    self.groups.push(g);
                }
            }
            selected.extend(map.values().copied());
        }
        self.enforce_layer_locks(&before);
        self.enforce_collisions(&before);
        let existing: Vec<_> = self.all_selections().into_iter().map(id).collect();
        selected.retain(|i| existing.contains(i));
        if selected.is_empty() {
            return;
        }
        self.editing.selection = selected;
        self.selected = self
            .all_selections()
            .into_iter()
            .find(|s| self.editing.selection.contains(&id(*s)));
        self.notice = format!("{} cópia(s) criada(s).", count);
        self.notice_error = false;
    }
    pub fn restore_edit_model(&mut self, s: &ProjectSnapshot) {
        self.modules = s.modules.clone();
        self.walls = s.walls.clone();
        self.openings = s.openings.clone();
        self.panels = s.panels.clone();
        self.gesso = s.gesso.clone();
        self.decor = s.decor.clone();
        self.groups = s.groups.clone();
        self.next_id = s.next_id;
        self.editing.selection.clear();
        self.selected = None;
    }
    pub fn array_editor(&mut self, ctx: &egui::Context) {
        let mut open = self.editing.array_open;
        egui::Window::new("Matriz de objetos — múltiplas cópias").open(&mut open).default_width(440.).show(ctx,|ui|{ui.spacing_mut().interact_size.y=38.;ui.label("Selecione os objetos; defina a quantidade adicional e o deslocamento entre cópias, em milímetros.");property_field(ui,"Cópias adicionais",&mut self.editing.count,1..=200);for (axis,label) in ["X • horizontal","Y • altura","Z • profundidade"].iter().enumerate(){ui.horizontal(|ui|{ui.label(*label);ui.add(egui::DragValue::new(&mut self.editing.step[axis]).clamp_range(-100000..=100000).suffix(" mm"));});}if ui.button("Criar matriz da seleção").clicked(){self.copy_selection();self.paste_copies(self.editing.count,self.editing.step);}ui.label(&self.notice);});
        self.editing.array_open = open;
    }
    pub fn curve_click(&mut self, p: P2) {
        match (self.pending_point, self.editing.curve_middle) {
            (None, _) => {
                self.pending_point = Some(p);
                self.notice = "Parede curva: clique no ponto intermediário do arco.".into();
            }
            (Some(_), None) => {
                self.editing.curve_middle = Some(p);
                self.notice = "Parede curva: clique no final do arco.".into();
            }
            (Some(a), Some(b)) => {
                if let Some(points) = arc_points(a, b, p) {
                    let mut ids = vec![];
                    for pair in points.windows(2) {
                        let id = self.next_id;
                        self.next_id += 1;
                        self.walls.push(Wall {
                            material: "Pintura branca".into(),
                            color: Color32::from_rgb(220, 221, 218),
                            id,
                            start: pair[0],
                            end: pair[1],
                            thickness_mm: self.wall_thickness,
                            height_mm: self.room[1],
                        });
                        ids.push(id);
                    }
                    self.groups.push(ids);
                    self.notice =
                        "Parede curva criada por três pontos. Seus trechos estão agrupados.".into();
                    self.pending_point = None;
                    self.editing.curve_middle = None;
                } else {
                    self.notice =
                        "Os três pontos precisam formar um arco; evite pontos alinhados.".into();
                }
            }
        }
    }
}
/// Circular arc through three points; no chord exceeds 2 degrees.
pub fn arc_points(a: P2, b: P2, c: P2) -> Option<Vec<P2>> {
    let d = 2. * (a.x * (b.z - c.z) + b.x * (c.z - a.z) + c.x * (a.z - b.z));
    if d.abs() < 1. {
        return None;
    }
    let q = |p: P2| p.x * p.x + p.z * p.z;
    let center = P2::new(
        (q(a) * (b.z - c.z) + q(b) * (c.z - a.z) + q(c) * (a.z - b.z)) / d,
        (q(a) * (c.x - b.x) + q(b) * (a.x - c.x) + q(c) * (b.x - a.x)) / d,
    );
    let r = center.distance(a);
    if !r.is_finite() || r > 1000000. {
        return None;
    }
    let angle = |p: P2| (p.z - center.z).atan2(p.x - center.x);
    let tau = std::f32::consts::TAU;
    let end = (angle(c) - angle(a)).rem_euclid(tau);
    let mid = (angle(b) - angle(a)).rem_euclid(tau);
    let sweep = if mid < end { end } else { end - tau };
    let steps = (sweep.abs().to_degrees() / 2.).ceil().max(2.) as usize;
    Some(
        (0..=steps)
            .map(|i| {
                let t = angle(a) + sweep * i as f32 / steps as f32;
                P2::new(center.x + r * t.cos(), center.z + r * t.sin())
            })
            .collect(),
    )
}

impl FurnitureApp {
    pub fn edit_menu(&mut self, ui: &mut egui::Ui) {
        ui.menu_button("Editar", |ui| {
            for (label, command) in [
                ("Copiar · Ctrl+C", 0),
                ("Colar · Ctrl+V", 1),
                ("Selecionar todos · Ctrl+A", 2),
                ("Agrupar · Ctrl+G", 3),
                ("Desagrupar · Shift+G", 4),
                ("Matriz de objetos…", 5),
            ] {
                if ui
                    .add_sized([240., 36.], egui::Button::new(label))
                    .clicked()
                {
                    match command {
                        0 => self.copy_selection(),
                        1 => self.paste_copies(1, [1000, 0, 0]),
                        2 => self.select_all_objects(),
                        3 => self.group_selection(),
                        4 => self.ungroup_selection(),
                        _ => self.editing.array_open = true,
                    }
                    ui.close_menu();
                }
            }
        });
    }
    fn object_locked(&self, id: u32) -> bool {
        self.all_selections()
            .into_iter()
            .find(|s| editing::id(*s) == id)
            .map(|s| match s {
                Selection::Wall(i) => {
                    self.layers.locked[0]
                        || self.openings.iter().any(|o| {
                            o.wall_id == i
                                && self.layers.locked
                                    [if o.kind == OpeningKind::Window { 3 } else { 4 }]
                        })
                }
                Selection::Gesso(_) => self.layers.locked[1],
                Selection::Opening(i) => {
                    self.layers.locked[0]
                        || self
                            .openings
                            .iter()
                            .find(|o| o.id == i)
                            .map(|o| {
                                self.layers.locked
                                    [if o.kind == OpeningKind::Window { 3 } else { 4 }]
                            })
                            .unwrap_or(true)
                }
                Selection::Module(_) | Selection::Panel(_) => self.layers.locked[5],
                Selection::Decor(_) => self.layers.locked[6],
            })
            .unwrap_or(true)
    }
    pub fn delete_selected(&mut self) {
        let ids = self.selection_ids();
        let selections = self.all_selections();
        for s in selections {
            if ids.contains(&id(s)) && !self.object_locked(id(s)) {
                self.selected = Some(s);
                self.delete_single_selected();
            }
        }
        let existing: Vec<_> = self.all_selections().into_iter().map(id).collect();
        for g in &mut self.groups {
            g.retain(|i| existing.contains(i));
        }
        self.groups.retain(|g| g.len() > 1);
        self.hidden_ids.retain(|i| existing.contains(i));
        self.editing.selection.clear();
        self.selected = None;
    }
    pub fn follow_group_translation(&mut self, before: &ProjectSnapshot) {
        let Some(primary) = self.selected.map(id) else {
            return;
        };
        let ids = self.selection_ids();
        if ids.len() < 2 {
            return;
        }
        let position = |s: &ProjectSnapshot, id: u32| -> Option<[i64; 3]> {
            if let Some(m) = s.modules.iter().find(|m| m.id == id) {
                return Some([m.x_mm as i64, m.y_mm as i64, m.z_mm as i64]);
            }
            if let Some(m) = s.decor.iter().find(|m| m.id == id) {
                return Some([m.x_mm as i64, m.y_mm as i64, m.z_mm as i64]);
            }
            if let Some(m) = s.panels.iter().find(|m| m.id == id) {
                return Some([m.x_mm as i64, m.y_mm as i64, m.z_mm as i64]);
            }
            None
        };
        let now = self.project_snapshot();
        let (Some(a), Some(b)) = (position(before, primary), position(&now, primary)) else {
            return;
        };
        let delta = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
        if delta == [0, 0, 0] {
            return;
        }
        if ids.iter().any(|i| self.object_locked(*i)) {
            self.restore_edit_model(before);
            self.notice = "O grupo contém uma camada bloqueada.".into();
            return;
        }
        let shift = |v: u32, axis: usize| -> Option<u32> {
            let n = v as i64 + delta[axis];
            if (0..=1000000).contains(&n) {
                Some(n as u32)
            } else {
                None
            }
        };
        let ok = (|| -> Option<()> {
            macro_rules! move_items {
                ($field:ident) => {
                    for o in self
                        .$field
                        .iter_mut()
                        .filter(|o| o.id != primary && ids.contains(&o.id))
                    {
                        o.x_mm = shift(o.x_mm, 0)?;
                        o.y_mm = shift(o.y_mm, 1)?;
                        o.z_mm = shift(o.z_mm, 2)?;
                    }
                };
            }
            move_items!(modules);
            move_items!(panels);
            move_items!(decor);
            for w in self.walls.iter_mut().filter(|w| ids.contains(&w.id)) {
                if delta[1] != 0 {
                    return None;
                }
                for p in [&mut w.start, &mut w.end] {
                    p.x += delta[0] as f32;
                    p.z += delta[2] as f32;
                    if p.x < 0. || p.z < 0. {
                        return None;
                    }
                }
            }
            for g in self.gesso.iter_mut().filter(|g| ids.contains(&g.id)) {
                g.x_mm = shift(g.x_mm, 0)?;
                g.z_mm = shift(g.z_mm, 2)?;
                let drop = g.drop_mm as i64 - delta[1];
                if drop < 0 {
                    return None;
                }
                g.drop_mm = drop as u32;
            }
            for o in self
                .openings
                .iter_mut()
                .filter(|o| ids.contains(&o.id) && !ids.contains(&o.wall_id))
            {
                let w = self.walls.iter().find(|w| w.id == o.wall_id)?;
                let len = w.start.distance(w.end);
                let along = (delta[0] as f32 * (w.end.x - w.start.x)
                    + delta[2] as f32 * (w.end.z - w.start.z))
                    / len;
                let center = o.center_mm as f32 + along;
                if center < o.width_mm as f32 / 2. || center + o.width_mm as f32 / 2. > len {
                    return None;
                }
                o.center_mm = center.round() as u32;
                o.sill_mm = shift(o.sill_mm, 1)?;
            }
            Some(())
        })();
        if ok.is_none() {
            self.restore_edit_model(before);
            self.notice = "Grupo fora dos limites; movimento cancelado.".into();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn groups_survive_save_and_undo() {
        let mut a = FurnitureApp::default();
        a.editing.selection = vec![1, 2];
        a.track_history();
        a.group_selection();
        a.track_history();
        assert_eq!(
            parse_mar_project(&project_to_mar(&a)).unwrap().groups,
            vec![vec![1, 2]]
        );
        a.undo_action();
        assert!(a.groups.is_empty());
    }
    #[test]
    fn copies_have_new_ids_and_relative_spacing() {
        let mut a = FurnitureApp::default();
        a.modules.truncate(1);
        a.walls.clear();
        a.selected = Some(Selection::Module(1));
        a.copy_selection();
        let original = a.modules[0].x_mm;
        a.paste_copies(3, [1500, 0, 0]);
        assert_eq!(a.modules.len(), 4);
        for (k, m) in a.modules.iter().enumerate() {
            assert_eq!(m.x_mm, original + k as u32 * 1500);
        }
        let mut ids: Vec<_> = a.modules.iter().map(|m| m.id).collect();
        ids.sort();
        ids.dedup();
        assert_eq!(ids.len(), 4);
    }
    #[test]
    fn copy_wall_remaps_opening_host() {
        let mut a = FurnitureApp::default();
        let w = a.walls[0].clone();
        a.openings.push(Opening {
            id: 200,
            wall_id: w.id,
            kind: OpeningKind::Window,
            center_mm: 1000,
            width_mm: 500,
            height_mm: 500,
            sill_mm: 1000,
            style: "Vidro".into(),
            material: "Vidro".into(),
        });
        a.selected = Some(Selection::Wall(w.id));
        a.copy_selection();
        a.paste_copies(1, [5000, 0, 0]);
        assert_ne!(a.openings[1].wall_id, w.id);
        assert!(a.walls.iter().any(|w| w.id == a.openings[1].wall_id));
    }
    #[test]
    fn selection_excludes_locked_and_hidden() {
        let mut a = FurnitureApp::default();
        a.layers.locked[5] = true;
        a.layers.visible[0] = false;
        a.select_all_objects();
        assert!(a.selection_ids().is_empty());
    }
    #[test]
    fn arc_passes_three_points() {
        let a = P2::new(1000., 0.);
        let b = P2::new(0., 1000.);
        let c = P2::new(-1000., 0.);
        let pts = arc_points(a, b, c).unwrap();
        assert!(pts.len() >= 91);
        assert!(pts[0].distance(a) < 0.01);
        assert!(pts.last().unwrap().distance(c) < 0.01);
        assert!(pts.iter().any(|p| p.distance(b) < 0.1));
    }
    #[test]
    fn no_top_has_no_top_board() {
        let mut a = FurnitureApp::default();
        a.modules[0].top_mode = 1;
        assert!(!fabrication::parts(&a, &a.modules[0])
            .iter()
            .any(|p| p.name == "Tampo estrutural"));
        a.modules[0].top_mode = 2;
        assert_eq!(
            fabrication::parts(&a, &a.modules[0])
                .iter()
                .find(|p| p.name == "Travessa superior")
                .unwrap()
                .quantity,
            2
        );
    }
    #[test]
    fn internal_drawers_keep_doors_and_shelves() {
        let a = FurnitureApp::default();
        let mut m = a.modules[0].clone();
        m.drawer_count = 2;
        m.shelf_count = 3;
        let p = fabrication::parts(&a, &m);
        assert!(p.iter().any(|p| p.name == "Porta"));
        assert!(p.iter().any(|p| p.name == "Prateleira" && p.quantity == 3));
        assert!(p
            .iter()
            .any(|p| p.name == "Lateral de gaveta" && p.quantity == 4));
        assert!(fabrication::hardware(&a, &m)
            .iter()
            .any(|p| p.name == "Par de corrediças telescópicas" && p.quantity == 2));
    }
    #[test]
    fn added_libraries_have_requested_counts() {
        assert_eq!(extra_presets(CatalogTab::Kitchen).len(), 25);
        assert_eq!(extra_presets(CatalogTab::Bathroom).len(), 15);
        assert_eq!(extra_presets(CatalogTab::Office).len(), 20);
    }
}
impl FurnitureApp {
    pub fn selection_outlines(&self) -> Vec<Vec<V3>> {
        let ids = self.selection_ids();
        let hidden = self.effective_hidden();
        let mut lines = vec![];
        for m in self
            .modules
            .iter()
            .filter(|m| ids.contains(&m.id) && !hidden.contains(&m.id))
        {
            let pts = module_corners(m);
            for y in [m.y_mm, m.y_mm + m.height_mm] {
                let mut edge: Vec<_> = pts.iter().map(|p| V3::new(p.x, y as f32, p.z)).collect();
                edge.push(edge[0]);
                lines.push(edge);
            }
            for p in pts {
                lines.push(vec![
                    V3::new(p.x, m.y_mm as f32, p.z),
                    V3::new(p.x, (m.y_mm + m.height_mm) as f32, p.z),
                ]);
            }
        }
        for w in self
            .walls
            .iter()
            .filter(|w| ids.contains(&w.id) && !hidden.contains(&w.id))
        {
            lines.push(vec![
                V3::new(w.start.x, 0., w.start.z),
                V3::new(w.end.x, 0., w.end.z),
                V3::new(w.end.x, w.height_mm as f32, w.end.z),
                V3::new(w.start.x, w.height_mm as f32, w.start.z),
                V3::new(w.start.x, 0., w.start.z),
            ]);
        }
        for d in self
            .decor
            .iter()
            .filter(|d| ids.contains(&d.id) && !hidden.contains(&d.id))
        {
            for y in [d.y_mm, d.y_mm + d.height_mm] {
                let mut edge: Vec<_> = geometry::footprint(d)
                    .into_iter()
                    .map(|p| V3::new(p.x, y as f32, p.z))
                    .collect();
                edge.push(edge[0]);
                lines.push(edge);
            }
        }
        for b in self
            .panels
            .iter()
            .filter(|b| ids.contains(&b.id) && !hidden.contains(&b.id))
        {
            let pts = automation::corners(b);
            let mut edge: Vec<_> = pts
                .iter()
                .map(|p| V3::new(p.x, b.y_mm as f32, p.z))
                .collect();
            edge.push(edge[0]);
            lines.push(edge);
        }
        lines
    }
    pub fn highlight_scene_selection(&self, p: &egui::Painter, rect: Rect) {
        for line in self.selection_outlines() {
            for pair in line.windows(2) {
                if let (Some(a), Some(b)) = (
                    self.camera.project(pair[0], rect),
                    self.camera.project(pair[1], rect),
                ) {
                    p.line_segment([a.0, b.0], Stroke::new(2., Color32::from_rgb(0, 135, 180)));
                }
            }
        }
    }
    pub fn highlight_plan_selection(&self, p: &egui::Painter, tr: PlanTransform) {
        for line in self.selection_outlines() {
            for pair in line.windows(2) {
                p.line_segment(
                    [
                        tr.screen(P2::new(pair[0].x, pair[0].z)),
                        tr.screen(P2::new(pair[1].x, pair[1].z)),
                    ],
                    Stroke::new(2., Color32::from_rgb(0, 135, 180)),
                );
            }
        }
    }
}
#[cfg(test)]
mod validation05 {
    use super::*;
    #[test]
    fn rotated_decor_and_polygon_survive_mar() {
        let mut a = FurnitureApp::default();
        a.add_decor("Teste", 300, 200, 400, Color32::WHITE);
        a.decor[0].rotation_deg = 35.;
        a.decor[0].outline = vec![P2::new(0., 0.), P2::new(1., 0.), P2::new(0., 1.)];
        let p = parse_mar_project(&project_to_mar(&a)).unwrap();
        assert_eq!(p.decor[0].rotation_deg, 35.);
        assert_eq!(p.decor[0].outline.len(), 3);
    }
    #[test]
    fn invalid_array_is_atomic() {
        let mut a = FurnitureApp::default();
        a.modules.truncate(1);
        a.walls.clear();
        a.selected = Some(Selection::Module(1));
        a.copy_selection();
        let before = a.project_snapshot();
        a.paste_copies(3, [-100000, 0, 0]);
        assert_eq!(a.modules.len(), before.modules.len());
        assert_eq!(a.next_id, before.next_id);
    }
    #[test]
    fn locked_opening_protects_its_wall() {
        let mut a = FurnitureApp::default();
        let id = a.walls[0].id;
        a.openings.push(Opening {
            id: 900,
            wall_id: id,
            kind: OpeningKind::Window,
            center_mm: 800,
            width_mm: 400,
            height_mm: 400,
            sill_mm: 1000,
            style: "Fixa".into(),
            material: "Vidro".into(),
        });
        a.layers.locked[3] = true;
        a.selected = Some(Selection::Wall(id));
        a.delete_selected();
        assert!(a.walls.iter().any(|w| w.id == id));
        assert_eq!(a.openings.len(), 1);
    }
    #[test]
    fn decorative_catalog_has_700_choices() {
        assert_eq!(decor_presets().len(), 700);
        assert_eq!(designers::extra_decor().len(), 200);
    }
    #[test]
    fn software_render_large_scene() {
        let mut a = FurnitureApp::default();
        a.modules.clear();
        a.walls.clear();
        for i in 0..100 {
            a.modules.push(make_module(
                i + 1,
                preset("Benchmark", ModuleKind::Base, 600, 720, 550, 0, 2, 1, 0),
                (i % 10) * 800,
                (i / 10) * 800,
            ));
        }
        a.room = [9000, 2700, 9000];
        a.camera = Camera::reset(a.room);
        a.camera.distance = 18000.;
        let f = scene_faces(
            a.camera,
            a.room,
            &a.walls,
            &a.openings,
            &a.modules,
            &[],
            &[],
            &[],
            &a.materials,
            &[],
            "Cimento claro",
        );
        let start = std::time::Instant::now();
        let image = visual::image(&f, a.camera, [480, 320], RenderMode::Colors);
        println!(
            "100 módulos, {} faces, imagem 480x320: {:?}",
            f.len(),
            start.elapsed()
        );
        assert_eq!(image.pixels.len(), 480 * 320);
    }
}
