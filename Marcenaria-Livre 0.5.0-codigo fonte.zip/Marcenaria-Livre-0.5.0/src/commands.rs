use super::*;
const TOOLS: [(Tool, &str); 12] = [
    (Tool::Select, "Selecionar"),
    (Tool::Move, "Mover"),
    (Tool::Wall, "Parede reta"),
    (Tool::WallChain, "Parede contínua"),
    (Tool::WallCurve, "Parede curva"),
    (Tool::Door, "Porta"),
    (Tool::Window, "Janela"),
    (Tool::Gesso, "Gesso"),
    (Tool::Panel, "Painel"),
    (Tool::CopyMaterial, "Copiar material"),
    (Tool::PaintMaterial, "Pintar material"),
    (Tool::WallAnchor, "Parede de fundo"),
];
pub fn defaults() -> [egui::Key; 12] {
    use egui::Key::*;
    [A, B, C, D, E, F, G, H, I, J, K, L]
}
pub fn handle(app: &mut FurnitureApp, ctx: &egui::Context) {
    if ctx.wants_keyboard_input() {
        return;
    }
    if ctx.input(|i| i.modifiers.ctrl && !i.modifiers.alt) {
        if ctx.input(|i| i.key_pressed(egui::Key::A)) {
            app.select_all_objects();
        }
        if ctx.input(|i| i.key_pressed(egui::Key::G)) {
            app.group_selection();
        }
        if ctx.input(|i| {
            i.key_pressed(egui::Key::C) || i.events.iter().any(|e| matches!(e, egui::Event::Copy))
        }) {
            app.copy_selection();
        }
        if ctx.input(|i| {
            i.key_pressed(egui::Key::V)
                || i.events.iter().any(|e| matches!(e, egui::Event::Paste(_)))
        }) {
            app.paste_copies(1, [1000, 0, 0]);
        }
    }
    if ctx.input(|i| i.modifiers.shift && !i.modifiers.ctrl && i.key_pressed(egui::Key::G)) {
        app.ungroup_selection();
    }
    if ctx.input(|i| i.modifiers.ctrl && i.modifiers.alt) {
        for (index, (tool, name)) in TOOLS.iter().enumerate() {
            if ctx.input(|i| i.key_pressed(app.tool_keys[index])) {
                app.set_tool(*tool);
                app.notice = format!("{} · Ctrl+Alt+{}", name, key_label(app.tool_keys[index]));
                break;
            }
        }
    }
    if ctx.input(|i| i.modifiers.ctrl && !i.modifiers.alt && i.key_pressed(egui::Key::S)) {
        app.save_project_action();
    }
    if ctx.input(|i| i.modifiers.ctrl && !i.modifiers.alt && i.key_pressed(egui::Key::O)) {
        app.choose_project_path(false);
    }
    if ctx.input(|i| i.key_pressed(egui::Key::F12)) {
        app.page = Page::Method;
    }
    if ctx.input(|i| i.key_pressed(egui::Key::F8)) {
        app.page = Page::Documentation;
    }
    if ctx.input(|i| i.key_pressed(egui::Key::F9)) {
        app.page = Page::Automation;
    }
}
pub fn settings(app: &mut FurnitureApp, ui: &mut egui::Ui) {
    ui.collapsing("⌨ Atalhos de todas as ferramentas · Ctrl + Alt + tecla",|ui|{
  let old=app.tool_keys;let mut changed=None;
  egui::Grid::new("all_tool_keys").num_columns(2).show(ui,|ui|{for (i,(_,name)) in TOOLS.iter().enumerate(){ui.label(*name);egui::ComboBox::from_id_source(("tool_key",i)).selected_text(key_label(app.tool_keys[i])).show_ui(ui,|ui|{for (key,label) in shortcut_keys(){if ui.selectable_value(&mut app.tool_keys[i],*key,*label).changed(){changed=Some(i);}}});ui.end_row();}});
  if let Some(i)=changed{for j in 0..12{if j!=i&&app.tool_keys[j]==app.tool_keys[i]{app.tool_keys[j]=old[i];}}app.save_preferences();}
  ui.label(i18n::tr("F8: Pranchas · F9: Automatizações · F12: Método construtivo · Ctrl+S: Salvar · Ctrl+O: Abrir · Esc: Cancelar · Delete: Excluir"));
 });
}
