use super::*;
#[test]
fn native_file_preserves_sheet_method_and_automations() {
    let mut app = FurnitureApp::default();
    app.sheet_options.revision = "R|02".into();
    app.sheet_options.notes = "Texto < & revisão".into();
    app.sheet_views[0].kind = ViewKind::Front;
    app.sheet_views[0].offset_x = 7.0;
    app.fabrication.back_overlap = 8;
    app.automation.thickness = 25;
    app.modules[0].divider_count = 2;
    app.run_automation("Tampo");
    let parsed = parse_mar_project(&project_to_mar(&app)).unwrap();
    assert_eq!(parsed.sheet_options.revision, "R|02");
    assert_eq!(parsed.sheet_views[0].kind, ViewKind::Front);
    assert_eq!(parsed.sheet_views[0].offset_x, 7.0);
    assert_eq!(parsed.fabrication.back_overlap, 8);
    assert_eq!(parsed.automation.thickness, 25);
    assert_eq!(parsed.modules[0].divider_count, 2);
    assert!(parsed.panels[0].horizontal);
}
#[test]
fn fabrication_accounts_for_back_overlap_and_front_gaps() {
    let app = FurnitureApp::default();
    let m = &app.modules[0];
    let parts = fabrication::parts(&app, m);
    let back = parts.iter().find(|p| p.name == "Fundo").unwrap();
    assert_eq!((back.width_mm, back.length_mm), (784, 704));
    let front = parts.iter().find(|p| p.name == "Porta").unwrap();
    assert_eq!(front.width_mm, 395);
    let shelf = parts.iter().find(|p| p.name == "Prateleira").unwrap();
    assert_eq!(shelf.width_mm, 512);
}
#[test]
fn drawer_parts_include_box_and_one_slide_pair_per_drawer() {
    let app = FurnitureApp::default();
    let m = make_module(
        1,
        preset("Gaveteiro", ModuleKind::Drawer, 600, 720, 550, 100, 0, 0, 3),
        0,
        0,
    );
    assert_eq!(
        fabrication::parts(&app, &m)
            .iter()
            .find(|p| p.name == "Lateral de gaveta")
            .unwrap()
            .quantity,
        6
    );
    assert_eq!(
        hardware_for_module(&m)
            .iter()
            .find(|p| p.name == "Par de corrediças telescópicas")
            .unwrap()
            .quantity,
        3
    );
}
#[test]
fn updates_automation_in_place_and_respects_module_rotation() {
    let mut app = FurnitureApp::default();
    app.modules[0].x_mm = 1000;
    app.modules[0].z_mm = 1000;
    app.modules[0].rotation_deg = 90.0;
    app.run_automation("Tampo");
    let id = app.panels[0].id;
    assert_eq!(app.panels[0].rotation_deg, 90.0);
    app.automation.thickness = 30;
    app.run_automation("Tampo");
    assert_eq!(app.panels.len(), 1);
    assert_eq!(app.panels[0].id, id);
    assert_eq!(app.panels[0].thickness_mm, 30);
}
#[test]
fn portrait_sheet_keeps_upright_text_and_physical_size() {
    let mut app = FurnitureApp::default();
    app.sheet_landscape = false;
    app.sheet_title = "A&B <teste>".into();
    app.sheet_views[0].kind = ViewKind::Side;
    let svg = sheet_svg(&app);
    assert!(svg.contains("width='210mm' height='297mm'"));
    assert!(!svg.contains("rotate(90)"));
    assert!(svg.contains("A&amp;B &lt;teste&gt;"));
    assert!(svg.contains("Elevação lateral"));
}
#[test]
fn selected_component_material_application_does_not_change_body() {
    let mut app = FurnitureApp::default();
    let original = app.modules[0].material.clone();
    app.material_target = 2;
    app.apply_material_to(Selection::Module(1), "Grafite fosco");
    assert_eq!(app.modules[0].material, original);
    assert_eq!(app.modules[0].door_material, "Grafite fosco");
}
#[test]
fn old_project_without_new_records_still_opens() {
    let p = parse_mar_project("MARCENARIA_LIVRE|1\nROOM|4200|2700|3200\nVIEW|Plan|16|18|168|128\n")
        .unwrap();
    assert_eq!(p.sheet_views[0].offset_x, 0.0);
    assert_eq!(p.fabrication.back_overlap, 10);
}

#[test]
fn pdf_has_physical_a4_and_extra_table_pages() {
    let mut app = FurnitureApp::default();
    app.sheet_options.table = true;
    let original = app.modules[0].clone();
    for id in 100..160 {
        let mut m = original.clone();
        m.id = id;
        app.modules.push(m);
    }
    let pdf = documentation::pdf(&app);
    let text = String::from_utf8_lossy(&pdf);
    assert!(text.starts_with("%PDF-1.4"));
    assert!(text.contains("/Count 4"));
    assert!(text.contains("xref"));
    assert!(text.ends_with("%%EOF\n"));
}
#[test]
fn orthographic_projection_does_not_change_size_with_depth() {
    let mut camera = Camera::reset([4200, 2700, 3200]);
    camera.projection = Projection::Orthographic;
    let r = Rect::from_min_size(Pos2::ZERO, Vec2::splat(800.0));
    let p = V3::new(200.0, 200.0, 200.0);
    let q = camera.project_polygon(
        &[
            p,
            p.add(V3::new(100.0, 0.0, 0.0)),
            p.add(V3::new(0.0, 100.0, 0.0)),
        ],
        r,
    );
    assert_eq!(q[0], camera.project(p, r).unwrap().0);
}

#[test]
fn wall_snap_is_independent_of_wall_drawing_direction() {
    let room = [4200, 2700, 3200];
    for (start, end) in [
        (P2::new(0.0, 0.0), P2::new(0.0, 3200.0)),
        (P2::new(0.0, 3200.0), P2::new(0.0, 0.0)),
    ] {
        let wall = Wall {
            material: "Pintura branca".into(),
            color: Color32::from_rgb(220, 221, 218),
            id: 1,
            start,
            end,
            thickness_mm: 150,
            height_mm: 2700,
        };
        let mut m = make_module(
            1,
            preset("Teste", ModuleKind::Base, 800, 720, 550, 0, 2, 1, 0),
            100,
            1000,
        );
        snap_module_to_wall_target(&mut m, &[wall], room, Some(1));
        let c = module_corners(&m);
        let minx = c.iter().map(|p| p.x).fold(f32::INFINITY, f32::min);
        assert!((minx - 75.0).abs() < 1.0);
        assert!(c.iter().all(|p| p.z >= 0.0 && p.z <= 3200.0));
    }
}

#[test]
fn manual_dimensions_survive_native_roundtrip() {
    let mut app = FurnitureApp::default();
    app.sheet_options.dimensions.push(documentation::Dimension {
        view: 0,
        a: Pos2::new(100., 100.),
        b: Pos2::new(900., 100.),
        offset: 7.,
    });
    let p = parse_mar_project(&project_to_mar(&app)).unwrap();
    assert_eq!(p.sheet_options.dimensions.len(), 1);
    assert_eq!(
        p.sheet_options.dimensions[0]
            .a
            .distance(p.sheet_options.dimensions[0].b),
        800.
    );
    assert_eq!(p.sheet_options.dimensions[0].offset, 7.);
}
#[test]
fn near_camera_geometry_is_not_discarded_at_800mm() {
    let c = Camera {
        target: V3::new(0., 0., 0.),
        yaw: 0.,
        pitch: 0.,
        distance: 500.,
        projection: Projection::Perspective,
    };
    let r = Rect::from_min_size(Pos2::ZERO, Vec2::splat(100.));
    assert!(c.project(V3::new(0., 0., 0.), r).is_some());
    assert_eq!(
        c.project_polygon(
            &[
                V3::new(-10., -10., 0.),
                V3::new(10., -10., 0.),
                V3::new(10., 10., 0.)
            ],
            r
        )
        .len(),
        3
    );
}
#[test]
fn depth_renderer_is_independent_of_face_order() {
    let c = Camera {
        target: V3::new(0., 0., 0.),
        yaw: 0.,
        pitch: 0.,
        distance: 1000.,
        projection: Projection::Perspective,
    };
    let mut faces = vec![];
    for (z, color) in [(0., Color32::RED), (300., Color32::GREEN)] {
        face(
            &mut faces,
            c,
            [
                V3::new(-30., -30., z),
                V3::new(30., -30., z),
                V3::new(30., 30., z),
                V3::new(-30., 30., z),
            ],
            color,
        );
    }
    let a = visual::image(&faces, c, [64, 64], RenderMode::Colors);
    faces.reverse();
    let b = visual::image(&faces, c, [64, 64], RenderMode::Colors);
    assert_eq!(a.pixels, b.pixels);
    assert_eq!(a.pixels[32 * 64 + 32], Color32::GREEN);
}
#[test]
fn handles_and_edge_prices_are_saved() {
    let mut app = FurnitureApp::default();
    app.modules[0].handles = vec![fronts::Handle {
        position: 1,
        vertical: false,
        length: 192,
        inset: 35,
        enabled: true,
        ..fronts::Handle::default()
    }];
    app.production.prices[1] = 4.5;
    let p = parse_mar_project(&project_to_mar(&app)).unwrap();
    assert_eq!(p.modules[0].handles[0].position, 1);
    assert_eq!(p.modules[0].handles[0].length, 192);
    assert_eq!(p.production.prices[1], 4.5);
}
#[test]
fn cut_layout_respects_stock_kerf_and_material() {
    let app = FurnitureApp::default();
    let parts = app.parts();
    let (sheets, rejected) = production::layout(&parts, &app.production, &app.materials);
    assert!(rejected.is_empty());
    let expected: u32 = parts
        .iter()
        .filter(|p| p.thickness_mm > 0)
        .map(|p| p.quantity)
        .sum();
    assert_eq!(
        sheets.iter().map(|s| s.pieces.len()).sum::<usize>(),
        expected as usize
    );
    for s in sheets {
        for (i, p) in s.pieces.iter().enumerate() {
            assert_eq!(parts[p.part].material, s.material);
            assert_eq!(parts[p.part].thickness_mm, s.thickness);
            assert!(p.x >= app.production.margin && p.y >= app.production.margin);
            assert!(p.x + p.w <= app.production.width - app.production.margin);
            assert!(p.y + p.h <= app.production.length - app.production.margin);
            for q in s.pieces.iter().skip(i + 1) {
                let k = app.production.kerf;
                assert!(
                    p.x + p.w + k <= q.x
                        || q.x + q.w + k <= p.x
                        || p.y + p.h + k <= q.y
                        || q.y + q.h + k <= p.y
                );
            }
        }
    }
}
#[test]
fn cutting_csv_excludes_hardware() {
    let app = FurnitureApp::default();
    let csv = production::csv(&app.parts(), &app.production);
    assert!(!csv.contains("Parafuso"));
    assert!(csv.contains("Lateral"));
}
#[test]
fn edge_price_is_per_linear_metre() {
    let mut app = FurnitureApp::default();
    app.production.prices[1] = 5.;
    let p = Part {
        group: "teste".into(),
        name: "Peça".into(),
        quantity: 2,
        length_mm: 1000,
        width_mm: 500,
        thickness_mm: 18,
        material: "MDF".into(),
        edge: "PVC 1 mm".into(),
        grain: "".into(),
    };
    assert_eq!(production::edge_cost(&[p], &app.production), 10.);
}
#[test]
fn horizontal_camera_drag_is_finite() {
    let mut c = Camera::reset([4200, 2700, 3200]);
    c.pitch = 0.;
    let d = visual::drag_delta(
        c,
        Rect::from_min_size(Pos2::ZERO, Vec2::splat(800.)),
        V3::new(1000., 500., 1000.),
        Vec2::new(4., 4.),
    );
    assert!(d.x.is_finite() && d.z.is_finite());
    assert!(d.x.abs() < 200. && d.z.abs() < 200.);
}
#[test]
fn simulated_mouse_drag_moves_selected_module_without_losing_selection() {
    let mut app = FurnitureApp::default();
    app.walls.clear();
    app.modules.truncate(1);
    app.camera = Camera {
        target: V3::new(660., 360., 500.),
        yaw: std::f32::consts::PI,
        pitch: 0.3,
        distance: 5000.,
        projection: Projection::Perspective,
    };
    let ctx = egui::Context::default();
    let screen = Rect::from_min_size(Pos2::ZERO, Vec2::new(800., 600.));
    let start = Pos2::new(400., 300.);
    let original = app.modules[0].x_mm;
    for step in 0..5 {
        let pos = start + Vec2::new(step as f32 * 12., 0.);
        let mut events = vec![egui::Event::PointerMoved(pos)];
        if step == 1 || step == 4 {
            events.push(egui::Event::PointerButton {
                pos,
                button: egui::PointerButton::Primary,
                pressed: step == 1,
                modifiers: egui::Modifiers::default(),
            });
        }
        let input = egui::RawInput {
            screen_rect: Some(screen),
            time: Some(step as f64 * 0.1),
            events,
            ..Default::default()
        };
        let _ = ctx.run(input, |ctx| {
            egui::CentralPanel::default().show(ctx, |ui| {
                let (rect, response) =
                    ui.allocate_exact_size(ui.available_size(), Sense::click_and_drag());
                app.handle_scene_input(ctx, &response, rect);
            });
        });
    }
    assert_eq!(app.selected, Some(Selection::Module(1)));
    assert_ne!(app.modules[0].x_mm, original);
    assert!(app.modules[0].x_mm < app.room[0]);
}

#[test]
fn layer_settings_and_individual_hinges_survive_save() {
    let mut a = FurnitureApp::default();
    a.layers.visible[0] = false;
    a.layers.locked[5] = true;
    a.modules[0].handles = vec![fronts::Handle {
        hinge_right: Some(true),
        open: true,
        ..Default::default()
    }];
    let b = parse_mar_project(&project_to_mar(&a)).unwrap();
    assert_eq!(a.layers, b.layers);
    assert_eq!(b.modules[0].handles[0].hinge_right, Some(true));
    assert!(b.modules[0].handles[0].open);
}
#[test]
fn hidden_furniture_remains_in_collision_world() {
    let mut a = FurnitureApp::default();
    a.track_history();
    let before = a.project_snapshot();
    a.hidden_ids.push(3);
    a.modules[0].x_mm = a.modules[2].x_mm;
    a.modules[0].z_mm = a.modules[2].z_mm;
    a.enforce_collisions(&before);
    assert_eq!(a.modules[0].x_mm, before.modules[0].x_mm);
}
#[test]
fn locked_layer_rejects_deletion() {
    let mut a = FurnitureApp::default();
    a.layers.locked[5] = true;
    a.track_history();
    let before = a.project_snapshot();
    a.modules.clear();
    a.enforce_layer_locks(&before);
    assert_eq!(a.modules.len(), 3);
}
#[test]
fn layers_hide_floor_and_host_openings() {
    let mut a = FurnitureApp::default();
    a.layers.visible[0] = false;
    a.layers.visible[2] = false;
    a.openings.push(Opening {
        id: 90,
        wall_id: 4,
        kind: OpeningKind::Door,
        center_mm: 1000,
        width_mm: 800,
        height_mm: 2100,
        sill_mm: 0,
        style: "Lisa".into(),
        material: "MDF".into(),
    });
    let hidden = a.effective_hidden();
    assert!(hidden.contains(&90));
    assert!(hidden.contains(&u32::MAX));
    assert!(!hidden.contains(&1));
}
