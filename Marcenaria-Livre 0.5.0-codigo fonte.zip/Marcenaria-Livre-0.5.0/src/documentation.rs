use super::*;

#[derive(Clone, Debug)]
pub struct Dimension {
    pub view: usize,
    pub a: Pos2,
    pub b: Pos2,
    pub offset: f32,
}
#[derive(Clone, Debug)]
pub struct Options {
    pub dimensions: Vec<Dimension>,
    pub dimension_tool: bool,
    pub pending: Option<(usize, Pos2)>,
    pub revision: String,
    pub number: String,
    pub notes: String,
    pub table: bool,
    pub color: bool,
    pub line_width: f32,
    pub selected: usize,
}
impl Default for Options {
    fn default() -> Self {
        Self {
            dimensions: vec![],
            dimension_tool: false,
            pending: None,
            revision: "00".into(),
            number: "01".into(),
            notes: String::new(),
            table: false,
            color: false,
            line_width: 0.25,
            selected: 0,
        }
    }
}
#[derive(Clone)]
enum Ink {
    Line(Pos2, Pos2, f32, Color32),
    Poly(Vec<Pos2>, Color32, f32),
    Text(Pos2, String, f32),
}
#[derive(Clone)]
struct Mark {
    ink: Ink,
    clip: Option<Rect>,
}
struct Drawing {
    marks: Vec<Mark>,
    clip: Option<Rect>,
}
impl Drawing {
    fn line(&mut self, a: Pos2, b: Pos2, w: f32, c: Color32) {
        self.marks.push(Mark {
            ink: Ink::Line(a, b, w, c),
            clip: self.clip,
        });
    }
    fn poly(&mut self, pts: Vec<Pos2>, c: Color32, w: f32) {
        self.marks.push(Mark {
            ink: Ink::Poly(pts, c, w),
            clip: self.clip,
        });
    }
    fn rect(&mut self, r: Rect, c: Color32, w: f32) {
        self.poly(
            vec![
                r.left_top(),
                r.right_top(),
                r.right_bottom(),
                r.left_bottom(),
            ],
            c,
            w,
        );
    }
    fn text(&mut self, p: Pos2, s: impl Into<String>, size: f32) {
        self.marks.push(Mark {
            ink: Ink::Text(p, s.into(), size),
            clip: self.clip,
        });
    }
    fn dimension(&mut self, a: Pos2, b: Pos2, label: String, size: f32) {
        self.dimension_offset(a, b, label, size, 3.0);
    }
    fn dimension_offset(&mut self, a: Pos2, b: Pos2, label: String, size: f32, offset: f32) {
        if a.distance(b) < 0.001 {
            return;
        }
        let n = Vec2::new(-(b.y - a.y), b.x - a.x).normalized() * offset;
        let a1 = a + n;
        let b1 = b + n;
        self.line(a, a1 + n * 0.5, 0.15, Color32::BLACK);
        self.line(b, b1 + n * 0.5, 0.15, Color32::BLACK);
        self.line(a1, b1, 0.15, Color32::BLACK);
        for p in [a1, b1] {
            self.line(
                p - Vec2::splat(0.8),
                p + Vec2::splat(0.8),
                0.25,
                Color32::BLACK,
            );
        }
        let shift = if (b.x - a.x).abs() > (b.y - a.y).abs() {
            Vec2::new(-(label.chars().count() as f32) * size * 0.25, 1.0)
        } else {
            Vec2::new(1.0, -size * 0.5)
        };
        self.text(a1 + (b1 - a1) * 0.5 + shift, label, size);
    }
}
fn paper(app: &FurnitureApp) -> Vec2 {
    if app.sheet_landscape {
        Vec2::new(297.0, 210.0)
    } else {
        Vec2::new(210.0, 297.0)
    }
}
fn content_bounds(app: &FurnitureApp, kind: ViewKind) -> Rect {
    let mut pts = Vec::new();
    for m in app
        .modules
        .iter()
        .filter(|m| !app.effective_hidden().contains(&m.id))
    {
        for c in module_corners(m) {
            match kind {
                ViewKind::Plan => pts.push(Pos2::new(c.x, c.z)),
                ViewKind::Side => {
                    pts.push(Pos2::new(c.z, -(m.y_mm as f32)));
                    pts.push(Pos2::new(c.z, -((m.y_mm + m.height_mm) as f32)));
                }
                _ => {
                    pts.push(Pos2::new(c.x, -(m.y_mm as f32)));
                    pts.push(Pos2::new(c.x, -((m.y_mm + m.height_mm) as f32)));
                }
            }
        }
    }
    for p in app
        .panels
        .iter()
        .filter(|p| !app.effective_hidden().contains(&p.id))
    {
        let h = if p.horizontal || p.name.starts_with("Bancada de pedra") {
            p.thickness_mm
        } else {
            p.height_mm
        };
        for c in automation::corners(p) {
            if kind == ViewKind::Plan {
                pts.push(Pos2::new(c.x, c.z));
            } else {
                let x = if kind == ViewKind::Side { c.z } else { c.x };
                pts.push(Pos2::new(x, -(p.y_mm as f32)));
                pts.push(Pos2::new(x, -((p.y_mm + h) as f32)));
            }
        }
    }
    if kind == ViewKind::Plan {
        for w in app
            .walls
            .iter()
            .filter(|w| !app.effective_hidden().contains(&w.id))
        {
            pts.push(Pos2::new(w.start.x, w.start.z));
            pts.push(Pos2::new(w.end.x, w.end.z));
        }
    }
    if pts.is_empty() {
        Rect::from_min_size(Pos2::ZERO, Vec2::splat(1000.0))
    } else {
        Rect::from_points(&pts)
    }
}
fn drawing(app: &FurnitureApp) -> Drawing {
    let mut d = Drawing {
        marks: vec![],
        clip: None,
    };
    let size = paper(app);
    let black = Color32::BLACK;
    let lw = app.sheet_options.line_width;
    d.rect(
        Rect::from_min_size(Pos2::new(5.0, 5.0), size - Vec2::splat(10.0)),
        Color32::WHITE,
        0.4,
    );
    d.text(Pos2::new(10.0, 9.0), &app.sheet_title, 4.0);
    for (i, v) in app.sheet_views.iter().enumerate() {
        let r = Rect::from_min_size(Pos2::new(v.x, v.y), Vec2::new(v.width, v.height));
        d.rect(r, Color32::WHITE, 0.15);
        d.text(
            Pos2::new(v.x, v.y - 4.0),
            format!(
                "{} · {} · {}",
                i + 1,
                v.kind.label(),
                if v.kind == ViewKind::ThreeD {
                    "sem escala"
                } else {
                    "1:25"
                }
            ),
            2.4,
        );
        d.clip = Some(r);
        let bounds = content_bounds(app, v.kind);
        let origin =
            r.center() - bounds.center().to_vec2() / 25.0 + Vec2::new(v.offset_x, v.offset_y);
        let tr = |x: f32, y: f32| origin + Vec2::new(x, y) / 25.0;
        if v.kind == ViewKind::Plan {
            for w in app
                .walls
                .iter()
                .filter(|w| !app.effective_hidden().contains(&w.id))
            {
                let a = tr(w.start.x, w.start.z);
                let b = tr(w.end.x, w.end.z);
                d.line(a, b, w.thickness_mm as f32 / 25.0, Color32::GRAY);
                if app.sheet_dimensions {
                    d.dimension(
                        a,
                        b,
                        format!("{:.0}", w.start.distance(w.end)),
                        app.dimension_text_size,
                    );
                }
            }
            for o in app
                .openings
                .iter()
                .filter(|o| !app.effective_hidden().contains(&o.id))
            {
                if let Some(w) = app
                    .walls
                    .iter()
                    .find(|w| w.id == o.wall_id && !app.effective_hidden().contains(&w.id))
                {
                    let len = w.start.distance(w.end).max(1.0);
                    let u = Vec2::new(w.end.x - w.start.x, w.end.z - w.start.z) / len;
                    let center = Vec2::new(w.start.x, w.start.z) + u * o.center_mm as f32;
                    let a = center - u * o.width_mm as f32 / 2.0;
                    let b = center + u * o.width_mm as f32 / 2.0;
                    d.line(
                        tr(a.x, a.y),
                        tr(b.x, b.y),
                        w.thickness_mm as f32 / 25.0 + 0.2,
                        Color32::WHITE,
                    );
                    d.line(tr(a.x, a.y), tr(b.x, b.y), 0.25, black);
                    if o.kind == OpeningKind::Door {
                        let end = a + Vec2::new(-u.y, u.x) * o.width_mm as f32;
                        d.line(tr(a.x, a.y), tr(end.x, end.y), 0.3, black);
                    } else {
                        let n = Vec2::new(-u.y, u.x) * 40.0;
                        d.line(
                            tr(a.x + n.x, a.y + n.y),
                            tr(b.x + n.x, b.y + n.y),
                            0.2,
                            black,
                        );
                    }
                }
            }
            for m in app
                .modules
                .iter()
                .filter(|m| !app.effective_hidden().contains(&m.id))
            {
                let pts: Vec<_> = module_corners(m).iter().map(|p| tr(p.x, p.z)).collect();
                let c = if app.sheet_options.color {
                    material_color_for(&m.material, &app.materials)
                } else {
                    Color32::WHITE
                };
                d.poly(pts.clone(), c, lw);
                let center = Rect::from_points(&pts).center();
                d.text(center, format!("M{}", m.id), 2.5);
                if app.sheet_dimensions {
                    d.dimension(
                        pts[0],
                        pts[1],
                        m.width_mm.to_string(),
                        app.dimension_text_size,
                    );
                }
            }
            for p in app
                .panels
                .iter()
                .filter(|p| !app.effective_hidden().contains(&p.id))
            {
                d.poly(
                    automation::corners(p)
                        .iter()
                        .map(|p| tr(p.x, p.z))
                        .collect(),
                    Color32::WHITE,
                    lw,
                );
            }
        } else {
            let mut camera = app.camera;
            if v.kind == ViewKind::ThreeD {
                camera.projection = Projection::Perspective;
            }
            let faces = if v.kind == ViewKind::ThreeD {
                scene_faces(
                    camera,
                    app.room,
                    &app.walls,
                    &app.openings,
                    &app.modules,
                    &app.panels,
                    &app.gesso,
                    &app.decor,
                    &app.materials,
                    &app.effective_hidden(),
                    &app.floor_texture,
                )
            } else {
                camera.yaw = if v.kind == ViewKind::Front {
                    std::f32::consts::PI
                } else {
                    -std::f32::consts::FRAC_PI_2
                };
                camera.pitch = 0.0;
                let mut faces = vec![];
                for p in app
                    .panels
                    .iter()
                    .filter(|p| !app.effective_hidden().contains(&p.id))
                {
                    automation::panel_faces(&mut faces, camera, p, &app.materials);
                }
                for m in app
                    .modules
                    .iter()
                    .filter(|m| !app.effective_hidden().contains(&m.id))
                {
                    append_module_faces(&mut faces, camera, m, &app.materials, false);
                }
                faces.sort_by(|a, b| a.depth.total_cmp(&b.depth));
                faces
            };
            for face in faces {
                let pts = if v.kind == ViewKind::ThreeD {
                    let local =
                        Rect::from_min_size(Pos2::ZERO, Vec2::new(v.width * 5.0, v.height * 5.0));
                    camera
                        .project_polygon(&face.points, local)
                        .iter()
                        .map(|p| Pos2::new(v.x + p.x / 5.0, v.y + p.y / 5.0))
                        .collect()
                } else {
                    face.points
                        .iter()
                        .map(|p| tr(if v.kind == ViewKind::Side { p.z } else { p.x }, -p.y))
                        .collect::<Vec<_>>()
                };
                if pts.len() >= 3 {
                    let c = if app.sheet_options.color {
                        face.color
                    } else {
                        Color32::WHITE
                    };
                    d.poly(pts, c, lw);
                }
            }
            if v.kind != ViewKind::ThreeD && app.sheet_dimensions {
                for m in app
                    .modules
                    .iter()
                    .filter(|m| !app.effective_hidden().contains(&m.id))
                {
                    let corners = module_corners(m);
                    let a = corners
                        .iter()
                        .map(|p| if v.kind == ViewKind::Side { p.z } else { p.x })
                        .fold(f32::INFINITY, f32::min);
                    let b = corners
                        .iter()
                        .map(|p| if v.kind == ViewKind::Side { p.z } else { p.x })
                        .fold(f32::NEG_INFINITY, f32::max);
                    d.dimension(
                        tr(a, -(m.y_mm as f32)),
                        tr(b, -(m.y_mm as f32)),
                        format!("{:.0}", b - a),
                        app.dimension_text_size,
                    );
                    d.dimension(
                        tr(a, -((m.y_mm + m.height_mm) as f32)),
                        tr(a, -(m.y_mm as f32)),
                        m.height_mm.to_string(),
                        app.dimension_text_size,
                    );
                }
            }
        }
        if let Some((index, point)) = app.sheet_options.pending {
            if index == i && app.sheet_options.dimension_tool {
                let at = tr(point.x, point.y);
                d.line(
                    at - Vec2::new(2.0, 0.0),
                    at + Vec2::new(2.0, 0.0),
                    0.3,
                    GREEN,
                );
                d.line(
                    at - Vec2::new(0.0, 2.0),
                    at + Vec2::new(0.0, 2.0),
                    0.3,
                    GREEN,
                );
            }
        }
        for dim in app
            .sheet_options
            .dimensions
            .iter()
            .filter(|dim| dim.view == i)
        {
            if v.kind != ViewKind::ThreeD {
                d.dimension_offset(
                    tr(dim.a.x, dim.a.y),
                    tr(dim.b.x, dim.b.y),
                    format!("{:.0}", dim.a.distance(dim.b)),
                    app.dimension_text_size,
                    dim.offset,
                );
            }
        }
        d.clip = None;
    }
    let footer = size.y - 35.0;
    d.rect(
        Rect::from_min_size(Pos2::new(10.0, footer), Vec2::new(size.x - 20.0, 25.0)),
        Color32::WHITE,
        0.35,
    );
    d.text(
        Pos2::new(12.0, footer + 2.0),
        format!(
            "{}  |  Folha {}  |  Revisão {}",
            app.sheet_title, app.sheet_options.number, app.sheet_options.revision
        ),
        3.0,
    );
    d.text(
        Pos2::new(12.0, footer + 8.0),
        format!(
            "Cliente: {}    Projetista: {}",
            app.sheet_client, app.sheet_author
        ),
        2.6,
    );
    d.text(
        Pos2::new(12.0, footer + 14.0),
        "A4 · Vistas ortogonais 1:25 · Medidas em mm · Imprimir em tamanho real (100%)",
        2.4,
    );
    d.text(
        Pos2::new(12.0, footer + 19.0),
        &app.sheet_options.notes,
        2.3,
    );
    if app.sheet_options.table {
        let y = footer - 47.0;
        d.rect(
            Rect::from_min_size(Pos2::new(10.0, y), Vec2::new(size.x - 20.0, 44.0)),
            Color32::WHITE,
            0.25,
        );
        d.text(
            Pos2::new(12.0, y + 1.0),
            "MÓDULOS · ID / Nome / L × A × P (mm) / Material",
            2.8,
        );
        for (i, m) in app.modules.iter().take(8).enumerate() {
            d.text(
                Pos2::new(12.0, y + 6.0 + i as f32 * 4.3),
                format!(
                    "M{}  {}  |  {} × {} × {}  |  {}",
                    m.id, m.name, m.width_mm, m.height_mm, m.depth_mm, m.material
                ),
                2.5,
            );
        }
        if app.modules.len() > 8 {
            d.text(
                Pos2::new(12.0, y + 40.0),
                format!(
                    "+ {} módulos: tabela completa nas páginas anexas do PDF",
                    app.modules.len() - 8
                ),
                2.4,
            );
        }
    }
    d
}
pub fn svg(app: &FurnitureApp) -> String {
    let size = paper(app);
    let mut s=format!("<svg xmlns='http://www.w3.org/2000/svg' width='{}mm' height='{}mm' viewBox='0 0 {} {}'><rect width='100%' height='100%' fill='white'/>",size.x,size.y,size.x,size.y);
    for (i, m) in drawing(app).marks.iter().enumerate() {
        if let Some(r) = m.clip {
            s.push_str(&format!("<defs><clipPath id='c{i}'><rect x='{}' y='{}' width='{}' height='{}'/></clipPath></defs><g clip-path='url(#c{i})'>",r.left(),r.top(),r.width(),r.height()));
        }
        match &m.ink {
            Ink::Line(a, b, w, c) => s.push_str(&format!(
                "<line x1='{}' y1='{}' x2='{}' y2='{}' stroke='{}' stroke-width='{w}'/>",
                a.x,
                a.y,
                b.x,
                b.y,
                svg_hex(*c)
            )),
            Ink::Poly(pts, c, w) => {
                let points = pts
                    .iter()
                    .map(|p| format!("{},{}", p.x, p.y))
                    .collect::<Vec<_>>()
                    .join(" ");
                s.push_str(&format!(
                    "<polygon points='{points}' fill='{}' stroke='#222' stroke-width='{w}'/>",
                    svg_hex(*c)
                ));
            }
            Ink::Text(p, t, size) => s.push_str(&format!(
                "<text x='{}' y='{}' font-family='sans-serif' font-size='{size}'>{}</text>",
                p.x,
                p.y + size * 0.82,
                xml_escape(t)
            )),
        }
        if m.clip.is_some() {
            s.push_str("</g>");
        }
    }
    s.push_str("</svg>");
    s
}
fn preview(app: &FurnitureApp, ui: &mut egui::Ui) -> (Rect, f32) {
    let page = paper(app);
    let scale = ((ui.available_width() - 12.0) / page.x)
        .min((ui.available_height() - 12.0).max(200.0) / page.y)
        .max(0.2);
    let (r, _) = ui.allocate_exact_size(page * scale, Sense::hover());
    let painter = ui.painter_at(r);
    painter.rect_filled(r, 0.0, Color32::WHITE);
    let tr = |p: Pos2| r.min + p.to_vec2() * scale;
    for mark in drawing(app).marks {
        let p = if let Some(c) = mark.clip {
            painter.with_clip_rect(Rect::from_min_max(tr(c.min), tr(c.max)).intersect(r))
        } else {
            painter.clone()
        };
        match mark.ink {
            Ink::Line(a, b, w, c) => {
                p.line_segment([tr(a), tr(b)], Stroke::new((w * scale).max(0.3), c));
            }
            Ink::Poly(pts, c, w) => {
                p.add(egui::Shape::convex_polygon(
                    pts.into_iter().map(tr).collect(),
                    c,
                    Stroke::new((w * scale).max(0.3), Color32::BLACK),
                ));
            }
            Ink::Text(at, t, size) => {
                p.text(
                    tr(at),
                    egui::Align2::LEFT_TOP,
                    t,
                    egui::FontId::proportional(size * scale),
                    Color32::BLACK,
                );
            }
        }
    }
    (r, scale)
}
pub fn editor(app: &mut FurnitureApp, ui: &mut egui::Ui) {
    ui.heading(i18n::tr("Documentação · editor de pranchas A4"));
    ui.horizontal_wrapped(|ui| {
        for kind in [
            ViewKind::Plan,
            ViewKind::Front,
            ViewKind::Side,
            ViewKind::ThreeD,
        ] {
            if ui
                .add_sized(
                    [130.0, 38.0],
                    egui::Button::new(format!("+ {}", kind.label())),
                )
                .clicked()
            {
                app.sheet_views.push(SheetViewport {
                    kind,
                    x: 14.0,
                    y: 24.0,
                    width: 165.0,
                    height: 110.0,
                    offset_x: 0.0,
                    offset_y: 0.0,
                });
                app.sheet_options.selected = app.sheet_views.len() - 1;
            }
        }
        for ext in ["pdf", "svg"] {
            if ui
                .add_sized(
                    [130.0, 38.0],
                    egui::Button::new(format!("Exportar {}", ext.to_uppercase())),
                )
                .clicked()
            {
                app.sheet_path = Path::new(&app.sheet_path)
                    .with_extension(ext)
                    .to_string_lossy()
                    .into_owned();
                if app.save_dialog_path() {
                    export(app, ext);
                }
            }
        }
    });
    ui.label(i18n::tr("Arraste a vista na folha. Arraste o quadrado verde no canto para redimensionar. A escala permanece 1:25; o quadro recorta a vista."));
    ui.horizontal(|ui|{ui.toggle_value(&mut app.sheet_options.dimension_tool,"Cota por dois pontos");if ui.button(i18n::tr("Cancelar cota")).clicked(){app.sheet_options.dimension_tool=false;app.sheet_options.pending=None;}if app.sheet_options.dimension_tool{ui.label(i18n::tr("Clique em dois pontos de uma vista ortogonal. Medida em mm, sem vínculo automático ao objeto."));}});
    ui.separator();
    ui.columns(2,|cols|{
        cols[1].vertical(|ui|{egui::ScrollArea::vertical().id_source("sheet_controls").show(ui,|ui|{
            ui.horizontal(|ui|{ui.selectable_value(&mut app.sheet_landscape,true,i18n::tr("Horizontal"));ui.selectable_value(&mut app.sheet_landscape,false,i18n::tr("Vertical"));});
            ui.label(i18n::tr("Título"));ui.text_edit_singleline(&mut app.sheet_title);ui.label(i18n::tr("Cliente"));ui.text_edit_singleline(&mut app.sheet_client);ui.label(i18n::tr("Projetista"));ui.text_edit_singleline(&mut app.sheet_author);
            ui.horizontal(|ui|{ui.label(i18n::tr("Folha"));ui.add(egui::TextEdit::singleline(&mut app.sheet_options.number).desired_width(55.0));ui.label(i18n::tr("Revisão"));ui.add(egui::TextEdit::singleline(&mut app.sheet_options.revision).desired_width(55.0));});
            ui.label(i18n::tr("Nota do carimbo"));ui.text_edit_singleline(&mut app.sheet_options.notes);
            ui.horizontal(|ui|{ui.checkbox(&mut app.sheet_dimensions,i18n::tr("Cotas automáticas"));ui.checkbox(&mut app.sheet_options.color,i18n::tr("Cores de materiais"));});ui.checkbox(&mut app.sheet_options.table,i18n::tr("Tabela de módulos (PDF inclui a lista completa)"));
            ui.add(egui::Slider::new(&mut app.dimension_text_size,1.5..=5.0).text("Texto da cota (mm)"));ui.add(egui::Slider::new(&mut app.sheet_options.line_width,0.1..=0.8).text("Espessura de linha (mm)"));
            ui.separator();let mut remove=None;let mut duplicate=None;
            for (i,v) in app.sheet_views.iter_mut().enumerate(){ui.push_id(i,|ui|{ui.group(|ui|{
                if ui.selectable_label(app.sheet_options.selected==i,format!("Vista {} · {}",i+1,v.kind.label())).clicked(){app.sheet_options.selected=i;}
                egui::ComboBox::from_id_source("kind").selected_text(v.kind.label()).show_ui(ui,|ui|{for k in [ViewKind::Plan,ViewKind::Front,ViewKind::Side,ViewKind::ThreeD]{ui.selectable_value(&mut v.kind,k,k.label());}});
                ui.horizontal(|ui|{ui.add(egui::DragValue::new(&mut v.x).speed(0.5).prefix("X "));ui.add(egui::DragValue::new(&mut v.y).speed(0.5).prefix("Y "));});
                ui.horizontal(|ui|{ui.add(egui::DragValue::new(&mut v.width).speed(0.5).clamp_range(20.0..=287.0).prefix("L "));ui.add(egui::DragValue::new(&mut v.height).speed(0.5).clamp_range(20.0..=277.0).prefix("A "));});
                ui.horizontal(|ui|{ui.add(egui::DragValue::new(&mut v.offset_x).speed(0.5).prefix("Deslocar desenho X "));ui.add(egui::DragValue::new(&mut v.offset_y).speed(0.5).prefix("Y "));});
                ui.horizontal(|ui|{if ui.button(i18n::tr("Duplicar")).clicked(){duplicate=Some(*v);}if ui.button(i18n::tr("Remover")).clicked(){remove=Some(i);}});
            });});}
            if let Some(i)=remove{app.sheet_views.remove(i);app.sheet_options.dimensions.retain(|d|d.view!=i);for d in &mut app.sheet_options.dimensions{if d.view>i{d.view-=1;}}}if let Some(mut v)=duplicate{v.x+=5.0;v.y+=5.0;app.sheet_views.push(v);}
            let size=paper(app);for (i,v) in app.sheet_views.iter().enumerate(){if v.x+v.width>size.x-5.0||v.y+v.height>size.y-if app.sheet_options.table{82.0}else{35.0}||v.x<5.0||v.y<18.0{ui.colored_label(Color32::DARK_RED,format!("Vista {} ultrapassa a área livre da folha.",i+1));}let bounds=content_bounds(app,v.kind);if v.kind!=ViewKind::ThreeD&&(bounds.width()/25.0>v.width-10.0||bounds.height()/25.0>v.height-10.0){ui.colored_label(Color32::DARK_RED,format!("Vista {} contém recortes na escala 1:25. Aumente o quadro ou desloque o desenho.",i+1));}}
            ui.collapsing("Cotas adicionadas",|ui|{let mut remove=None;for (i,d) in app.sheet_options.dimensions.iter_mut().enumerate(){ui.horizontal(|ui|{ui.label(format!("Vista {} · {:.0} mm",d.view+1,d.a.distance(d.b)));ui.add(egui::DragValue::new(&mut d.offset).speed(0.2).prefix("Afastamento ").suffix(" mm"));if ui.button(i18n::tr("Excluir")).clicked(){remove=Some(i);}});}if let Some(i)=remove{app.sheet_options.dimensions.remove(i);}});
            ui.label(i18n::tr("Destino PDF ou SVG"));ui.text_edit_singleline(&mut app.sheet_path);if ui.button(i18n::tr("Salvar no destino informado")).clicked(){let ext=if app.sheet_path.to_lowercase().ends_with(".pdf"){"pdf"}else{"svg"};export(app,ext);}
        });});
        cols[0].vertical(|ui|{
            let (r,scale)=preview(app,ui);let page=paper(app);let bounds:Vec<_>=app.sheet_views.iter().map(|v|content_bounds(app,v.kind)).collect();
            for (i,v) in app.sheet_views.iter_mut().enumerate(){let vr=Rect::from_min_size(r.min+Vec2::new(v.x,v.y)*scale,Vec2::new(v.width,v.height)*scale);let handle=Rect::from_center_size(vr.right_bottom(),Vec2::splat(12.0));let response=ui.interact(vr,ui.id().with(("view",i)),if app.sheet_options.dimension_tool{Sense::click()}else{Sense::click_and_drag()});let size_response=ui.interact(handle,ui.id().with(("resize",i)),Sense::drag());
                if response.clicked()||response.dragged()||size_response.dragged(){app.sheet_options.selected=i;}
                if app.sheet_options.dimension_tool&&response.clicked()&&v.kind!=ViewKind::ThreeD{if let Some(p)=response.interact_pointer_pos(){let paper_point=(p-r.min)/scale;let center=Pos2::new(v.x+v.width/2.0,v.y+v.height/2.0);let origin=center-bounds[i].center().to_vec2()/25.0+Vec2::new(v.offset_x,v.offset_y);let world=Pos2::ZERO+(paper_point-origin.to_vec2())*25.0;if let Some((old,a))=app.sheet_options.pending{if old==i&&a.distance(world)>1.0{app.sheet_options.dimensions.push(Dimension{view:i,a,b:world,offset:5.0});app.sheet_options.pending=None;}else{app.sheet_options.pending=Some((i,world));}}else{app.sheet_options.pending=Some((i,world));}}}
                if !app.sheet_options.dimension_tool&&size_response.dragged(){let delta=ui.input(|i|i.pointer.delta())/scale;v.width=(v.width+delta.x).clamp(20.0,(page.x-v.x-5.0).max(20.0));v.height=(v.height+delta.y).clamp(20.0,(page.y-v.y-35.0).max(20.0));}else if !app.sheet_options.dimension_tool&&response.dragged(){let delta=ui.input(|i|i.pointer.delta())/scale;v.x=(v.x+delta.x).clamp(5.0,(page.x-v.width-5.0).max(5.0));v.y=(v.y+delta.y).clamp(18.0,(page.y-v.height-35.0).max(18.0));}
                if app.sheet_options.selected==i{ui.painter().rect_stroke(vr,0.0,Stroke::new(2.0,GREEN));ui.painter().rect_filled(handle,2.0,GREEN);}
            }
        });
    });
    if !app.notice.is_empty() {
        ui.label(&app.notice);
    }
}

fn export(app: &mut FurnitureApp, ext: &str) {
    let path = Path::new(&app.sheet_path).with_extension(ext);
    app.sheet_path = path.to_string_lossy().into_owned();
    let result = if ext == "pdf" {
        fs::write(&path, pdf(app))
    } else {
        fs::write(&path, svg(app))
    };
    match result {
        Ok(()) => {
            app.notice = format!("Prancha salva em {}", path.display());
            app.notice_error = false;
        }
        Err(e) => {
            app.notice = format!("Não foi possível exportar: {e}");
            app.notice_error = true;
        }
    }
}
/// Vector PDF in physical millimetres. No browser print scaling or remote service.
pub fn pdf(app: &FurnitureApp) -> Vec<u8> {
    let size = paper(app);
    let mut pages = vec![drawing(app)];
    if app.sheet_options.table && app.modules.len() > 8 {
        let rows = ((size.y - 55.0) / 7.0) as usize;
        for (page, chunk) in app.modules.chunks(rows).enumerate() {
            let mut d = Drawing {
                marks: vec![],
                clip: None,
            };
            d.rect(
                Rect::from_min_size(Pos2::new(5.0, 5.0), size - Vec2::splat(10.0)),
                Color32::WHITE,
                0.3,
            );
            d.text(
                Pos2::new(10.0, 10.0),
                format!("{} · Tabela de módulos · {}", app.sheet_title, page + 1),
                3.5,
            );
            d.text(
                Pos2::new(10.0, 20.0),
                "ID / Nome / Largura × Altura × Profundidade (mm) / Material",
                2.8,
            );
            for (i, m) in chunk.iter().enumerate() {
                let y = 29.0 + i as f32 * 7.0;
                d.text(
                    Pos2::new(10.0, y),
                    format!(
                        "M{} · {} · {} × {} × {} · {}",
                        m.id, m.name, m.width_mm, m.height_mm, m.depth_mm, m.material
                    ),
                    2.5,
                );
                d.line(
                    Pos2::new(10.0, y + 5.0),
                    Pos2::new(size.x - 10.0, y + 5.0),
                    0.15,
                    Color32::GRAY,
                );
            }
            d.text(
                Pos2::new(10.0, size.y - 15.0),
                format!(
                    "Anexo da folha {} · Revisão {} · Somente marcenaria",
                    app.sheet_options.number, app.sheet_options.revision
                ),
                2.6,
            );
            pages.push(d);
        }
    }
    let mut objects: Vec<Vec<u8>> = vec![
        b"<< /Type /Catalog /Pages 2 0 R >>".to_vec(),
        Vec::new(),
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"
            .to_vec(),
    ];
    let mut kids = String::new();
    let k = 72.0 / 25.4;
    for drawing in pages {
        let id = objects.len() + 1;
        kids.push_str(&format!("{id} 0 R "));
        objects.push(format!("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {} {}] /Resources << /Font << /F1 3 0 R >> >> /Contents {} 0 R >>",size.x*k,size.y*k,id+1).into_bytes());
        let mut stream = String::new();
        for mark in drawing.marks {
            stream.push_str("q\n");
            if let Some(r) = mark.clip {
                stream.push_str(&format!(
                    "{} {} {} {} re W n\n",
                    r.left() * k,
                    (size.y - r.bottom()) * k,
                    r.width() * k,
                    r.height() * k
                ));
            }
            match mark.ink {
                Ink::Line(a, b, w, c) => {
                    stream.push_str(&format!(
                        "{} {} {} RG {} w {} {} m {} {} l S\n",
                        c.r() as f32 / 255.0,
                        c.g() as f32 / 255.0,
                        c.b() as f32 / 255.0,
                        w * k,
                        a.x * k,
                        (size.y - a.y) * k,
                        b.x * k,
                        (size.y - b.y) * k
                    ));
                }
                Ink::Poly(pts, c, w) => {
                    if let Some(a) = pts.first() {
                        stream.push_str(&format!(
                            "{} {} {} rg 0.13 0.13 0.13 RG {} w {} {} m\n",
                            c.r() as f32 / 255.0,
                            c.g() as f32 / 255.0,
                            c.b() as f32 / 255.0,
                            w * k,
                            a.x * k,
                            (size.y - a.y) * k
                        ));
                        for p in pts.iter().skip(1) {
                            stream.push_str(&format!("{} {} l\n", p.x * k, (size.y - p.y) * k));
                        }
                        stream.push_str("h B\n");
                    }
                }
                Ink::Text(p, t, font) => {
                    let hex = t
                        .chars()
                        .map(|c| {
                            let n = match c {
                                '–' | '—' => b'-',
                                '×' => 215,
                                '·' => 183,
                                _ if (c as u32) <= 255 => c as u8,
                                _ => b'?',
                            };
                            format!("{n:02X}")
                        })
                        .collect::<String>();
                    stream.push_str(&format!(
                        "0 0 0 rg BT /F1 {} Tf 1 0 0 1 {} {} Tm <{}> Tj ET\n",
                        font * k,
                        p.x * k,
                        (size.y - p.y - font * 0.82) * k,
                        hex
                    ));
                }
            }
            stream.push_str("Q\n");
        }
        objects.push(
            format!(
                "<< /Length {} >>\nstream\n{}endstream",
                stream.len(),
                stream
            )
            .into_bytes(),
        );
    }
    objects[1] = format!(
        "<< /Type /Pages /Count {} /Kids [{}] >>",
        (objects.len() - 3) / 2,
        kids
    )
    .into_bytes();
    let mut bytes = b"%PDF-1.4\n%\xE2\xE3\xCF\xD3\n".to_vec();
    let mut offsets = vec![0];
    for (i, obj) in objects.iter().enumerate() {
        offsets.push(bytes.len());
        bytes.extend_from_slice(format!("{} 0 obj\n", i + 1).as_bytes());
        bytes.extend_from_slice(obj);
        bytes.extend_from_slice(b"\nendobj\n");
    }
    let start = bytes.len();
    bytes.extend_from_slice(format!("xref\n0 {}\n0000000000 65535 f \n", offsets.len()).as_bytes());
    for off in offsets.iter().skip(1) {
        bytes.extend_from_slice(format!("{off:010} 00000 n \n").as_bytes());
    }
    bytes.extend_from_slice(
        format!(
            "trailer\n<< /Size {} /Root 1 0 R >>\nstartxref\n{start}\n%%EOF\n",
            offsets.len()
        )
        .as_bytes(),
    );
    bytes
}
