use super::*;
#[derive(Clone, Debug)]
pub struct Settings {
    pub back_overlap: u32,
    pub back_setback: u32,
    pub shelf_setback: u32,
    pub drawer_clearance: u32,
    pub base_between: bool,
    pub top_between: bool,
    pub base_height: u32,
    pub base_depth: u32,
    pub base_elevation: u32,
    pub upper_height: u32,
    pub upper_depth: u32,
    pub upper_elevation: u32,
    pub hinge_step: u32,
}
impl Default for Settings {
    fn default() -> Self {
        Self {
            back_overlap: 10,
            back_setback: 12,
            shelf_setback: 20,
            drawer_clearance: 13,
            base_between: true,
            top_between: true,
            base_height: 720,
            base_depth: 550,
            base_elevation: 100,
            upper_height: 720,
            upper_depth: 350,
            upper_elevation: 1400,
            hinge_step: 700,
        }
    }
}
impl Settings {
    pub fn fields(&self) -> Vec<String> {
        vec![
            "FABRICATION".into(),
            self.back_overlap.to_string(),
            self.back_setback.to_string(),
            self.shelf_setback.to_string(),
            self.drawer_clearance.to_string(),
            self.base_between.to_string(),
            self.top_between.to_string(),
            self.base_height.to_string(),
            self.base_depth.to_string(),
            self.base_elevation.to_string(),
            self.upper_height.to_string(),
            self.upper_depth.to_string(),
            self.upper_elevation.to_string(),
            self.hinge_step.to_string(),
        ]
    }
    pub fn parse(f: &[&str]) -> Result<Self, String> {
        Ok(Self {
            back_overlap: mar_num(f, 1)?,
            back_setback: mar_num(f, 2)?,
            shelf_setback: mar_num(f, 3)?,
            drawer_clearance: mar_num(f, 4)?,
            base_between: mar_num(f, 5)?,
            top_between: mar_num(f, 6)?,
            base_height: mar_num(f, 7)?,
            base_depth: mar_num(f, 8)?,
            base_elevation: mar_num(f, 9)?,
            upper_height: mar_num(f, 10)?,
            upper_depth: mar_num(f, 11)?,
            upper_elevation: mar_num(f, 12)?,
            hinge_step: mar_num::<u32>(f, 13)?.max(100),
        })
    }
}
pub fn parts(app: &FurnitureApp, m: &Module) -> Vec<Part> {
    let c = &app.fabrication;
    let t = m.thickness_mm;
    let top = app.method_top;
    let back = app.method_back;
    let gap = app.method_gap;
    let inside = m.width_mm.saturating_sub(2 * t);
    let side_h = m
        .height_mm
        .saturating_sub(if c.base_between { 0 } else { top })
        .saturating_sub(if c.top_between || m.top_mode != 0 {
            0
        } else {
            top
        });
    let mut result = Vec::new();
    let mut add = |name: &str, q: u32, l: u32, w: u32, th: u32, mat: &str, edge: bool| {
        if q > 0 && l > 0 && w > 0 {
            result.push(Part {
                group: format!("M{} · {}", m.id, m.name),
                name: name.into(),
                quantity: q,
                length_mm: l,
                width_mm: w,
                thickness_mm: th,
                material: format!("{} {} mm", mat, th),
                edge: if edge {
                    app.standard_edge.clone()
                } else {
                    "sem fita".into()
                },
                grain: m.grain.label().into(),
            });
        }
    };
    add("Lateral", 2, side_h, m.depth_mm, t, &m.material, true);
    add(
        "Base",
        1,
        if c.base_between { inside } else { m.width_mm },
        m.depth_mm,
        top,
        &m.material,
        true,
    );
    if m.top_mode == 0 {
        add(
            "Tampo estrutural",
            1,
            if c.top_between { inside } else { m.width_mm },
            m.depth_mm,
            top,
            &m.material,
            true,
        );
    } else if m.top_mode == 2 {
        add(
            "Travessa superior",
            2,
            inside,
            80.min(m.depth_mm / 3),
            top,
            &m.material,
            true,
        );
    }
    let (bw, bh) = if app.back_mount == "Sobreposto" {
        (m.width_mm, m.height_mm)
    } else {
        (
            inside.saturating_add(c.back_overlap.min(t) * 2),
            m.height_mm
                .saturating_sub(2 * top)
                .saturating_add(c.back_overlap.min(top) * 2),
        )
    };
    add("Fundo", 1, bh, bw, back, &m.material, false);
    let shelf_depth = m
        .depth_mm
        .saturating_sub(back + c.back_setback + c.shelf_setback);
    let bays = m.divider_count + 1;
    let bay = inside.saturating_sub(m.divider_count * t) / bays;
    add(
        "Divisória vertical",
        m.divider_count,
        m.height_mm.saturating_sub(2 * top),
        m.depth_mm.saturating_sub(back + c.back_setback),
        t,
        &m.material,
        true,
    );
    add(
        "Prateleira",
        m.shelf_count * bays,
        bay,
        shelf_depth,
        t,
        &m.material,
        true,
    );
    if m.kind == ModuleKind::Drawer || m.drawer_count > 0 {
        let n = m.drawer_count.max(1);
        let zone = if m.kind == ModuleKind::Drawer {
            m.height_mm
        } else {
            m.internal_drawer_height
                .min(m.height_mm.saturating_sub(2 * t))
        };
        let front_h = zone.saturating_sub(gap * (n + 1)) / n;
        let outer = inside.saturating_sub(2 * c.drawer_clearance);
        let depth = m.depth_mm.saturating_sub(back + c.back_setback + 20);
        let box_h = front_h.saturating_sub(40).max(40);
        if m.kind == ModuleKind::Drawer {
            add(
                "Frente de gaveta",
                n,
                m.width_mm.saturating_sub(2 * gap),
                front_h,
                t,
                &m.door_material,
                true,
            );
        }
        add(
            "Lateral de gaveta",
            n * 2,
            depth,
            box_h,
            t,
            &m.material,
            true,
        );
        add(
            "Traseiro e contrafrente de gaveta",
            n * 2,
            outer.saturating_sub(2 * t),
            box_h,
            t,
            &m.material,
            true,
        );
        add("Fundo de gaveta", n, depth, outer, back, &m.material, false);
    }
    if m.kind != ModuleKind::Drawer && m.door_count > 0 {
        let width = m.width_mm.saturating_sub(gap * (m.door_count + 1)) / m.door_count;
        add(
            "Porta",
            m.door_count,
            m.height_mm.saturating_sub(2 * gap),
            width,
            t,
            &m.door_material,
            true,
        );
    }
    result
}
pub fn editor(app: &mut FurnitureApp, ui: &mut egui::Ui) {
    ui.heading(i18n::tr("Método construtivo · medidas e montagem"));
    ui.label(i18n::tr("As regras abaixo calculam a lista de peças do projeto. Confira a prévia antes de fabricar."));
    egui::ScrollArea::vertical().show(ui, |ui| {
        ui.columns(2, |c| {
            c[0].group(|ui| {
                ui.heading(i18n::tr("▦ Espessuras e encaixes"));
                property_field(ui, "Laterais (novos módulos)", &mut app.method_side, 6..=40);
                property_field(ui, "Base e tampo", &mut app.method_top, 6..=40);
                property_field(ui, "Fundo", &mut app.method_back, 3..=25);
                ui.checkbox(
                    &mut app.fabrication.base_between,
                    i18n::tr("Base entre as laterais"),
                );
                ui.checkbox(
                    &mut app.fabrication.top_between,
                    i18n::tr("Tampo entre as laterais"),
                );
                egui::ComboBox::from_label(i18n::tr("Montagem do fundo"))
                    .selected_text(&app.back_mount)
                    .show_ui(ui, |ui| {
                        for item in ["Encaixado", "Sobreposto", "Canaleta"] {
                            ui.selectable_value(&mut app.back_mount, item.into(), item);
                        }
                    });
                property_field(
                    ui,
                    "Avanço do fundo por lado",
                    &mut app.fabrication.back_overlap,
                    0..=20,
                );
                property_field(
                    ui,
                    "Recuo do fundo",
                    &mut app.fabrication.back_setback,
                    0..=100,
                );
                property_field(
                    ui,
                    "Recuo frontal das prateleiras",
                    &mut app.fabrication.shelf_setback,
                    0..=100,
                );
            });
            c[1].group(|ui| {
                ui.heading(i18n::tr("↔ Folgas e dimensões"));
                property_field(ui, "Folgas das frentes", &mut app.method_gap, 0..=15);
                property_field(
                    ui,
                    "Altura por dobradiça (estimativa)",
                    &mut app.fabrication.hinge_step,
                    100..=1200,
                );
                property_field(
                    ui,
                    "Folga corrediça por lado",
                    &mut app.fabrication.drawer_clearance,
                    0..=30,
                );
                property_field(
                    ui,
                    "Altura balcão",
                    &mut app.fabrication.base_height,
                    100..=1600,
                );
                property_field(
                    ui,
                    "Profundidade balcão",
                    &mut app.fabrication.base_depth,
                    100..=1200,
                );
                property_field(
                    ui,
                    "Elevação / rodapé",
                    &mut app.fabrication.base_elevation,
                    0..=400,
                );
                property_field(
                    ui,
                    "Altura aéreo",
                    &mut app.fabrication.upper_height,
                    100..=1600,
                );
                property_field(
                    ui,
                    "Profundidade aéreo",
                    &mut app.fabrication.upper_depth,
                    100..=1000,
                );
                property_field(
                    ui,
                    "Elevação aéreo",
                    &mut app.fabrication.upper_elevation,
                    500..=2500,
                );
                egui::ComboBox::from_label(i18n::tr("Fita de borda"))
                    .selected_text(&app.standard_edge)
                    .show_ui(ui, |ui| {
                        for v in [
                            "Sem fita",
                            "PVC 0,4 mm",
                            "PVC 1 mm",
                            "PVC 2 mm",
                            "ABS 1 mm",
                            "ABS 2 mm",
                        ] {
                            ui.selectable_value(&mut app.standard_edge, v.into(), v);
                        }
                    });
            });
        });
        ui.horizontal_wrapped(|ui| {
            if ui
                .add_sized(
                    [230.0, 42.0],
                    egui::Button::new(i18n::tr("▦ Aplicar espessura aos módulos")),
                )
                .clicked()
            {
                for m in &mut app.modules {
                    m.thickness_mm = app.method_side;
                }
                app.custom_thickness = app.method_side;
                app.notice = "Espessuras aplicadas. A lista de corte foi recalculada.".into();
            }
            if ui
                .add_sized(
                    [230.0, 42.0],
                    egui::Button::new(i18n::tr("↕ Aplicar dimensões da cozinha")),
                )
                .clicked()
            {
                for m in &mut app.modules {
                    match m.kind {
                        ModuleKind::Base | ModuleKind::Drawer => {
                            m.height_mm = app.fabrication.base_height;
                            m.depth_mm = app.fabrication.base_depth;
                            m.y_mm = app.fabrication.base_elevation;
                        }
                        ModuleKind::Wall => {
                            m.height_mm = app.fabrication.upper_height;
                            m.depth_mm = app.fabrication.upper_depth;
                            m.y_mm = app.fabrication.upper_elevation;
                        }
                        _ => {}
                    }
                }
                app.notice = "Dimensões aplicadas aos balcões, gaveteiros e aéreos.".into();
            }
        });
        ui.separator();
        ui.heading(i18n::tr("Prévia das peças do módulo selecionado"));
        let m = app
            .modules
            .iter()
            .find(|m| app.selected == Some(Selection::Module(m.id)))
            .or_else(|| app.modules.first());
        if let Some(m) = m {
            ui.label(format!(
                "{} · {} × {} × {} mm",
                m.name, m.width_mm, m.height_mm, m.depth_mm
            ));
            egui::Grid::new("method_parts")
                .striped(true)
                .show(ui, |ui| {
                    for p in parts(app, m) {
                        ui.label(p.name);
                        ui.label(format!("{} un.", p.quantity));
                        ui.label(format!(
                            "{} × {} × {} mm",
                            p.length_mm, p.width_mm, p.thickness_mm
                        ));
                        ui.end_row();
                    }
                });
        }
    });
}

pub fn module_preview(app: &FurnitureApp, ui: &mut egui::Ui, pr: Preset) {
    let mut m = make_module(0, pr, 0, 0);
    m.thickness_mm = app.custom_thickness;
    m.divider_count = app.custom_dividers;
    m.drawer_count = app.custom_drawers;
    m.top_mode = app.custom_top;
    m.internal_drawer_height = app.custom_drawer_height;
    m.door_style = app.custom_style;
    m.door_styles = vec![app.custom_style; m.door_count as usize];
    m.material = app.custom_material.clone();
    m.door_material = app.custom_material.clone();
    m.door_open = true;
    let (r, _) = ui.allocate_exact_size(
        Vec2::new(ui.available_width().min(340.0), 220.0),
        Sense::hover(),
    );
    let p = ui.painter_at(r);
    p.rect_filled(r, 5.0, Color32::from_gray(242));
    let camera = Camera {
        target: V3::new(
            m.width_mm as f32 / 2.0,
            m.height_mm as f32 / 2.0,
            m.depth_mm as f32 / 2.0,
        ),
        yaw: 3.7,
        pitch: 0.2,
        distance: m.width_mm.max(m.height_mm).max(m.depth_mm) as f32 * 10.0,
        projection: Projection::Perspective,
    };
    let mut faces = vec![];
    append_module_faces(&mut faces, camera, &m, &app.materials, false);
    faces.sort_by(|a, b| a.depth.total_cmp(&b.depth));
    for f in faces {
        let pts = camera.project_polygon(&f.points, r);
        if pts.len() > 2 {
            p.add(egui::Shape::convex_polygon(
                pts,
                f.color,
                Stroke::new(0.6, Color32::DARK_GRAY),
            ));
        }
    }
    ui.small(i18n::tr(
        "Prévia com portas abertas para visualizar os vãos e as divisórias.",
    ));
}

pub fn hardware(app: &FurnitureApp, m: &Module) -> Vec<Part> {
    let mut parts = hardware_for_module(m);
    for p in &mut parts {
        if p.name == "Dobradiça com caneco" {
            p.quantity = if m.kind == ModuleKind::Drawer {
                0
            } else {
                m.door_count
                    * ((m.height_mm + app.fabrication.hinge_step - 1) / app.fabrication.hinge_step)
                        .max(2)
            };
        }
    }
    parts.retain(|p| p.quantity > 0 && p.name != "Puxador");
    let count = if m.kind == ModuleKind::Drawer {
        m.drawer_count.max(1)
    } else {
        m.door_count
    };
    for i in 0..count as usize {
        let style = m.door_styles.get(i).copied().unwrap_or(m.door_style);
        if matches!(
            style,
            DoorStyle::Cava | DoorStyle::Horizontal | DoorStyle::Vertical
        ) {
            continue;
        }
        let h = m
            .handles
            .get(i)
            .cloned()
            .unwrap_or_else(|| fronts::default_handle(m, i));
        if h.enabled {
            parts.push(Part {
                group: format!("M{} · {}", m.id, m.name),
                name: format!("Puxador barra {} mm · frente {}", h.length, i + 1),
                quantity: 1,
                length_mm: 0,
                width_mm: 0,
                thickness_mm: 0,
                material: "Ferragem".into(),
                edge: "—".into(),
                grain: "—".into(),
            });
        }
    }
    parts
}
