use super::*;
#[derive(Clone, Debug)]
pub struct Surface {
    pub grain: Grain,
    pub seed: f32,
    pub texture: Option<std::sync::Arc<egui::ColorImage>>,
}
#[derive(Clone, Copy)]
struct Vertex {
    p: V3,
    uv: Vec2,
}
fn clip(poly: &[Vertex], camera: Camera) -> Vec<Vertex> {
    let depth = |p: V3| camera.distance - p.sub(camera.target).dot(camera.basis().2);
    let mut out = vec![];
    for i in 0..poly.len() {
        let a = poly[i];
        let b = poly[(i + 1) % poly.len()];
        let da = depth(a.p);
        let db = depth(b.p);
        if da >= 10.0 {
            out.push(a);
        }
        if (da >= 10.0) != (db >= 10.0) {
            let t = (10.0 - da) / (db - da);
            out.push(Vertex {
                p: a.p.add(b.p.sub(a.p).mul(t)),
                uv: a.uv + (b.uv - a.uv) * t,
            });
        }
    }
    out
}
pub fn image(
    faces: &[Face],
    camera: Camera,
    size: [usize; 2],
    mode: RenderMode,
) -> egui::ColorImage {
    image_scaled(faces, camera, size, mode, 1.)
}
fn image_scaled(
    faces: &[Face],
    camera: Camera,
    size: [usize; 2],
    mode: RenderMode,
    scale: f32,
) -> egui::ColorImage {
    let [w, h] = size;
    let rect = Rect::from_min_size(Pos2::ZERO, Vec2::new(w as f32, h as f32));
    let project = |v: V3| {
        camera
            .project(v, rect)
            .map(|(p, d, s)| (rect.center() + (p - rect.center()) * scale, d, s * scale))
    };
    let mut image = egui::ColorImage::new(size, Color32::from_rgb(235, 238, 240));
    let mut zbuf = vec![f32::INFINITY; w * h];
    for f in faces
        .iter()
        .filter(|f| f.color.a() == 255)
        .chain(faces.iter().filter(|f| f.color.a() < 255))
    {
        let uv = [
            Vec2::new(0., 0.),
            Vec2::new(1., 0.),
            Vec2::new(1., 1.),
            Vec2::new(0., 1.),
        ];
        let raw: Vec<_> = f
            .points
            .iter()
            .enumerate()
            .map(|(i, p)| Vertex { p: *p, uv: uv[i] })
            .collect();
        let poly = if camera.projection == Projection::Perspective {
            clip(&raw, camera)
        } else {
            raw
        };
        if poly.len() < 3 {
            continue;
        }
        for i in 1..poly.len() - 1 {
            let vertices = [poly[0], poly[i], poly[i + 1]];
            let mut screen = [Pos2::ZERO; 3];
            let mut depth = [0.; 3];
            let mut valid = true;
            for j in 0..3 {
                depth[j] = camera.distance - vertices[j].p.sub(camera.target).dot(camera.basis().2);
                if let Some((p, _, _)) = project(vertices[j].p) {
                    screen[j] = p;
                } else {
                    valid = false;
                }
            }
            if !valid {
                continue;
            }
            let edge =
                |a: Pos2, b: Pos2, c: Pos2| (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
            let area = edge(screen[0], screen[1], screen[2]);
            if area.abs() < 0.001 {
                continue;
            }
            let bounds = Rect::from_points(&screen).intersect(rect);
            if !bounds.is_positive() {
                continue;
            }
            for y in bounds.top().max(0.) as usize..(bounds.bottom().ceil() as usize).min(h) {
                for x in bounds.left().max(0.) as usize..(bounds.right().ceil() as usize).min(w) {
                    let p = Pos2::new(x as f32 + 0.5, y as f32 + 0.5);
                    let weights = [
                        edge(screen[1], screen[2], p) / area,
                        edge(screen[2], screen[0], p) / area,
                        edge(screen[0], screen[1], p) / area,
                    ];
                    if weights.iter().any(|v| *v < -0.0001) {
                        continue;
                    }
                    let mut interp = weights;
                    let z = if camera.projection == Projection::Perspective {
                        let inv = (0..3).map(|j| weights[j] / depth[j]).sum::<f32>();
                        for j in 0..3 {
                            interp[j] = weights[j] / depth[j] / inv;
                        }
                        1. / inv
                    } else {
                        (0..3).map(|j| weights[j] * depth[j]).sum()
                    };
                    let index = y * w + x;
                    if z >= zbuf[index] {
                        continue;
                    }
                    if f.color.a() == 255 {
                        zbuf[index] = z;
                    }
                    let mut c = if mode == RenderMode::Untextured {
                        Color32::from_gray(218)
                    } else {
                        f.color
                    };
                    if mode == RenderMode::Textures {
                        if let Some(surface) = &f.surface {
                            let uv =
                                (0..3).fold(Vec2::ZERO, |acc, j| acc + vertices[j].uv * interp[j]);
                            let (u, v) = if surface.grain == Grain::Length {
                                (uv.x, uv.y)
                            } else {
                                (uv.y, uv.x)
                            };
                            let wave =
                                (u * 43. + (v * 11. + surface.seed).sin() * 1.3 + surface.seed)
                                    .sin();
                            let fine = (u * 113. + v * 2.).sin();
                            let k = 0.98 + 0.035 * wave + 0.012 * fine;
                            c = Color32::from_rgb(
                                (c.r() as f32 * k).min(255.) as u8,
                                (c.g() as f32 * k).min(255.) as u8,
                                (c.b() as f32 * k).min(255.) as u8,
                            );
                            if let Some(tex) = &surface.texture {
                                let x = (u.clamp(0., 0.99999) * tex.size[0] as f32) as usize;
                                let y = (v.clamp(0., 0.99999) * tex.size[1] as f32) as usize;
                                c = tex.pixels[y * tex.size[0] + x];
                            }
                        }
                    }
                    if c.a() < 255 {
                        let rgba = c.to_srgba_unmultiplied();
                        let a = rgba[3] as f32 / 255.;
                        let old = image.pixels[index];
                        c = Color32::from_rgb(
                            (rgba[0] as f32 * a + old.r() as f32 * (1. - a)) as u8,
                            (rgba[1] as f32 * a + old.g() as f32 * (1. - a)) as u8,
                            (rgba[2] as f32 * a + old.b() as f32 * (1. - a)) as u8,
                        );
                    }
                    image.pixels[index] = c;
                }
            }
        }
    }
    // Depth-tested perimeter edges, without triangulation diagonals or hidden back edges.
    for f in faces {
        for k in 0..4 {
            let mut a = f.points[k];
            let mut b = f.points[(k + 1) % 4];
            let depth = |v: V3| camera.distance - v.sub(camera.target).dot(camera.basis().2);
            let mut da = depth(a);
            let mut db = depth(b);
            if camera.projection == Projection::Perspective {
                if da < 10. && db < 10. {
                    continue;
                }
                if da < 10. {
                    a = a.add(b.sub(a).mul((10. - da) / (db - da)));
                    da = 10.;
                }
                if db < 10. {
                    b = b.add(a.sub(b).mul((10. - db) / (da - db)));
                    db = 10.;
                }
            }
            if let (Some(pa), Some(pb)) = (project(a), project(b)) {
                let delta = pb.0 - pa.0;
                let steps = delta.x.abs().max(delta.y.abs()).ceil().min(20000.) as usize;
                for step in 0..=steps {
                    let t = step as f32 / steps.max(1) as f32;
                    let q = pa.0 + delta * t;
                    let x = q.x.floor() as isize;
                    let y = q.y.floor() as isize;
                    if x < 0 || y < 0 || x >= w as isize || y >= h as isize {
                        continue;
                    }
                    let z = if camera.projection == Projection::Perspective {
                        1. / ((1. - t) / da + t / db)
                    } else {
                        da * (1. - t) + db * t
                    };
                    let i = y as usize * w + x as usize;
                    if z <= zbuf[i] + 2.5 {
                        image.pixels[i] = Color32::BLACK;
                    }
                }
            }
        }
    }
    image
}
/// Cache pixels when only UI hover changes; geometry/camera/material changes invalidate it.
#[derive(Clone)]
struct RenderCache {
    key: u64,
    texture: egui::TextureHandle,
}
pub fn paint(p: &egui::Painter, rect: Rect, faces: &[Face], camera: Camera, mode: RenderMode) {
    use std::hash::{Hash, Hasher};
    let moving = p
        .ctx()
        .input(|i| i.pointer.any_down() || i.smooth_scroll_delta.y.abs() > 0.1);
    let scale = if moving { 0.6 } else { 1. };
    let size = [
        (rect.width() * scale).ceil().max(1.) as usize,
        (rect.height() * scale).ceil().max(1.) as usize,
    ];
    let mut hash = std::collections::hash_map::DefaultHasher::new();
    size.hash(&mut hash);
    (mode as u8).hash(&mut hash);
    (camera.projection as u8).hash(&mut hash);
    for n in [
        camera.target.x,
        camera.target.y,
        camera.target.z,
        camera.yaw,
        camera.pitch,
        camera.distance,
    ] {
        n.to_bits().hash(&mut hash);
    }
    for f in faces {
        for v in f.points {
            v.x.to_bits().hash(&mut hash);
            v.y.to_bits().hash(&mut hash);
            v.z.to_bits().hash(&mut hash);
        }
        f.color.to_array().hash(&mut hash);
        if let Some(s) = &f.surface {
            (s.grain as u8).hash(&mut hash);
            s.seed.to_bits().hash(&mut hash);
            if let Some(t) = &s.texture {
                (std::sync::Arc::as_ptr(t) as usize).hash(&mut hash);
            }
        }
    }
    let key = hash.finish();
    let id = egui::Id::new("depth_renderer_cache");
    let previous = p.ctx().data_mut(|d| d.get_temp::<RenderCache>(id));
    let cache = if let Some(c) = previous.filter(|c| c.key == key) {
        c
    } else {
        let img = image_scaled(faces, camera, size, mode, scale);
        RenderCache {
            key,
            texture: p
                .ctx()
                .load_texture("Scene 3D", img, egui::TextureOptions::LINEAR),
        }
    };
    p.image(
        cache.texture.id(),
        rect,
        Rect::from_min_max(Pos2::ZERO, Pos2::new(1., 1.)),
        Color32::WHITE,
    );
    p.ctx().data_mut(|d| d.insert_temp(id, cache));
}
pub fn mark(faces: &mut [Face], material: &str, materials: &[MaterialData], grain: Grain) {
    if let Some(m) = materials.iter().find(|m| m.name == material) {
        let texture = texture(&m.texture_path);
        if m.has_grain || texture.is_some() {
            let seed = material.bytes().map(|b| b as u32).sum::<u32>() as f32;
            for f in faces {
                f.surface = Some(Surface {
                    grain,
                    seed,
                    texture: texture.clone(),
                });
            }
        }
    }
}
pub fn texture(path: &str) -> Option<std::sync::Arc<egui::ColorImage>> {
    if path.is_empty() {
        return None;
    }
    thread_local! {static CACHE:std::cell::RefCell<std::collections::HashMap<String,std::sync::Arc<egui::ColorImage>>>=std::cell::RefCell::new(std::collections::HashMap::new());}
    CACHE.with(|cache| {
        if let Some(image) = cache.borrow().get(path) {
            return Some(image.clone());
        }
        let meta = std::fs::metadata(path).ok()?;
        if meta.len() > 20_000_000 {
            return None;
        }
        let image = image::open(path).ok()?.thumbnail(512, 512).to_rgba8();
        let pixels = egui::ColorImage::from_rgba_unmultiplied(
            [image.width() as usize, image.height() as usize],
            image.as_raw(),
        );
        let image = std::sync::Arc::new(pixels);
        let mut map = cache.borrow_mut();
        if map.len() >= 64 {
            map.clear();
        }
        map.insert(path.into(), image.clone());
        Some(image)
    })
}
pub fn visible_wall(w: &Wall, camera: Camera, room: [u32; 3]) -> bool {
    let eye = camera.target.add(camera.basis().2.mul(camera.distance));
    let dx = w.end.x - w.start.x;
    let dz = w.end.z - w.start.z;
    let side = |x: f32, z: f32| dx * (z - w.start.z) - dz * (x - w.start.x);
    side(eye.x, eye.z) * side(room[0] as f32 / 2., room[2] as f32 / 2.) >= 0.
}
/// Project a small local floor basis: stable at eye level with a bounded fallback.
pub fn drag_delta(camera: Camera, rect: Rect, center: V3, delta: Vec2) -> P2 {
    let a = camera.project(center, rect);
    let b = camera.project(center.add(V3::new(100., 0., 0.)), rect);
    let c = camera.project(center.add(V3::new(0., 0., 100.)), rect);
    if let (Some(a), Some(b), Some(c)) = (a, b, c) {
        let u = b.0 - a.0;
        let v = c.0 - a.0;
        let det = u.x * v.y - u.y * v.x;
        if camera.pitch.abs() > 0.12 && det.abs() > 0.4 {
            let x = 100. * (delta.x * v.y - delta.y * v.x) / det;
            let z = 100. * (u.x * delta.y - u.y * delta.x) / det;
            return P2::new(x.clamp(-500., 500.), z.clamp(-500., 500.));
        }
    }
    let (r, _, toward) = camera.basis();
    let scale = camera.distance / 1700.;
    P2::new(
        (r.x * delta.x + toward.x * delta.y) * scale,
        (r.z * delta.x + toward.z * delta.y) * scale,
    )
}
pub fn pick(
    p: Pos2,
    rect: Rect,
    camera: Camera,
    modules: &[Module],
    hidden: &[u32],
) -> Option<u32> {
    let (r, u, t) = camera.basis();
    let nx = (p.x - rect.center().x) / 1700.;
    let ny = -(p.y - rect.center().y) / 1700.;
    let (origin, direction) = if camera.projection == Projection::Perspective {
        (
            camera.target.add(t.mul(camera.distance)),
            r.mul(nx).add(u.mul(ny)).sub(t),
        )
    } else {
        (
            camera
                .target
                .add(t.mul(camera.distance))
                .add(r.mul(nx * camera.distance))
                .add(u.mul(ny * camera.distance)),
            t.mul(-1.),
        )
    };
    let cross = |a: V3, b: V3| {
        V3::new(
            a.y * b.z - a.z * b.y,
            a.z * b.x - a.x * b.z,
            a.x * b.y - a.y * b.x,
        )
    };
    let mut best = f32::INFINITY;
    let mut id = None;
    for m in modules.iter().filter(|m| !hidden.contains(&m.id)) {
        let mut faces = vec![];
        append_module_faces(&mut faces, camera, m, &[], false);
        for f in faces {
            for tri in [[0, 1, 2], [0, 2, 3]] {
                let a = f.points[tri[0]];
                let e1 = f.points[tri[1]].sub(a);
                let e2 = f.points[tri[2]].sub(a);
                let h = cross(direction, e2);
                let det = e1.dot(h);
                if det.abs() < 0.00001 {
                    continue;
                }
                let s = origin.sub(a);
                let u = s.dot(h) / det;
                if !(0.0..=1.0).contains(&u) {
                    continue;
                }
                let q = cross(s, e1);
                let v = direction.dot(q) / det;
                if v < 0. || u + v > 1. {
                    continue;
                }
                let distance = e2.dot(q) / det;
                if distance > 0. && distance < best {
                    best = distance;
                    id = Some(m.id);
                }
            }
        }
    }
    id
}
pub fn save(app: &FurnitureApp, path: &str) -> image::ImageResult<()> {
    let walls: Vec<_> = app
        .walls
        .iter()
        .filter(|w| !app.cutaway || visible_wall(w, app.camera, app.room))
        .cloned()
        .collect();
    let faces = scene_faces(
        app.camera,
        app.room,
        &walls,
        &app.openings,
        &app.modules,
        &app.panels,
        &app.gesso,
        &app.decor,
        &app.materials,
        &app.effective_hidden(),
        &app.floor_texture,
    );
    let img = image(&faces, app.camera, [1200, 800], app.render_mode);
    let rgba: Vec<u8> = img.pixels.iter().flat_map(|p| p.to_array()).collect();
    image::save_buffer(path, &rgba, 1200, 800, image::ColorType::Rgba8)
}

pub fn hit_faces(p: Pos2, rect: Rect, camera: Camera, faces: &[Face]) -> Option<f32> {
    let (r, u, t) = camera.basis();
    let nx = (p.x - rect.center().x) / 1700.;
    let ny = -(p.y - rect.center().y) / 1700.;
    let (origin, direction) = if camera.projection == Projection::Perspective {
        (
            camera.target.add(t.mul(camera.distance)),
            r.mul(nx).add(u.mul(ny)).sub(t),
        )
    } else {
        (
            camera
                .target
                .add(t.mul(camera.distance))
                .add(r.mul(nx * camera.distance))
                .add(u.mul(ny * camera.distance)),
            t.mul(-1.),
        )
    };
    let cross = |a: V3, b: V3| {
        V3::new(
            a.y * b.z - a.z * b.y,
            a.z * b.x - a.x * b.z,
            a.x * b.y - a.y * b.x,
        )
    };
    let mut best = f32::INFINITY;
    for f in faces {
        for tri in [[0, 1, 2], [0, 2, 3]] {
            let a = f.points[tri[0]];
            let e1 = f.points[tri[1]].sub(a);
            let e2 = f.points[tri[2]].sub(a);
            let h = cross(direction, e2);
            let det = e1.dot(h);
            if det.abs() < 0.00001 {
                continue;
            }
            let s = origin.sub(a);
            let u = s.dot(h) / det;
            if !(0.0..=1.0).contains(&u) {
                continue;
            }
            let q = cross(s, e1);
            let v = direction.dot(q) / det;
            if v < 0. || u + v > 1. {
                continue;
            }
            let distance = e2.dot(q) / det;
            if distance > 0. {
                best = best.min(distance);
            }
        }
    }
    if best.is_finite() {
        Some(best)
    } else {
        None
    }
}
impl FurnitureApp {
    pub fn pick_scene(&self, p: Pos2, rect: Rect) -> Option<Selection> {
        let hidden = self.effective_hidden();
        let mut best = f32::INFINITY;
        let mut selected = None;
        let camera = self.camera;
        let mut candidate = |s: Selection, faces: Vec<Face>| {
            if hidden.contains(&editing::id(s)) {
                return;
            }
            if let Some(t) = hit_faces(p, rect, camera, &faces) {
                if t < best {
                    best = t;
                    selected = Some(s);
                }
            }
        };
        for m in &self.modules {
            let mut faces = vec![];
            append_module_faces(&mut faces, camera, m, &self.materials, false);
            candidate(Selection::Module(m.id), faces);
        }
        for d in &self.decor {
            let mut faces = vec![];
            designers::decor_faces(&mut faces, camera, d);
            candidate(Selection::Decor(d.id), faces);
        }
        for b in &self.panels {
            let mut faces = vec![];
            automation::panel_faces(&mut faces, camera, b, &self.materials);
            candidate(Selection::Panel(b.id), faces);
        }
        for w in &self.walls {
            if self.cutaway && !visible_wall(w, camera, self.room) {
                continue;
            }
            let os: Vec<_> = self
                .openings
                .iter()
                .filter(|o| o.wall_id == w.id)
                .cloned()
                .collect();
            let mut faces = vec![];
            append_wall_faces(&mut faces, camera, w, &os);
            candidate(Selection::Wall(w.id), faces);
            for o in &os {
                let mut faces = vec![];
                append_opening_faces(&mut faces, camera, w, o, &self.materials);
                candidate(Selection::Opening(o.id), faces);
            }
        }
        for g in &self.gesso {
            let mut faces = vec![];
            let y = self.room[1].saturating_sub(g.drop_mm) as f32;
            append_box(
                &mut faces,
                camera,
                V3::new(g.x_mm as f32, y, g.z_mm as f32),
                V3::new(
                    (g.x_mm + g.width_mm) as f32,
                    y + g.thickness_mm as f32,
                    (g.z_mm + g.depth_mm) as f32,
                ),
                Color32::WHITE,
            );
            candidate(Selection::Gesso(g.id), faces);
        }
        selected
    }
}
