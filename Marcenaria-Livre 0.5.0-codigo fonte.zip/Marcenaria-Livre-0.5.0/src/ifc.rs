//! IFC4 exchange: native swept-solid parameters, typed products, materials and properties.
use super::*;
struct Writer {
    data: String,
    next: u32,
    seq: u64,
    namespace: u64,
}
fn text(s: &str) -> String {
    let mut out = String::new();
    for c in s.chars() {
        if c == '\'' {
            out.push_str("''");
        } else if c == '\\' || !c.is_ascii() {
            let mut utf = [0; 2];
            out.push_str("\\X2\\");
            for u in c.encode_utf16(&mut utf) {
                out.push_str(&format!("{u:04X}"));
            }
            out.push_str("\\X0\\");
        } else {
            out.push(c);
        }
    }
    format!("'{out}'")
}
impl Writer {
    fn add(&mut self, s: String) -> u32 {
        let id = self.next;
        self.next += 1;
        self.data.push_str(&format!("#{id}={s};\n"));
        id
    }
    fn guid(&mut self) -> String {
        self.seq += 1;
        let mut n = ((self.namespace as u128) << 64) | self.seq as u128;
        let alphabet = b"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$";
        let mut out = [b'0'; 22];
        for i in (0..22).rev() {
            out[i] = alphabet[(n & 63) as usize];
            n >>= 6;
        }
        String::from_utf8(out.to_vec()).unwrap()
    }
    fn rel(&mut self, kind: &str, a: u32, bs: &[u32]) {
        if bs.is_empty() {
            return;
        }
        let g = self.guid();
        let refs = bs
            .iter()
            .map(|i| format!("#{i}"))
            .collect::<Vec<_>>()
            .join(",");
        self.add(format!("{kind}('{g}',$,$,$,#{a},({refs}))"));
    }
    fn properties(&mut self, product: u32, values: Vec<(&str, String)>) {
        let mut refs = vec![];
        for (k, v) in values {
            refs.push(self.add(format!(
                "IFCPROPERTYSINGLEVALUE({},$,IFCTEXT({}),$)",
                text(k),
                text(&v)
            )));
        }
        let g = self.guid();
        let p = self.add(format!(
            "IFCPROPERTYSET('{g}',$,'MarcenariaLivre',$,({}))",
            refs.iter()
                .map(|i| format!("#{i}"))
                .collect::<Vec<_>>()
                .join(",")
        ));
        let g = self.guid();
        self.add(format!(
            "IFCRELDEFINESBYPROPERTIES('{g}',$,$,$,(#{product}),#{p})"
        ));
    }
    fn product(&mut self, kind: &str, name: &str, faces: &[Face], tail: &str) -> u32 {
        let mut solids = vec![];
        let complete = faces.len() / 6 * 6;
        let mut expanded = faces[..complete].to_vec();
        for f in &faces[complete..] {
            let u = f.points[1].sub(f.points[0]);
            let length = u.dot(u).sqrt();
            if length < 0.01 {
                continue;
            }
            let offset = V3::new(-u.z / length * 2., 0., u.x / length * 2.);
            let mut back = f.clone();
            for p in &mut back.points {
                *p = p.add(offset);
            }
            expanded.extend([f.clone(), back, f.clone(), f.clone(), f.clone(), f.clone()]);
        }

        for box_ in expanded.chunks_exact(6) {
            let a = box_[0].points[0];
            let b = box_[0].points[1];
            let d = box_[0].points[3];
            let e = box_[1].points[0];
            let u = b.sub(a);
            let v = e.sub(a);
            let width = u.dot(u).sqrt();
            let depth = v.dot(v).sqrt();
            let height = d.y - a.y;
            if width < 0.01 || depth < 0.01 || height < 0.01 {
                continue;
            }
            let center = a.add(u.mul(0.5)).add(v.mul(0.5));
            let point = self.add(format!(
                "IFCCARTESIANPOINT(({:.5},{:.5},{:.5}))",
                center.x, center.z, center.y
            ));
            let direction = self.add(format!(
                "IFCDIRECTION(({:.9},{:.9},0.))",
                u.x / width,
                u.z / width
            ));
            let axis = self.add(format!("IFCAXIS2PLACEMENT3D(#{point},#5,#{direction})"));
            let profile = self.add(format!(
                "IFCRECTANGLEPROFILEDEF(.AREA.,$,$,{width:.5},{depth:.5})"
            ));
            let solid = self.add(format!(
                "IFCEXTRUDEDAREASOLID(#{profile},#{axis},#5,{height:.5})"
            ));
            solids.push(solid);
            let rgba = box_[1].color.to_srgba_unmultiplied();
            let color = self.add(format!(
                "IFCCOLOURRGB($,{:.5},{:.5},{:.5})",
                rgba[0] as f32 / 255.,
                rgba[1] as f32 / 255.,
                rgba[2] as f32 / 255.
            ));
            let rendering = self.add(format!(
                "IFCSURFACESTYLERENDERING(#{color},{:.5},$,$,$,$,$,$,.NOTDEFINED.)",
                1. - rgba[3] as f32 / 255.
            ));
            let style = self.add(format!("IFCSURFACESTYLE($,.BOTH.,(#{rendering}))"));
            self.add(format!("IFCSTYLEDITEM(#{solid},(#{style}),$)"));
        }
        let representation = if solids.is_empty() {
            "$".into()
        } else {
            let shape = self.add(format!(
                "IFCSHAPEREPRESENTATION(#2,'Body','SweptSolid',({}))",
                solids
                    .iter()
                    .map(|i| format!("#{i}"))
                    .collect::<Vec<_>>()
                    .join(",")
            ));
            let product_shape = self.add(format!("IFCPRODUCTDEFINITIONSHAPE($,$,(#{shape}))"));
            format!("#{product_shape}")
        };
        let g = self.guid();
        self.add(format!(
            "{kind}('{g}',$,{},$,$,#17,{representation},${tail})",
            text(name)
        ))
    }
    fn decorative_profile(&mut self, d: &DecorItem) -> u32 {
        let mut refs = vec![];
        for p in &d.outline {
            refs.push(self.add(format!(
                "IFCCARTESIANPOINT(({:.5},{:.5}))",
                p.x * d.width_mm as f32,
                p.z * d.depth_mm as f32
            )));
        }
        refs.push(refs[0]);
        let curve = self.add(format!(
            "IFCPOLYLINE(({}))",
            refs.iter()
                .map(|i| format!("#{i}"))
                .collect::<Vec<_>>()
                .join(",")
        ));
        let profile = self.add(format!("IFCARBITRARYCLOSEDPROFILEDEF(.AREA.,$,#{curve})"));
        let origin = self.add(format!(
            "IFCCARTESIANPOINT(({}.,{}.,{}.))",
            d.x_mm, d.z_mm, d.y_mm
        ));
        let (s, c) = d.rotation_deg.to_radians().sin_cos();
        let direction = self.add(format!("IFCDIRECTION(({c:.9},{s:.9},0.))"));
        let axis = self.add(format!("IFCAXIS2PLACEMENT3D(#{origin},#5,#{direction})"));
        let solid = self.add(format!(
            "IFCEXTRUDEDAREASOLID(#{profile},#{axis},#5,{}.)",
            d.height_mm
        ));
        let shape = self.add(format!(
            "IFCSHAPEREPRESENTATION(#2,'Body','SweptSolid',(#{solid}))"
        ));
        let representation = self.add(format!("IFCPRODUCTDEFINITIONSHAPE($,$,(#{shape}))"));
        let g = self.guid();
        let object = self.add(format!(
            "IFCBUILDINGELEMENTPROXY('{g}',$,{},$,$,#17,#{representation},$,.NOTDEFINED.)",
            text(&d.name)
        ));
        self.material(object, &d.material);
        object
    }
    fn material(&mut self, product: u32, name: &str) {
        let m = self.add(format!("IFCMATERIAL({},$,$)", text(name)));
        let g = self.guid();
        self.add(format!(
            "IFCRELASSOCIATESMATERIAL('{g}',$,$,$,(#{product}),#{m})"
        ));
    }
}
pub fn project(app: &FurnitureApp) -> String {
    let hash = app.project_id;
    let mut w = Writer {
        data: String::new(),
        next: 18,
        seq: 20,
        namespace: hash,
    };
    let g: Vec<_> = (0..7).map(|_| w.guid()).collect();
    w.data=format!("#1=IFCPROJECT('{}',$,'Marcenaria Livre',$,$,$,$,(#2),#7);\n#2=IFCGEOMETRICREPRESENTATIONCONTEXT($,'Model',3,0.001,#3,$);\n#3=IFCAXIS2PLACEMENT3D(#4,#5,#6);\n#4=IFCCARTESIANPOINT((0.,0.,0.));\n#5=IFCDIRECTION((0.,0.,1.));\n#6=IFCDIRECTION((1.,0.,0.));\n#7=IFCUNITASSIGNMENT((#8));\n#8=IFCSIUNIT(*,.LENGTHUNIT.,.MILLI.,.METRE.);\n#9=IFCSITE('{}',$,'Obra',$,$,#17,$,$,.ELEMENT.,$,$,$,$,$);\n#10=IFCBUILDING('{}',$,'Edificacao',$,$,#17,$,$,.ELEMENT.,$,$,$);\n#11=IFCBUILDINGSTOREY('{}',$,'Pavimento',$,$,#17,$,$,.ELEMENT.,0.);\n#12=IFCRELAGGREGATES('{}',$,$,$,#1,(#9));\n#13=IFCRELAGGREGATES('{}',$,$,$,#9,(#10));\n#14=IFCRELAGGREGATES('{}',$,$,$,#10,(#11));\n#17=IFCLOCALPLACEMENT($,#3);\n",g[0],g[1],g[2],g[3],g[4],g[5],g[6]);
    let camera = Camera::reset(app.room);
    let mut elements = vec![];
    for wall in &app.walls {
        let os: Vec<_> = app
            .openings
            .iter()
            .filter(|o| o.wall_id == wall.id)
            .cloned()
            .collect();
        let mut faces = vec![];
        append_wall_faces(&mut faces, camera, wall, &os);
        let id = w.product(
            "IFCWALL",
            &format!("Parede {}", wall.id),
            &faces,
            ",.NOTDEFINED.",
        );
        elements.push(id);
        w.material(id, &wall.material);
        w.properties(
            id,
            vec![
                ("Id", wall.id.to_string()),
                ("Espessura_mm", wall.thickness_mm.to_string()),
                ("Altura_mm", wall.height_mm.to_string()),
                ("Comprimento_mm", wall.start.distance(wall.end).to_string()),
            ],
        );
        for o in &os {
            let len = wall.start.distance(wall.end);
            if len <= 0. {
                continue;
            }
            let angle = (wall.end.z - wall.start.z).atan2(wall.end.x - wall.start.x);
            let center = V3::new(
                wall.start.x + angle.cos() * o.center_mm as f32,
                o.sill_mm as f32,
                wall.start.z + angle.sin() * o.center_mm as f32,
            );
            let mut opening_faces = vec![];
            append_box(
                &mut opening_faces,
                camera,
                V3::new(
                    -(o.width_mm as f32) / 2.,
                    0.,
                    -(wall.thickness_mm as f32) / 2.,
                ),
                V3::new(
                    o.width_mm as f32 / 2.,
                    o.height_mm as f32,
                    wall.thickness_mm as f32 / 2.,
                ),
                Color32::WHITE,
            );
            for f in &mut opening_faces {
                for p in &mut f.points {
                    let (x, z) = (p.x, p.z);
                    *p = V3::new(
                        center.x + x * angle.cos() - z * angle.sin(),
                        center.y + p.y,
                        center.z + x * angle.sin() + z * angle.cos(),
                    );
                }
            }
            let hole = w.product(
                "IFCOPENINGELEMENT",
                &format!("Vao {}", o.id),
                &opening_faces,
                ",.OPENING.",
            );
            let g = w.guid();
            w.add(format!("IFCRELVOIDSELEMENT('{g}',$,$,$,#{id},#{hole})"));
            let mut f = vec![];
            append_opening_faces(&mut f, camera, wall, o, &app.materials);
            let kind = if o.kind == OpeningKind::Door {
                "IFCDOOR"
            } else {
                "IFCWINDOW"
            };
            let tail = format!(
                ",{:.3}, {:.3},.NOTDEFINED.,.NOTDEFINED.,$",
                o.height_mm as f32, o.width_mm as f32
            );
            let door = w.product(kind, &o.style, &f, &tail);
            elements.push(door);
            let g = w.guid();
            w.add(format!("IFCRELFILLSELEMENT('{g}',$,$,$,#{hole},#{door})"));
            w.material(door, &o.material);
            w.properties(
                door,
                vec![
                    ("Id", o.id.to_string()),
                    ("Estilo", o.style.clone()),
                    ("Peitoril_mm", o.sill_mm.to_string()),
                ],
            );
        }
    }
    for m in &app.modules {
        let mut faces = vec![];
        append_module_faces(&mut faces, camera, m, &app.materials, false);
        let id = w.product(
            "IFCFURNITURE",
            &m.name,
            &faces,
            ",.NOTDEFINED.,.NOTDEFINED.",
        );
        elements.push(id);
        w.material(id, &m.material);
        w.properties(
            id,
            vec![
                ("Id", m.id.to_string()),
                ("Largura_mm", m.width_mm.to_string()),
                ("Altura_mm", m.height_mm.to_string()),
                ("Profundidade_mm", m.depth_mm.to_string()),
                ("Espessura_mm", m.thickness_mm.to_string()),
                ("Portas", m.door_count.to_string()),
                ("Prateleiras", m.shelf_count.to_string()),
                ("Gavetas", m.drawer_count.to_string()),
                ("Divisorias", m.divider_count.to_string()),
                ("MaterialFrentes", m.door_material.clone()),
                ("EstiloFrentes", format!("{:?}", m.door_styles)),
                ("Veio", format!("{:?}", m.grain)),
                ("PuxadoresEDobradicas", fronts::encode(&m.handles)),
                ("MetodoConstrutivo", app.fabrication.fields().join("|")),
            ],
        );
    }
    for p in &app.panels {
        let mut faces = vec![];
        automation::panel_faces(&mut faces, camera, p, &app.materials);
        let id = w.product("IFCPLATE", &p.name, &faces, ",.NOTDEFINED.");
        elements.push(id);
        w.material(id, &p.material);
        w.properties(
            id,
            vec![
                ("Largura_mm", p.width_mm.to_string()),
                ("Altura_mm", p.height_mm.to_string()),
                ("Espessura_mm", p.thickness_mm.to_string()),
                ("Veio", format!("{:?}", p.grain)),
            ],
        );
    }
    for g in &app.gesso {
        let mut faces = vec![];
        let y = app.room[1].saturating_sub(g.drop_mm) as f32;
        append_box(
            &mut faces,
            camera,
            V3::new(g.x_mm as f32, y, g.z_mm as f32),
            V3::new(
                (g.x_mm + g.width_mm) as f32,
                y + g.thickness_mm as f32,
                (g.z_mm + g.depth_mm) as f32,
            ),
            Color32::WHITE,
        );
        elements.push(w.product("IFCCOVERING", "Teto / gesso", &faces, ",.CEILING."));
    }
    let mut floor = vec![];
    append_box(
        &mut floor,
        camera,
        V3::new(0., -20., 0.),
        V3::new(app.room[0] as f32, 0., app.room[2] as f32),
        Color32::LIGHT_GRAY,
    );
    let id = w.product("IFCSLAB", "Piso", &floor, ",.FLOOR.");
    w.material(id, &app.floor_texture);
    elements.push(id);
    for d in &app.decor {
        let mut faces = vec![];
        designers::decor_faces(&mut faces, camera, d);
        let id = if d.outline.len() >= 3 && geometry::triangulate(&d.outline).is_some() {
            w.decorative_profile(d)
        } else {
            w.product("IFCBUILDINGELEMENTPROXY", &d.name, &faces, ",.NOTDEFINED.")
        };
        w.properties(
            id,
            vec![
                ("Categoria", "Decoracao".into()),
                ("Orcavel", "false".into()),
            ],
        );
        elements.push(id);
    }
    let g = w.guid();
    w.add(format!(
        "IFCRELCONTAINEDINSPATIALSTRUCTURE('{g}',$,$,$,({}),#11)",
        elements
            .iter()
            .map(|i| format!("#{i}"))
            .collect::<Vec<_>>()
            .join(",")
    ));
    format!("ISO-10303-21;\nHEADER;\nFILE_DESCRIPTION(('Marcenaria Livre IFC4 swept solids'),'2;1');\nFILE_NAME('projeto.ifc','2026-10-10T00:00:00',(''),(''),'Marcenaria Livre','Marcenaria Livre','');\nFILE_SCHEMA(('IFC4'));\nENDSEC;\nDATA;\n{}ENDSEC;\nEND-ISO-10303-21;\n",w.data)
}
