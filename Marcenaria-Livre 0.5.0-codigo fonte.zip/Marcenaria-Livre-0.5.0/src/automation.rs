use super::*;
#[derive(Clone, Debug)]
pub struct Settings {
    pub thickness: u32,
    pub advance: u32,
    pub height: u32,
    pub material: String,
    pub selected_only: bool,
    pub top: bool,
    pub plinth: bool,
    pub crown: bool,
    pub envelope: bool,
}
impl Default for Settings {
    fn default() -> Self {
        Self {
            thickness: 18,
            advance: 20,
            height: 100,
            material: "Carvalho claro".into(),
            selected_only: false,
            top: true,
            plinth: false,
            crown: false,
            envelope: false,
        }
    }
}
impl Settings {
    pub fn fields(&self) -> Vec<String> {
        vec![
            "AUTOMATION".into(),
            self.thickness.to_string(),
            self.advance.to_string(),
            self.height.to_string(),
            mar_escape(&self.material),
            self.selected_only.to_string(),
            self.top.to_string(),
            self.plinth.to_string(),
            self.crown.to_string(),
            self.envelope.to_string(),
        ]
    }
    pub fn parse(f: &[&str]) -> Result<Self, String> {
        Ok(Self {
            thickness: mar_num(f, 1)?,
            advance: mar_num(f, 2)?,
            height: mar_num(f, 3)?,
            material: mar_text(f, 4)?,
            selected_only: mar_num(f, 5)?,
            top: mar_num(f, 6)?,
            plinth: mar_num(f, 7)?,
            crown: mar_num(f, 8)?,
            envelope: mar_num(f, 9)?,
        })
    }
}
fn panel(
    app: &mut FurnitureApp,
    m: &Module,
    kind: &str,
    local: V3,
    w: u32,
    h: u32,
    horizontal: bool,
    turn: f32,
) -> bool {
    let a = m.rotation_deg.to_radians();
    let (sn, cs) = a.sin_cos();
    let x = m.x_mm as f32 + local.x * cs - local.z * sn;
    let z = m.z_mm as f32 + local.x * sn + local.z * cs;
    if x < 0.0 || z < 0.0 {
        return false;
    }
    let name = format!("Auto M{} · {}", m.id, kind);
    let id = if let Some(p) = app.panels.iter().find(|p| p.name == name) {
        p.id
    } else {
        let id = app.next_id;
        app.next_id += 1;
        id
    };
    let p = WoodPanel {
        id,
        name,
        rotation_deg: m.rotation_deg + turn,
        horizontal,
        x_mm: x.round() as u32,
        y_mm: (m.y_mm as f32 + local.y).max(0.0).round() as u32,
        z_mm: z.round() as u32,
        width_mm: w,
        height_mm: h,
        thickness_mm: app.automation.thickness,
        material: app.automation.material.clone(),
        grain: Grain::Length,
    };
    if let Some(old) = app.panels.iter_mut().find(|p| p.id == id) {
        *old = p;
    } else {
        app.panels.push(p);
    }
    true
}
pub fn apply(app: &mut FurnitureApp, kinds: &[&str]) {
    let modules: Vec<_> = app
        .modules
        .iter()
        .filter(|m| {
            !app.hidden_ids.contains(&m.id)
                && (!app.automation.selected_only || app.selected == Some(Selection::Module(m.id)))
        })
        .cloned()
        .collect();
    let mut count = 0;
    let mut skipped = 0;
    for m in modules {
        for kind in kinds {
            let t = app.automation.thickness;
            let advance = app.automation.advance;
            let h = app.automation.height;
            match *kind {
                "Tampo" if matches!(m.kind, ModuleKind::Base | ModuleKind::Drawer) => {
                    count += panel(
                        app,
                        &m,
                        "Tampo",
                        V3::new(0.0, m.height_mm as f32, -(advance as f32)),
                        m.width_mm,
                        m.depth_mm + advance,
                        true,
                        0.0,
                    ) as usize;
                }
                "Rodapé" if matches!(m.kind, ModuleKind::Base | ModuleKind::Drawer) => {
                    if m.y_mm == 0 {
                        skipped += 1;
                        continue;
                    }
                    count += panel(
                        app,
                        &m,
                        "Rodapé",
                        V3::new(0.0, -(m.y_mm as f32), advance as f32),
                        m.width_mm,
                        m.y_mm,
                        false,
                        0.0,
                    ) as usize;
                }
                "Rodaforro" if m.kind == ModuleKind::Wall => {
                    count += panel(
                        app,
                        &m,
                        "Rodaforro",
                        V3::new(0.0, m.height_mm as f32, -(advance as f32)),
                        m.width_mm,
                        h,
                        false,
                        0.0,
                    ) as usize;
                }
                "Envelopamento" | "Fechamento" | "Tamponamento" => {
                    count += panel(
                        app,
                        &m,
                        "Lateral esquerda",
                        V3::new(0.0, 0.0, 0.0),
                        m.depth_mm + advance,
                        m.height_mm,
                        false,
                        90.0,
                    ) as usize;
                    count += panel(
                        app,
                        &m,
                        "Lateral direita",
                        V3::new((m.width_mm + t) as f32, 0.0, 0.0),
                        m.depth_mm + advance,
                        m.height_mm,
                        false,
                        90.0,
                    ) as usize;
                    if *kind != "Fechamento" {
                        count += panel(
                            app,
                            &m,
                            "Capa superior",
                            V3::new(0.0, m.height_mm as f32, 0.0),
                            m.width_mm,
                            m.depth_mm + advance,
                            true,
                            0.0,
                        ) as usize;
                    }
                }
                _ => {}
            }
        }
    }
    app.notice=format!("{} painéis gerados/atualizados. {} rodapés ignorados porque o módulo está no piso. Peças que ultrapassam a origem do ambiente não são geradas. Os painéis podem ser editados e entram na lista de peças.",count,skipped);
    app.notice_error = count == 0;
}
pub fn panel_faces(
    faces: &mut Vec<Face>,
    camera: Camera,
    p: &WoodPanel,
    materials: &[MaterialData],
) {
    let mut proxy = make_module(
        p.id,
        preset(
            "Painel",
            ModuleKind::Custom,
            p.width_mm,
            p.height_mm,
            p.thickness_mm,
            0,
            0,
            0,
            0,
        ),
        p.x_mm,
        p.z_mm,
    );
    proxy.rotation_deg = p.rotation_deg;
    let min = V3::new(p.x_mm as f32, p.y_mm as f32, p.z_mm as f32);
    let horizontal = p.horizontal || p.name.starts_with("Bancada de pedra");
    let max = min.add(if horizontal {
        V3::new(p.width_mm as f32, p.thickness_mm as f32, p.height_mm as f32)
    } else {
        V3::new(p.width_mm as f32, p.height_mm as f32, p.thickness_mm as f32)
    });
    append_module_box(
        faces,
        camera,
        &proxy,
        min,
        max,
        material_color_for(&p.material, materials),
        0.0,
        0.0,
    );
    if !horizontal && p.name.to_lowercase().contains("ripado") {
        let slat = (p.width_mm / 16).max(25);
        let step = slat + slat / 2;
        for x in (0..p.width_mm.saturating_sub(slat)).step_by(step as usize) {
            let a = min.add(V3::new(x as f32, 0.0, p.thickness_mm as f32));
            let b = a.add(V3::new(slat as f32, p.height_mm as f32, 12.0));
            append_module_box(
                faces,
                camera,
                &proxy,
                a,
                b,
                material_color_for(&p.material, materials),
                0.0,
                0.0,
            );
        }
    }
}
pub fn corners(p: &WoodPanel) -> [P2; 4] {
    let mut proxy = make_module(
        p.id,
        preset(
            "Painel",
            ModuleKind::Custom,
            p.width_mm,
            p.height_mm,
            if p.horizontal || p.name.starts_with("Bancada de pedra") {
                p.height_mm
            } else {
                p.thickness_mm
            },
            0,
            0,
            0,
            0,
        ),
        p.x_mm,
        p.z_mm,
    );
    proxy.rotation_deg = p.rotation_deg;
    module_corners(&proxy)
}
pub fn editor(app: &mut FurnitureApp, ui: &mut egui::Ui) {
    ui.heading(i18n::tr("⚙ Automatizações de marcenaria"));
    ui.label(i18n::tr("Configure os fechamentos e execute juntos. Repetir atualiza os painéis gerados para cada módulo."));
    ui.horizontal_wrapped(|ui| {
        ui.checkbox(&mut app.automation.top, i18n::tr("Tampos"));
        ui.checkbox(&mut app.automation.plinth, i18n::tr("Rodapés"));
        ui.checkbox(&mut app.automation.crown, i18n::tr("Rodaforros"));
        ui.checkbox(
            &mut app.automation.envelope,
            i18n::tr("Tamponamento / envelopamento"),
        );
    });
    property_field(ui, "Espessura", &mut app.automation.thickness, 6..=60);
    property_field(
        ui,
        "Avanço / recuo frontal",
        &mut app.automation.advance,
        0..=200,
    );
    property_field(ui, "Altura rodaforro", &mut app.automation.height, 20..=400);
    let choices = app
        .materials
        .iter()
        .map(|m| m.name.clone())
        .collect::<Vec<_>>();
    material_combo(
        ui,
        "Material dos fechamentos",
        &mut app.automation.material,
        &choices,
    );
    ui.checkbox(
        &mut app.automation.selected_only,
        i18n::tr("Aplicar somente ao módulo selecionado"),
    );
    ui.label(i18n::tr("Tampos e rodapés: balcões e gaveteiros. Rodaforro: aéreos. A altura do rodapé acompanha a elevação do módulo. Cada módulo recebe seus próprios painéis; junções contínuas entre módulos ainda exigem ajuste."));
    if ui
        .add_sized(
            [260.0, 48.0],
            egui::Button::new(i18n::tr("▶ Executar automatizações")),
        )
        .clicked()
    {
        let mut kinds = vec![];
        if app.automation.top {
            kinds.push("Tampo");
        }
        if app.automation.plinth {
            kinds.push("Rodapé");
        }
        if app.automation.crown {
            kinds.push("Rodaforro");
        }
        if app.automation.envelope {
            kinds.push("Envelopamento");
        }
        apply(app, &kinds);
    }
    if ui.button(i18n::tr("◩ Ver resultado no ambiente")).clicked() {
        app.page = Page::Scene;
    }
    ui.label(&app.notice);
}
