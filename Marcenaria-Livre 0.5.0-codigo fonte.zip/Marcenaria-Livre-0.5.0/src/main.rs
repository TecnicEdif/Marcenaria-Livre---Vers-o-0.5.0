mod automation;
mod bridge;
mod collision;
mod commands;
mod designers;
mod documentation;
mod editing;
mod fabrication;
mod fronts;
mod geometry;
mod i18n;
mod icons;
mod ifc;
mod layers;
mod production;
mod visual;
use eframe::egui::{self, Color32, Pos2, Rect, Sense, Stroke, Vec2};
use std::{fs, io, path::Path, process::Command};

const GREEN: Color32 = Color32::from_rgb(41, 105, 81);
const GRID: Color32 = Color32::from_rgb(206, 209, 210);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ModuleKind {
    Base,
    Wall,
    Tall,
    Drawer,
    OpenShelf,
    Custom,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Grain {
    Length,
    Width,
}
impl Grain {
    fn label(self) -> &'static str {
        match self {
            Self::Length => "No comprimento",
            Self::Width => "Na largura",
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum OpeningKind {
    Door,
    Window,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum DoorStyle {
    GlassHorizontal,
    GlassVertical,
    Plain,
    Provincial,
    Horizontal,
    Vertical,
    Cava,
    Glass,
    Aluminum,
}
impl DoorStyle {
    fn label(self) -> &'static str {
        match self {
            Self::GlassHorizontal => "Vidro • perfil horizontal",
            Self::GlassVertical => "Vidro • perfil vertical",
            Self::Plain => "Lisa",
            Self::Provincial => "Provençal",
            Self::Horizontal => "Perfil horizontal",
            Self::Vertical => "Perfil vertical",
            Self::Cava => "Cava",
            Self::Glass => "Vidro",
            Self::Aluminum => "Alumínio e vidro",
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Projection {
    Perspective,
    Orthographic,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum RenderMode {
    Textures,
    Colors,
    Untextured,
    Wireframe,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Page {
    GeometryDesigner,
    FinishDesigner,
    PanelDesigner,
    Plan,
    Scene,
    Parts,
    Materials,
    Method,
    Budget,
    OpeningLibrary,
    Documentation,
    ModuleBuilder,
    Preferences,
    Automation,
    Cut,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Tool {
    Select,
    Move,
    Wall,
    WallChain,
    WallCurve,
    Door,
    Window,
    Gesso,
    Panel,
    CopyMaterial,
    PaintMaterial,
    WallAnchor,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum CatalogTab {
    Kitchen,
    Bathroom,
    Bedroom,
    Living,
    Office,
    Store,
    Wardrobes,
    Shelves,
    Panels,
    Decor,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum InspectorTab {
    Tools,
    Properties,
    Room,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Selection {
    Module(u32),
    Wall(u32),
    Opening(u32),
    Panel(u32),
    Gesso(u32),
    Decor(u32),
}

#[derive(Clone, Copy, Debug, Default)]
struct P2 {
    x: f32,
    z: f32,
}
impl P2 {
    fn new(x: f32, z: f32) -> Self {
        Self { x, z }
    }
    fn distance(self, other: Self) -> f32 {
        ((self.x - other.x).powi(2) + (self.z - other.z).powi(2)).sqrt()
    }
}
#[derive(Clone, Copy, Debug, Default)]
struct V3 {
    x: f32,
    y: f32,
    z: f32,
}
impl V3 {
    fn new(x: f32, y: f32, z: f32) -> Self {
        Self { x, y, z }
    }
    fn dot(self, b: Self) -> f32 {
        self.x * b.x + self.y * b.y + self.z * b.z
    }
    fn sub(self, b: Self) -> Self {
        Self::new(self.x - b.x, self.y - b.y, self.z - b.z)
    }
    fn add(self, b: Self) -> Self {
        Self::new(self.x + b.x, self.y + b.y, self.z + b.z)
    }
    fn mul(self, s: f32) -> Self {
        Self::new(self.x * s, self.y * s, self.z * s)
    }
}

#[derive(Clone, Debug)]
struct Module {
    top_mode: u8,
    internal_drawer_height: u32,
    handles: Vec<fronts::Handle>,
    id: u32,
    name: String,
    kind: ModuleKind,
    x_mm: u32,
    y_mm: u32,
    z_mm: u32,
    rotation_deg: f32,
    width_mm: u32,
    height_mm: u32,
    depth_mm: u32,
    divider_count: u32,
    thickness_mm: u32,
    door_count: u32,
    shelf_count: u32,
    drawer_count: u32,
    material: String,
    door_material: String,
    grain: Grain,
    door_style: DoorStyle,
    door_styles: Vec<DoorStyle>,
    door_open: bool,
}
#[derive(Clone, Debug)]
struct Wall {
    material: String,
    color: Color32,
    id: u32,
    start: P2,
    end: P2,
    thickness_mm: u32,
    height_mm: u32,
}
#[derive(Clone, Debug)]
struct Opening {
    id: u32,
    wall_id: u32,
    kind: OpeningKind,
    center_mm: u32,
    width_mm: u32,
    height_mm: u32,
    sill_mm: u32,
    style: String,
    material: String,
}
#[derive(Clone, Debug)]
struct WoodPanel {
    rotation_deg: f32,
    horizontal: bool,
    id: u32,
    name: String,
    x_mm: u32,
    y_mm: u32,
    z_mm: u32,
    width_mm: u32,
    height_mm: u32,
    thickness_mm: u32,
    material: String,
    grain: Grain,
}
#[derive(Clone, Debug)]
struct GessoBlock {
    id: u32,
    x_mm: u32,
    z_mm: u32,
    width_mm: u32,
    depth_mm: u32,
    drop_mm: u32,
    thickness_mm: u32,
}
#[derive(Clone, Debug)]
struct DecorItem {
    outline: Vec<P2>,
    rotation_deg: f32,
    id: u32,
    name: String,
    material: String,
    x_mm: u32,
    y_mm: u32,
    z_mm: u32,
    width_mm: u32,
    height_mm: u32,
    depth_mm: u32,
    color: Color32,
}
#[derive(Clone, Debug)]
struct Part {
    group: String,
    name: String,
    quantity: u32,
    length_mm: u32,
    width_mm: u32,
    thickness_mm: u32,
    material: String,
    edge: String,
    grain: String,
}
#[derive(Clone)]
struct MaterialData {
    texture_path: String,
    name: String,
    price_m2: f32,
    has_grain: bool,
    gloss: u32,
    reflect: u32,
    color: Color32,
}
#[derive(Clone, Copy)]
struct Camera {
    target: V3,
    yaw: f32,
    pitch: f32,
    distance: f32,
    projection: Projection,
}
#[derive(Clone)]
struct Face {
    surface: Option<visual::Surface>,
    points: [V3; 4],
    color: Color32,
    depth: f32,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ViewKind {
    Plan,
    ThreeD,
    Front,
    Side,
}
impl ViewKind {
    fn label(self) -> &'static str {
        match self {
            Self::Plan => "Planta",
            Self::ThreeD => "Perspectiva",
            Self::Front => "Elevação frontal",
            Self::Side => "Elevação lateral",
        }
    }
}
#[derive(Clone, Copy, Debug)]
struct SheetViewport {
    offset_x: f32,
    offset_y: f32,
    kind: ViewKind,
    x: f32,
    y: f32,
    width: f32,
    height: f32,
}
#[derive(Clone, Copy)]
struct PlanTransform {
    rect: Rect,
    center: Pos2,
    scale: f32,
    room_w: f32,
    room_d: f32,
}
#[derive(Clone, Copy)]
struct Preset {
    name: &'static str,
    kind: ModuleKind,
    width: u32,
    height: u32,
    depth: u32,
    y: u32,
    doors: u32,
    shelves: u32,
    drawers: u32,
}
#[derive(Clone)]
struct ProjectSnapshot {
    method_values: (u32, u32, u32, u32, String, String),
    room: [u32; 3],
    walls: Vec<Wall>,
    openings: Vec<Opening>,
    modules: Vec<Module>,
    panels: Vec<WoodPanel>,
    gesso: Vec<GessoBlock>,
    decor: Vec<DecorItem>,
    hidden_ids: Vec<u32>,
    groups: Vec<Vec<u32>>,
    layers: layers::Layers,
    project_id: u64,
    next_id: u32,
    production: production::Settings,
    automation: automation::Settings,
    fabrication: fabrication::Settings,
    sheet_options: documentation::Options,
    sheet_title: String,
    sheet_client: String,
    sheet_author: String,
    sheet_views: Vec<SheetViewport>,
    sheet_dimensions: bool,
    dimension_text_size: f32,
    sheet_landscape: bool,
}
struct ProjectFile {
    room: [u32; 3],
    anchor_wall: Option<u32>,
    walls: Vec<Wall>,
    openings: Vec<Opening>,
    modules: Vec<Module>,
    panels: Vec<WoodPanel>,
    gesso: Vec<GessoBlock>,
    decor: Vec<DecorItem>,
    hidden_ids: Vec<u32>,
    groups: Vec<Vec<u32>>,
    layers: layers::Layers,
    project_id: u64,
    floor_texture: String,
    materials: Vec<MaterialData>,
    decor_materials: Vec<MaterialData>,
    production: production::Settings,
    automation: automation::Settings,
    fabrication: fabrication::Settings,
    sheet_options: documentation::Options,
    sheet_title: String,
    sheet_client: String,
    sheet_author: String,
    sheet_views: Vec<SheetViewport>,
    sheet_dimensions: bool,
    dimension_text_size: f32,
    sheet_landscape: bool,
    method_side: u32,
    method_top: u32,
    method_back: u32,
    method_gap: u32,
    standard_edge: String,
    back_mount: String,
    sale_markup: f32,
    budget_labor: f32,
    budget_waste: f32,
    budget_hardware: f32,
    budget_tax: f32,
}

impl Camera {
    fn reset(room: [u32; 3]) -> Self {
        Self {
            target: V3::new(
                room[0] as f32 / 2.0,
                room[1] as f32 * 0.42,
                room[2] as f32 / 2.0,
            ),
            yaw: 2.63,
            pitch: 0.30,
            distance: 10500.0,
            projection: Projection::Perspective,
        }
    }
    fn basis(self) -> (V3, V3, V3) {
        let (sy, cy) = self.yaw.sin_cos();
        let (sp, cp) = self.pitch.sin_cos();
        (
            V3::new(cy, 0.0, -sy),
            V3::new(-sy * sp, cp, -cy * sp),
            V3::new(sy * cp, sp, cy * cp),
        )
    }
    fn project(self, p: V3, rect: Rect) -> Option<(Pos2, f32, f32)> {
        let rel = p.sub(self.target);
        let (right, up, toward) = self.basis();
        let depth = rel.dot(toward);
        let camera_depth = self.distance - depth;
        if self.projection == Projection::Perspective && camera_depth < 9.99 {
            return None;
        }
        let scale = match self.projection {
            Projection::Perspective => 1700.0 / camera_depth,
            Projection::Orthographic => 1700.0 / self.distance,
        };
        let xy = Pos2::new(
            rect.center().x + rel.dot(right) * scale,
            rect.center().y - rel.dot(up) * scale,
        );
        if xy.x.is_finite() && xy.y.is_finite() {
            Some((xy, depth, scale))
        } else {
            None
        }
    }
    fn intersect_horizontal(self, screen: Pos2, rect: Rect, y: f32) -> Option<P2> {
        let (right, up, toward) = self.basis();
        let focal = 1700.0;
        let (origin, direction) = match self.projection {
            Projection::Perspective => {
                let origin = self.target.add(toward.mul(self.distance));
                let nx = (screen.x - rect.center().x) / focal;
                let ny = -(screen.y - rect.center().y) / focal;
                let direction = right.mul(nx).add(up.mul(ny)).sub(toward);
                (origin, direction)
            }
            Projection::Orthographic => {
                let scale = focal / self.distance;
                let origin = self
                    .target
                    .add(right.mul((screen.x - rect.center().x) / scale))
                    .add(up.mul(-(screen.y - rect.center().y) / scale))
                    .add(toward.mul(self.distance));
                (origin, toward.mul(-1.0))
            }
        };
        if direction.y.abs() < 0.0001 {
            return None;
        }
        let t = (y - origin.y) / direction.y;
        if !t.is_finite() || t < 0.0 {
            return None;
        }
        let hit = origin.add(direction.mul(t));
        Some(P2::new(hit.x, hit.z))
    }
    fn project_polygon(self, points: &[V3], rect: Rect) -> Vec<Pos2> {
        if self.projection == Projection::Orthographic {
            return points
                .iter()
                .filter_map(|p| self.project(*p, rect).map(|v| v.0))
                .collect();
        }
        let (right, up, toward) = self.basis();
        let polygon: Vec<(f32, f32, f32)> = points
            .iter()
            .map(|p| {
                let rel = p.sub(self.target);
                (rel.dot(right), rel.dot(up), self.distance - rel.dot(toward))
            })
            .collect();
        let near = 10.0;
        let mut clipped: Vec<(f32, f32, f32)> = Vec::new();
        if polygon.is_empty() {
            return Vec::new();
        }
        for i in 0..polygon.len() {
            let a = polygon[i];
            let b = polygon[(i + 1) % polygon.len()];
            let ain = a.2 >= near;
            let bin = b.2 >= near;
            if ain {
                clipped.push(a);
            }
            if ain != bin {
                let t = (near - a.2) / (b.2 - a.2);
                clipped.push((a.0 + (b.0 - a.0) * t, a.1 + (b.1 - a.1) * t, near));
            }
        }
        clipped
            .into_iter()
            .map(|(x, y, d)| {
                Pos2::new(
                    rect.center().x + x * 1700.0 / d,
                    rect.center().y - y * 1700.0 / d,
                )
            })
            .filter(|p| p.x.is_finite() && p.y.is_finite())
            .collect()
    }
}
impl PlanTransform {
    fn new(rect: Rect, room: [u32; 3], zoom: f32, pan: Vec2) -> Self {
        let w = room[0] as f32;
        let d = room[2] as f32;
        let scale = ((rect.width() - 90.0) / w)
            .min((rect.height() - 90.0) / d)
            .max(0.01)
            * zoom;
        Self {
            rect,
            center: rect.center() + pan,
            scale,
            room_w: w,
            room_d: d,
        }
    }
    fn screen(self, p: P2) -> Pos2 {
        Pos2::new(
            self.center.x + (p.x - self.room_w / 2.0) * self.scale,
            self.center.y + (p.z - self.room_d / 2.0) * self.scale,
        )
    }
    fn world(self, p: Pos2) -> P2 {
        P2::new(
            (p.x - self.center.x) / self.scale + self.room_w / 2.0,
            (p.y - self.center.y) / self.scale + self.room_d / 2.0,
        )
    }
}

struct FurnitureApp {
    geometry: geometry::Designer,
    decor_category: usize,
    finish_designer: designers::FinishDesigner,
    panel_designer: designers::PanelDesigner,
    editing: editing::Editor,
    room: [u32; 3],
    walls: Vec<Wall>,
    openings: Vec<Opening>,
    modules: Vec<Module>,
    panels: Vec<WoodPanel>,
    gesso: Vec<GessoBlock>,
    selected: Option<Selection>,
    next_id: u32,
    camera: Camera,
    page: Page,
    tool: Tool,
    catalog: CatalogTab,
    inspector: InspectorTab,
    wall_thickness: u32,
    modulation_mm: u32,
    wall_snap_distance: u32,
    wall_grid_enabled: bool,
    wall_snap_ortho: bool,
    wall_snap_perpendicular: bool,
    wall_snap_angular: bool,
    wall_angle_step: u32,
    wall_length_mm: u32,
    wall_direction_deg: f32,
    wall_dimensions_locked: bool,
    cutaway: bool,
    scene_drag_offset: Option<P2>,
    plan_rulers: bool,
    anchor_wall: Option<u32>,
    door_width: u32,
    door_height: u32,
    window_width: u32,
    window_height: u32,
    window_sill: u32,
    materials: Vec<MaterialData>,
    decor_materials: Vec<MaterialData>,
    decor_material_view: bool,
    material_name: String,
    material_price: f32,
    sale_markup: f32,
    method_side: u32,
    method_top: u32,
    method_back: u32,
    method_gap: u32,
    standard_edge: String,
    back_mount: String,
    plan_zoom: f32,
    plan_pan: Vec2,
    budget_labor: f32,
    budget_waste: f32,
    budget_hardware: f32,
    budget_tax: f32,
    hidden_ids: Vec<u32>,
    groups: Vec<Vec<u32>>,
    layers: layers::Layers,
    project_id: u64,
    opening_style: String,
    opening_material: String,
    opening_catalog_kind: OpeningKind,
    floor_texture: String,
    decor: Vec<DecorItem>,
    panel_width: u32,
    panel_height: u32,
    panel_thickness: u32,
    panel_material: String,
    panel_grain: Grain,
    panel_name: String,
    gesso_drop: u32,
    gesso_thickness: u32,
    custom_width: u32,
    custom_height: u32,
    custom_depth: u32,
    custom_thickness: u32,
    custom_top: u8,
    custom_drawer_height: u32,
    custom_dividers: u32,
    custom_drawers: u32,
    custom_doors: u32,
    custom_shelves: u32,
    custom_kind: ModuleKind,
    custom_style: DoorStyle,
    custom_material: String,
    global_door_style: DoorStyle,
    door_apply_all: bool,
    door_edit_individually: bool,
    render_mode: RenderMode,
    view_path: String,
    sheet_path: String,
    production: production::Settings,
    automation: automation::Settings,
    fabrication: fabrication::Settings,
    sheet_options: documentation::Options,
    sheet_title: String,
    sheet_client: String,
    sheet_author: String,
    sheet_views: Vec<SheetViewport>,
    sheet_dimensions: bool,
    dimension_text_size: f32,
    sheet_landscape: bool,
    pending_point: Option<P2>,
    material_target: u8,
    material_source: Option<String>,
    undo_stack: Vec<ProjectSnapshot>,
    last_snapshot: Option<ProjectSnapshot>,
    history_signature: String,
    language: usize,
    show_layers: bool,
    show_command_hints: bool,
    show_catalog: bool,
    show_inspector: bool,
    tool_keys: [egui::Key; 12],
    preferences_loaded: bool,
    shortcut_undo: egui::Key,
    shortcut_select: egui::Key,
    shortcut_wall: egui::Key,
    shortcut_copy: egui::Key,
    shortcut_paint: egui::Key,
    project_path: String,
    project_path_selected: bool,
    logo_texture: Option<egui::TextureHandle>,
    csv_path: String,
    ifc_path: String,
    notice: String,
    notice_error: bool,
}

impl Default for FurnitureApp {
    fn default() -> Self {
        let room = [4200, 2700, 3200];
        let modules = vec![
            make_module(
                1,
                preset("Balcão 800", ModuleKind::Base, 800, 720, 550, 0, 2, 1, 0),
                260,
                300,
            ),
            make_module(
                2,
                preset("Aéreo 800", ModuleKind::Wall, 800, 720, 350, 1320, 2, 1, 0),
                260,
                300,
            ),
            make_module(
                3,
                preset(
                    "Torre alta 600",
                    ModuleKind::Tall,
                    600,
                    2100,
                    600,
                    0,
                    2,
                    2,
                    0,
                ),
                2260,
                250,
            ),
        ];
        let walls = vec![
            Wall {
                material: "Pintura branca".into(),
                color: Color32::from_rgb(220, 221, 218),
                id: 4,
                start: P2::new(0.0, 0.0),
                end: P2::new(0.0, room[2] as f32),
                thickness_mm: 150,
                height_mm: room[1],
            },
            Wall {
                material: "Pintura branca".into(),
                color: Color32::from_rgb(220, 221, 218),
                id: 5,
                start: P2::new(0.0, room[2] as f32),
                end: P2::new(room[0] as f32, room[2] as f32),
                thickness_mm: 150,
                height_mm: room[1],
            },
            Wall {
                material: "Pintura branca".into(),
                color: Color32::from_rgb(220, 221, 218),
                id: 6,
                start: P2::new(room[0] as f32, room[2] as f32),
                end: P2::new(room[0] as f32, 0.0),
                thickness_mm: 150,
                height_mm: room[1],
            },
        ];
        Self {
            geometry: geometry::Designer::default(),
            decor_category: 0,
            finish_designer: designers::FinishDesigner::default(),
            panel_designer: designers::PanelDesigner::default(),
            editing: editing::Editor::default(),
            room,
            walls,
            openings: Vec::new(),
            modules,
            panels: Vec::new(),
            gesso: Vec::new(),
            decor: Vec::new(),
            hidden_ids: Vec::new(),
            groups: vec![],
            layers: layers::Layers::default(),
            project_id: project_identity(),
            selected: Some(Selection::Module(1)),
            next_id: 7,
            camera: Camera::reset(room),
            page: Page::Scene,
            tool: Tool::Select,
            catalog: CatalogTab::Kitchen,
            inspector: InspectorTab::Tools,
            wall_thickness: 150,
            modulation_mm: 50,
            wall_snap_distance: 150,
            wall_grid_enabled: true,
            wall_snap_ortho: false,
            wall_snap_perpendicular: false,
            wall_snap_angular: false,
            wall_angle_step: 15,
            wall_length_mm: 1000,
            wall_direction_deg: 0.0,
            wall_dimensions_locked: false,
            cutaway: true,
            scene_drag_offset: None,
            plan_rulers: true,
            anchor_wall: None,
            door_width: 800,
            door_height: 2100,
            window_width: 1200,
            window_height: 1100,
            window_sill: 900,
            opening_style: "Lisa".into(),
            opening_material: "MDF branco".into(),
            opening_catalog_kind: OpeningKind::Door,
            floor_texture: "Cimento claro".into(),
            materials: default_materials(),
            decor_materials: decorative_materials(),
            decor_material_view: false,
            material_name: String::new(),
            material_price: 120.0,
            sale_markup: 1.35,
            method_side: 18,
            method_top: 18,
            method_back: 6,
            method_gap: 3,
            standard_edge: "PVC 1 mm".into(),
            back_mount: "Encaixado".into(),
            plan_zoom: 1.0,
            plan_pan: Vec2::ZERO,
            budget_labor: 20.0,
            budget_waste: 10.0,
            budget_hardware: 45.0,
            budget_tax: 0.0,
            panel_width: 1000,
            panel_height: 2400,
            panel_thickness: 18,
            panel_material: "Carvalho claro".into(),
            panel_grain: Grain::Length,
            panel_name: "Painel sob medida".into(),
            gesso_drop: 250,
            gesso_thickness: 120,
            custom_width: 800,
            custom_height: 720,
            custom_depth: 550,
            custom_thickness: 18,
            custom_top: 0,
            custom_drawer_height: 400,
            custom_dividers: 0,
            custom_drawers: 0,
            custom_doors: 2,
            custom_shelves: 1,
            custom_kind: ModuleKind::Base,
            custom_style: DoorStyle::Plain,
            custom_material: "Carvalho claro".into(),
            global_door_style: DoorStyle::Plain,
            door_apply_all: true,
            door_edit_individually: false,
            render_mode: RenderMode::Textures,
            view_path: "captura-vista.svg".into(),
            sheet_path: "prancha-A4.svg".into(),
            production: production::Settings::default(),
            automation: automation::Settings::default(),
            fabrication: fabrication::Settings::default(),
            sheet_options: documentation::Options::default(),
            sheet_title: "Projeto de marcenaria".into(),
            sheet_client: "Cliente".into(),
            sheet_author: "Projetista".into(),
            sheet_views: vec![SheetViewport {
                offset_x: 0.0,
                offset_y: 0.0,
                kind: ViewKind::Plan,
                x: 16.0,
                y: 24.0,
                width: 250.0,
                height: 140.0,
            }],
            sheet_dimensions: true,
            dimension_text_size: 2.6,
            sheet_landscape: true,
            pending_point: None,
            material_target: 0,
            material_source: None,
            undo_stack: Vec::new(),
            last_snapshot: None,
            history_signature: String::new(),
            language: 0,
            show_layers: false,
            show_command_hints: true,
            show_catalog: true,
            show_inspector: true,
            tool_keys: commands::defaults(),
            preferences_loaded: false,
            shortcut_undo: egui::Key::Z,
            shortcut_select: egui::Key::Q,
            shortcut_wall: egui::Key::W,
            shortcut_copy: egui::Key::C,
            shortcut_paint: egui::Key::B,
            project_path: "projeto.mar".into(),
            project_path_selected: false,
            logo_texture: None,
            csv_path: "lista-de-corte.csv".into(),
            ifc_path: "projeto.ifc".into(),
            notice: String::new(),
            notice_error: false,
        }
    }
}

impl FurnitureApp {
    fn set_tool(&mut self, tool: Tool) {
        self.editing.curve_middle = None;
        self.tool = tool;
        self.pending_point = None;
        if matches!(
            tool,
            Tool::Wall
                | Tool::WallChain
                | Tool::WallCurve
                | Tool::Door
                | Tool::Window
                | Tool::Panel
                | Tool::Gesso
                | Tool::CopyMaterial
                | Tool::PaintMaterial
                | Tool::WallAnchor
        ) {
            self.page = Page::Plan;
        }
    }
    fn toggle_tool(&mut self, tool: Tool) {
        if self.tool == tool {
            self.tool = Tool::Select;
            self.selected = None;
            self.pending_point = None;
            self.material_source = None;
        } else {
            self.set_tool(tool);
        }
    }
    fn cancel_current(&mut self) {
        self.editing.selection.clear();
        self.editing.curve_middle = None;
        self.tool = Tool::Select;
        self.selected = None;
        self.pending_point = None;
        self.material_source = None;
    }
    fn save_dialog_path(&mut self) -> bool {
        let proposed = Path::new(&self.sheet_path);
        let filename = proposed
            .file_name()
            .and_then(|s| s.to_str())
            .unwrap_or("prancha-A4.svg");
        let output = Command::new("zenity")
            .args([
                "--file-selection",
                "--save",
                "--confirm-overwrite",
                &format!("--filename={filename}"),
            ])
            .output();
        match output {
            Ok(o) if o.status.success() => {
                self.sheet_path = String::from_utf8_lossy(&o.stdout).trim().to_owned();
                true
            }
            Ok(_) => false,
            Err(_) => {
                self.notice="Não encontrei o seletor de arquivos do sistema. Digite o caminho completo no campo da prancha e use Salvar no destino.".into();
                self.notice_error = true;
                false
            }
        }
    }
    fn choose_project_path(&mut self, save: bool) {
        let filename = Path::new(&self.project_path)
            .file_name()
            .and_then(|s| s.to_str())
            .unwrap_or("projeto.mar");
        let mut command = Command::new("zenity");
        command.arg("--file-selection");
        if save {
            command.args(["--save", "--confirm-overwrite"]);
        }
        if let Ok(result) = command
            .arg("--file-filter=Projeto Marcenaria Livre | *.mar")
            .arg(format!("--filename={filename}"))
            .output()
        {
            if result.status.success() {
                self.project_path = String::from_utf8_lossy(&result.stdout).trim().to_owned();
                self.project_path_selected = true;
                if save {
                    self.save_project();
                } else {
                    self.open_project();
                }
            }
        }
    }
    fn save_project_action(&mut self) {
        if self.project_path_selected {
            self.save_project();
        } else {
            self.choose_project_path(true);
        }
    }
    fn save_project(&mut self) {
        let mut path = self.project_path.clone();
        if Path::new(&path).extension().and_then(|s| s.to_str()) != Some("mar") {
            path.push_str(".mar");
            self.project_path = path.clone();
        }
        self.project_path_selected = true;
        match write_file(&path, &project_to_mar(self)) {
            Ok(()) => {
                self.notice = format!("Projeto Marcenaria Livre salvo: {path}");
                self.notice_error = false;
            }
            Err(e) => {
                self.notice = format!("Não foi possível salvar o projeto: {e}");
                self.notice_error = true;
            }
        }
    }
    fn open_project(&mut self) {
        match fs::read_to_string(&self.project_path)
            .map_err(|e| e.to_string())
            .and_then(|s| parse_mar_project(&s))
        {
            Ok(p) => {
                self.room = p.room;
                self.anchor_wall = p
                    .anchor_wall
                    .filter(|id| p.walls.iter().any(|w| w.id == *id));
                self.walls = p.walls;
                self.openings = p.openings;
                self.modules = p.modules;
                self.panels = p.panels;
                self.gesso = p.gesso;
                self.decor = p.decor;
                self.hidden_ids = p.hidden_ids;
                self.groups = p.groups;
                self.editing = editing::Editor::default();
                self.layers = p.layers;
                self.project_id = p.project_id;
                self.floor_texture = p.floor_texture;
                self.materials = p.materials;
                self.decor_materials = p.decor_materials;
                self.production = p.production;
                self.automation = p.automation;
                self.fabrication = p.fabrication;
                self.sheet_options = p.sheet_options;
                self.sheet_title = p.sheet_title;
                self.sheet_client = p.sheet_client;
                self.sheet_author = p.sheet_author;
                self.sheet_views = p.sheet_views;
                self.sheet_dimensions = p.sheet_dimensions;
                self.dimension_text_size = p.dimension_text_size;
                self.sheet_landscape = p.sheet_landscape;
                self.method_side = p.method_side;
                self.method_top = p.method_top;
                self.method_back = p.method_back;
                self.method_gap = p.method_gap;
                self.standard_edge = p.standard_edge;
                self.back_mount = p.back_mount;
                self.sale_markup = p.sale_markup;
                self.budget_labor = p.budget_labor;
                self.budget_waste = p.budget_waste;
                self.budget_hardware = p.budget_hardware;
                self.budget_tax = p.budget_tax;
                self.next_id = self
                    .walls
                    .iter()
                    .map(|x| x.id)
                    .chain(self.openings.iter().map(|x| x.id))
                    .chain(self.modules.iter().map(|x| x.id))
                    .chain(self.panels.iter().map(|x| x.id))
                    .chain(self.gesso.iter().map(|x| x.id))
                    .chain(self.decor.iter().map(|x| x.id))
                    .max()
                    .unwrap_or(0)
                    + 1;
                self.camera = Camera::reset(self.room);
                self.project_path_selected = true;
                self.selected = None;
                self.page = Page::Scene;
                self.undo_stack.clear();
                self.last_snapshot = None;
                self.history_signature.clear();
                self.notice = format!("Projeto aberto: {}", self.project_path);
                self.notice_error = false;
            }
            Err(e) => {
                self.notice = format!("Não foi possível abrir o projeto: {e}");
                self.notice_error = true;
            }
        }
    }
    fn preferences_path() -> Option<std::path::PathBuf> {
        std::env::var_os("HOME")
            .map(std::path::PathBuf::from)
            .map(|p| p.join(".config/marcenaria-livre/preferences.ini"))
    }
    fn load_preferences(&mut self) {
        if let Some(path) = Self::preferences_path() {
            if let Ok(content) = fs::read_to_string(path) {
                for line in content.lines() {
                    let mut p = line.splitn(2, '=');
                    let (k, v) = (p.next().unwrap_or(""), p.next().unwrap_or(""));
                    match k {
                        "dark_mode" => {}
                        "language" => self.language = v.parse::<usize>().unwrap_or(0).min(2),
                        "show_command_hints" => self.show_command_hints = v != "false",
                        "show_catalog" => self.show_catalog = v != "false",
                        "show_inspector" => self.show_inspector = v != "false",
                        "plan_rulers" => self.plan_rulers = v != "false",
                        "shortcut_undo" => {
                            if let Some(key) = key_from_label(v) {
                                self.shortcut_undo = key
                            }
                        }
                        "shortcut_select" => {
                            if let Some(key) = key_from_label(v) {
                                self.shortcut_select = key
                            }
                        }
                        "shortcut_wall" => {
                            if let Some(key) = key_from_label(v) {
                                self.shortcut_wall = key
                            }
                        }
                        "shortcut_copy" => {
                            if let Some(key) = key_from_label(v) {
                                self.shortcut_copy = key
                            }
                        }
                        "shortcut_paint" => {
                            if let Some(key) = key_from_label(v) {
                                self.shortcut_paint = key
                            }
                        }
                        "wall_grid_enabled" => self.wall_grid_enabled = v != "false",
                        "wall_snap_ortho" => self.wall_snap_ortho = v == "true",
                        "wall_snap_perpendicular" => self.wall_snap_perpendicular = v == "true",
                        "wall_snap_angular" => self.wall_snap_angular = v == "true",
                        "modulation_mm" => {
                            if let Ok(n) = v.parse() {
                                self.modulation_mm = n
                            }
                        }
                        "wall_snap_distance" => {
                            if let Ok(n) = v.parse() {
                                self.wall_snap_distance = n
                            }
                        }
                        "wall_angle_step" => {
                            if let Ok(n) = v.parse() {
                                self.wall_angle_step = n
                            }
                        }
                        _ => {
                            if let Some(index) = k
                                .strip_prefix("tool_key_")
                                .and_then(|v| v.parse::<usize>().ok())
                            {
                                if index < 12 {
                                    if let Some(key) = key_from_label(v) {
                                        self.tool_keys[index] = key;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        self.preferences_loaded = true;
    }
    fn save_preferences(&self) {
        if let Some(path) = Self::preferences_path() {
            if let Some(parent) = path.parent() {
                let _ = fs::create_dir_all(parent);
            }
            let data=format!("dark_mode={}\nshow_command_hints={}\nshow_catalog={}\nshow_inspector={}\nplan_rulers={}\nshortcut_undo={}\nshortcut_select={}\nshortcut_wall={}\nshortcut_copy={}\nshortcut_paint={}\nwall_grid_enabled={}\nwall_snap_ortho={}\nwall_snap_perpendicular={}\nwall_snap_angular={}\nmodulation_mm={}\nwall_snap_distance={}\nwall_angle_step={}\n",false,self.show_command_hints,self.show_catalog,self.show_inspector,self.plan_rulers,key_label(self.shortcut_undo),key_label(self.shortcut_select),key_label(self.shortcut_wall),key_label(self.shortcut_copy),key_label(self.shortcut_paint),self.wall_grid_enabled,self.wall_snap_ortho,self.wall_snap_perpendicular,self.wall_snap_angular,self.modulation_mm,self.wall_snap_distance,self.wall_angle_step);
            let mut data = data;
            data.push_str(&format!("language={}\n", self.language));
            for (i, key) in self.tool_keys.iter().enumerate() {
                data.push_str(&format!("tool_key_{}={}\n", i, key_label(*key)));
            }
            let _ = fs::write(path, data);
        }
    }
    fn command_hint(&self) -> String {
        match self.tool {
            Tool::Select => format!(
                "Selecionar: {} · Excluir: Delete · Desfazer: Ctrl+{}",
                key_label(self.shortcut_select),
                key_label(self.shortcut_undo)
            ),
            Tool::Move => "Mover: arraste um módulo · encaixe na parede".into(),
            Tool::Wall => "Parede reta: clique no início e no fim · Esc cancela".into(),
            Tool::WallChain | Tool::WallCurve => format!(
                "Parede contínua: {} · snap ortogonal/perpendicular/angular conforme Preferências",
                key_label(self.shortcut_wall)
            ),
            Tool::Door => "Porta: clique na parede para abrir o vão".into(),
            Tool::Window => "Janela: clique na parede para abrir o vão".into(),
            Tool::Gesso => "Gesso: clique em dois cantos opostos".into(),
            Tool::Panel => "Painel: clique para colocar · edite as medidas na seleção".into(),
            Tool::CopyMaterial => format!(
                "Copiar material: {} · clique na origem e depois no destino",
                key_label(self.shortcut_copy)
            ),
            Tool::PaintMaterial => format!(
                "Pintar material: {} · escolha o acabamento e clique nos objetos",
                key_label(self.shortcut_paint)
            ),
            Tool::WallAnchor => {
                "Parede de fundo: clique na parede que receberá o fundo dos módulos".into()
            }
        }
    }
    fn project_snapshot(&self) -> ProjectSnapshot {
        ProjectSnapshot {
            method_values: (
                self.method_side,
                self.method_top,
                self.method_back,
                self.method_gap,
                self.standard_edge.clone(),
                self.back_mount.clone(),
            ),
            room: self.room,
            walls: self.walls.clone(),
            openings: self.openings.clone(),
            modules: self.modules.clone(),
            panels: self.panels.clone(),
            gesso: self.gesso.clone(),
            decor: self.decor.clone(),
            hidden_ids: self.hidden_ids.clone(),
            groups: self.groups.clone(),
            layers: self.layers.clone(),
            project_id: self.project_id,
            next_id: self.next_id,
            production: self.production.clone(),
            automation: self.automation.clone(),
            fabrication: self.fabrication.clone(),
            sheet_options: self.sheet_options.clone(),
            sheet_title: self.sheet_title.clone(),
            sheet_client: self.sheet_client.clone(),
            sheet_author: self.sheet_author.clone(),
            sheet_views: self.sheet_views.clone(),
            sheet_dimensions: self.sheet_dimensions,
            dimension_text_size: self.dimension_text_size,
            sheet_landscape: self.sheet_landscape,
        }
    }
    fn project_signature(&self) -> String {
        format!(
            "{:?}|{:?}|{:?}",
            (
                self.method_side,
                self.method_top,
                self.method_back,
                self.method_gap,
                &self.standard_edge,
                &self.back_mount
            ),
            (
                &self.room,
                &self.walls,
                &self.openings,
                &self.modules,
                &self.panels,
                &self.gesso,
                &self.decor,
                &self.hidden_ids,
                &self.layers,
                &self.groups
            ),
            (
                &self.production,
                &self.automation,
                &self.fabrication,
                &self.sheet_options,
                &self.sheet_title,
                self.sheet_client.as_str(),
                self.sheet_author.as_str(),
                &self.sheet_views,
                self.sheet_dimensions,
                self.dimension_text_size,
                self.sheet_landscape
            )
        )
    }
    fn undo_action(&mut self) {
        if let Some(s) = self.undo_stack.pop() {
            (
                self.method_side,
                self.method_top,
                self.method_back,
                self.method_gap,
                self.standard_edge,
                self.back_mount,
            ) = s.method_values;
            self.room = s.room;
            self.walls = s.walls;
            self.openings = s.openings;
            self.modules = s.modules;
            self.panels = s.panels;
            self.gesso = s.gesso;
            self.decor = s.decor;
            self.hidden_ids = s.hidden_ids;
            self.groups = s.groups;
            self.editing.selection.clear();
            self.layers = s.layers;
            self.project_id = s.project_id;
            self.next_id = s.next_id;
            self.production = s.production;
            self.automation = s.automation;
            self.fabrication = s.fabrication;
            self.sheet_options = s.sheet_options;
            self.sheet_title = s.sheet_title;
            self.sheet_client = s.sheet_client;
            self.sheet_author = s.sheet_author;
            self.sheet_views = s.sheet_views;
            self.sheet_dimensions = s.sheet_dimensions;
            self.dimension_text_size = s.dimension_text_size;
            self.sheet_landscape = s.sheet_landscape;
            self.last_snapshot = Some(self.project_snapshot());
            self.history_signature = self.project_signature();
            self.selected = None;
            self.notice = "Ação desfeita · Ctrl+Z".into();
            self.notice_error = false;
        } else {
            self.notice = "Não há ações anteriores para desfazer.".into();
            self.notice_error = false;
        }
    }
    fn track_history(&mut self) {
        let signature = self.project_signature();
        if self.last_snapshot.is_none() {
            self.last_snapshot = Some(self.project_snapshot());
            self.history_signature = signature;
            return;
        }
        if signature != self.history_signature {
            if let Some(previous) = self.last_snapshot.take() {
                self.undo_stack.push(previous);
                if self.undo_stack.len() > 100 {
                    self.undo_stack.remove(0);
                }
            }
            self.last_snapshot = Some(self.project_snapshot());
            self.history_signature = signature;
        }
    }
    fn material_of_selection(&self, s: Selection) -> Option<String> {
        match s {
            Selection::Wall(id) => self
                .walls
                .iter()
                .find(|v| v.id == id)
                .map(|v| v.material.clone()),
            Selection::Module(id) => self
                .modules
                .iter()
                .find(|v| v.id == id)
                .map(|v| v.material.clone()),
            Selection::Panel(id) => self
                .panels
                .iter()
                .find(|v| v.id == id)
                .map(|v| v.material.clone()),
            Selection::Opening(id) => self
                .openings
                .iter()
                .find(|v| v.id == id)
                .map(|v| v.material.clone()),
            Selection::Decor(id) => self
                .decor
                .iter()
                .find(|v| v.id == id)
                .map(|v| v.material.clone()),
            _ => None,
        }
    }
    fn apply_material_to(&mut self, s: Selection, material: &str) {
        match s {
            Selection::Wall(id) => {
                if let Some(v) = self.walls.iter_mut().find(|v| v.id == id) {
                    v.material = material.into();
                    v.color = self
                        .decor_materials
                        .iter()
                        .chain(self.materials.iter())
                        .find(|m| m.name == material)
                        .map(|m| m.color)
                        .unwrap_or(v.color);
                }
            }
            Selection::Module(id) => {
                if let Some(v) = self.modules.iter_mut().find(|v| v.id == id) {
                    if self.material_target != 2 {
                        v.material = material.into();
                    }
                    if self.material_target != 1 {
                        v.door_material = material.into();
                    }
                }
            }
            Selection::Panel(id) => {
                if let Some(v) = self.panels.iter_mut().find(|v| v.id == id) {
                    v.material = material.into();
                }
            }
            Selection::Opening(id) => {
                if let Some(v) = self.openings.iter_mut().find(|v| v.id == id) {
                    v.material = material.into();
                }
            }
            Selection::Decor(id) => {
                let color = self
                    .decor_materials
                    .iter()
                    .find(|m| m.name == material)
                    .or_else(|| self.materials.iter().find(|m| m.name == material))
                    .map(|m| m.color);
                if let Some(v) = self.decor.iter_mut().find(|v| v.id == id) {
                    v.material = material.into();
                    if let Some(c) = color {
                        v.color = c;
                    }
                }
            }
            _ => {}
        }
    }
    fn reset_camera(&mut self) {
        self.camera = Camera::reset(self.room);
    }
    fn add_preset(&mut self, p: Preset) {
        let x = 180 + (self.modules.len() as u32 % 4) * 900;
        let z = 250 + (self.modules.len() as u32 / 4) * 700;
        let mut m = make_module(self.next_id, p, x, z);
        m.thickness_mm = self.method_side;
        m.door_style = self.global_door_style;
        m.door_styles = vec![self.global_door_style; p.doors.max(1) as usize];
        snap_module_to_wall_target(&mut m, &self.walls, self.room, self.anchor_wall);
        self.next_id += 1;
        self.selected = Some(Selection::Module(m.id));
        self.modules.push(m);
        self.page = Page::Scene;
        self.notice = format!("{} inserido e ajustado à parede mais próxima", p.name);
        self.notice_error = false;
    }
    fn add_custom_module(&mut self) {
        let p = preset(
            "Módulo sob medida",
            self.custom_kind,
            self.custom_width,
            self.custom_height,
            self.custom_depth,
            0,
            self.custom_doors,
            self.custom_shelves,
            0,
        );
        let mut m = make_module(self.next_id, p, 250, 250);
        if self.custom_kind == ModuleKind::Wall {
            m.y_mm = 1320;
        }
        m.thickness_mm = self.custom_thickness;
        m.divider_count = self.custom_dividers.min(
            (self.custom_width.saturating_sub(2 * self.custom_thickness)
                / (self.custom_thickness + 50))
                .saturating_sub(1),
        );
        m.drawer_count = self.custom_drawers;
        m.top_mode = self.custom_top;
        m.internal_drawer_height = self
            .custom_drawer_height
            .min(m.height_mm.saturating_sub(2 * m.thickness_mm));
        m.material = self.custom_material.clone();
        m.door_material = self.custom_material.clone();
        m.door_style = self.custom_style;
        m.door_styles = vec![self.custom_style; self.custom_doors as usize];
        snap_module_to_wall_target(&mut m, &self.walls, self.room, self.anchor_wall);
        self.next_id += 1;
        self.selected = Some(Selection::Module(m.id));
        self.modules.push(m);
        self.page = Page::Scene;
    }
    fn add_decor(&mut self, name: &str, w: u32, h: u32, d: u32, color: Color32) {
        let item = DecorItem {
            outline: vec![],
            rotation_deg: 0.,
            id: self.next_id,
            name: name.into(),
            material: self
                .decor_materials
                .first()
                .map(|m| m.name.clone())
                .unwrap_or_default(),
            x_mm: self.room[0] / 2 - w / 2,
            y_mm: 0,
            z_mm: self.room[2] / 2 - d / 2,
            width_mm: w,
            height_mm: h,
            depth_mm: d,
            color,
        };
        self.next_id += 1;
        self.selected = Some(Selection::Decor(item.id));
        self.decor.push(item);
        self.page = Page::Scene;
        self.notice = format!("{name} inserido em Decoração; fora do orçamento de marcenaria.");
        self.notice_error = false;
    }
    fn add_panel_at(&mut self, p: P2) {
        let panel = WoodPanel {
            rotation_deg: 0.0,
            horizontal: false,
            id: self.next_id,
            name: self.panel_name.clone(),
            x_mm: p.x.max(0.0) as u32,
            y_mm: 0,
            z_mm: p.z.max(0.0) as u32,
            width_mm: self.panel_width,
            height_mm: self.panel_height,
            thickness_mm: self.panel_thickness,
            material: self.panel_material.clone(),
            grain: self.panel_grain,
        };
        self.next_id += 1;
        self.selected = Some(Selection::Panel(panel.id));
        self.panels.push(panel);
        self.page = Page::Scene;
    }
    fn create_marble_countertop(&mut self) {
        let mut bases: Vec<&Module> = self
            .modules
            .iter()
            .filter(|m| m.kind == ModuleKind::Base)
            .collect();
        if bases.is_empty() {
            self.notice = "Adicione módulos inferiores de cozinha antes de criar a bancada.".into();
            self.notice_error = true;
            return;
        }
        bases.sort_by_key(|m| m.x_mm);
        let first = bases[0];
        let x = first.x_mm;
        let y = first.y_mm + first.height_mm;
        let z = first.z_mm;
        let end = bases.iter().map(|m| m.x_mm + m.width_mm).max().unwrap_or(x);
        let w = end.saturating_sub(x);
        let mat = if self.materials.iter().any(|m| m.name == "Mármore branco") {
            "Mármore branco"
        } else {
            "Granito São Gabriel"
        };
        self.panels.push(WoodPanel {
            rotation_deg: 0.0,
            horizontal: false,
            id: self.next_id,
            name: "Bancada de pedra para módulos inferiores".into(),
            x_mm: x,
            y_mm: y,
            z_mm: z,
            width_mm: w,
            height_mm: 30,
            thickness_mm: 30,
            material: mat.into(),
            grain: Grain::Length,
        });
        self.next_id += 1;
        self.panels.push(WoodPanel {
            rotation_deg: 0.0,
            horizontal: false,
            id: self.next_id,
            name: "Frontão da bancada".into(),
            x_mm: x,
            y_mm: y,
            z_mm: z,
            width_mm: w,
            height_mm: 100,
            thickness_mm: 20,
            material: mat.into(),
            grain: Grain::Length,
        });
        self.next_id += 1;
        self.notice =
            "Bancada de pedra e frontão adicionados sobre a faixa dos módulos inferiores.".into();
        self.notice_error = false;
    }
    fn run_automation(&mut self, kind: &str) {
        automation::apply(self, &[kind]);
    }

    fn hide_selected(&mut self) {
        let id = match self.selected {
            Some(Selection::Module(i))
            | Some(Selection::Wall(i))
            | Some(Selection::Opening(i))
            | Some(Selection::Panel(i))
            | Some(Selection::Gesso(i))
            | Some(Selection::Decor(i)) => i,
            None => return,
        };
        if !self.hidden_ids.contains(&id) {
            self.hidden_ids.push(id);
        }
        self.notice = "Elemento ocultado. Use Mostrar tudo para recuperá-lo.".into();
    }
    fn show_all(&mut self) {
        self.hidden_ids.clear();
        self.layers.visible.fill(true);
        self.notice = "Todos os elementos estão visíveis.".into();
    }
    fn snap_selected_module(&mut self) {
        if let Some(Selection::Module(id)) = self.selected {
            if let Some(m) = self.modules.iter_mut().find(|m| m.id == id) {
                snap_module_to_wall_target(m, &self.walls, self.room, self.anchor_wall);
            }
        }
    }
    fn nudge_selected_module(&mut self, dx: f32, dz: f32) {
        if let Some(Selection::Module(id)) = self.selected {
            if let Some(m) = self.modules.iter_mut().find(|m| m.id == id) {
                m.x_mm = (m.x_mm as f32 + dx).max(0.0) as u32;
                m.z_mm = (m.z_mm as f32 + dz).max(0.0) as u32;
                snap_module_to_wall_target(m, &self.walls, self.room, self.anchor_wall);
            }
        }
    }
    fn parts(&self) -> Vec<Part> {
        let mut p: Vec<Part> = self
            .modules
            .iter()
            .flat_map(|m| {
                let mut v = fabrication::parts(self, m);
                v.extend(fabrication::hardware(self, m));
                v
            })
            .collect();
        p.extend(self.panels.iter().map(|board| Part {
            group: "Painéis personalizados".into(),
            name: board.name.clone(),
            quantity: 1,
            length_mm: board.height_mm,
            width_mm: board.width_mm,
            thickness_mm: board.thickness_mm,
            material: board.material.clone(),
            edge: self.standard_edge.clone(),
            grain: board.grain.label().into(),
        }));
        p
    }
    fn selected_module_mut(&mut self) -> Option<&mut Module> {
        let id = match self.selected {
            Some(Selection::Module(id)) => id,
            _ => return None,
        };
        self.modules.iter_mut().find(|m| m.id == id)
    }
    fn new_environment(&mut self) {
        self.project_id = project_identity();
        self.walls.clear();
        self.openings.clear();
        self.modules.clear();
        self.panels.clear();
        self.gesso.clear();
        self.decor.clear();
        self.hidden_ids.clear();
        self.groups.clear();
        self.editing.selection.clear();
        self.anchor_wall = None;
        self.selected = None;
        self.page = Page::Plan;
        self.pending_point = None;
        self.reset_camera();
        self.notice = "Ambiente vazio. Desenhe as paredes na planta.".into();
        self.notice_error = false;
    }
    fn duplicate_selected(&mut self) {
        if let Some(Selection::Module(id)) = self.selected {
            if let Some(source) = self.modules.iter().find(|m| m.id == id).cloned() {
                let mut m = source;
                m.id = self.next_id;
                m.x_mm = m
                    .x_mm
                    .saturating_add(m.width_mm + 40)
                    .min(self.room[0].saturating_sub(m.width_mm));
                self.next_id += 1;
                self.selected = Some(Selection::Module(m.id));
                self.modules.push(m);
            }
        }
    }
    fn delete_single_selected(&mut self) {
        match self.selected {
            Some(Selection::Module(id)) => self.modules.retain(|v| v.id != id),
            Some(Selection::Wall(id)) => {
                self.walls.retain(|v| v.id != id);
                let gone: Vec<u32> = self
                    .openings
                    .iter()
                    .filter(|o| o.wall_id == id)
                    .map(|o| o.id)
                    .collect();
                self.openings.retain(|o| o.wall_id != id);
                if !gone.is_empty() {
                    self.notice = "Parede e aberturas removidas".into();
                }
            }
            Some(Selection::Opening(id)) => self.openings.retain(|v| v.id != id),
            Some(Selection::Panel(id)) => self.panels.retain(|v| v.id != id),
            Some(Selection::Gesso(id)) => self.gesso.retain(|v| v.id != id),
            Some(Selection::Decor(id)) => self.decor.retain(|v| v.id != id),
            None => {}
        }
        self.selected = None;
    }
    fn add_wall_segment(&mut self, mut a: P2, mut b: P2) {
        if a.distance(b) < 100.0 {
            self.notice = "A parede precisa ter pelo menos 100 mm.".into();
            self.notice_error = true;
            return;
        }
        for w in &self.walls {
            for candidate in [&mut a, &mut b] {
                let (offset, distance) = project_to_wall(*candidate, w);
                if distance < self.wall_snap_distance as f32 {
                    let len = w.start.distance(w.end).max(1.0);
                    let ux = (w.end.x - w.start.x) / len;
                    let uz = (w.end.z - w.start.z) / len;
                    *candidate = P2::new(w.start.x + ux * offset, w.start.z + uz * offset);
                }
                for endpoint in [w.start, w.end] {
                    if candidate.distance(endpoint) < self.wall_snap_distance as f32 {
                        *candidate = endpoint;
                    }
                }
            }
        }
        let wall = Wall {
            material: "Pintura branca".into(),
            color: Color32::from_rgb(220, 221, 218),
            id: self.next_id,
            start: a,
            end: b,
            thickness_mm: self.wall_thickness,
            height_mm: self.room[1],
        };
        self.next_id += 1;
        self.selected = Some(Selection::Wall(wall.id));
        self.walls.push(wall);
        self.notice = "Parede criada e conectada ao ponto mais próximo.".into();
        self.notice_error = false;
    }
    fn add_opening_near(&mut self, p: P2, kind: OpeningKind) {
        let found = self
            .walls
            .iter()
            .map(|w| (w, project_to_wall(p, w)))
            .min_by(|a, b| a.1 .1.total_cmp(&b.1 .1));
        if let Some((wall, (offset, dist))) = found {
            let width = if kind == OpeningKind::Door {
                self.door_width
            } else {
                self.window_width
            };
            let height = if kind == OpeningKind::Door {
                self.door_height
            } else {
                self.window_height
            };
            let sill = if kind == OpeningKind::Door {
                0
            } else {
                self.window_sill
            };
            let len = wall.start.distance(wall.end);
            if dist > wall.thickness_mm as f32 / 2.0 + 250.0 {
                self.notice = "Clique sobre uma parede para inserir a abertura.".into();
                self.notice_error = true;
                return;
            }
            if len < width as f32 + 50.0 {
                self.notice = "A abertura precisa ser menor que a parede.".into();
                self.notice_error = true;
                return;
            }
            let center = offset.clamp(width as f32 / 2.0, (len - width as f32 / 2.0));
            let opening = Opening {
                id: self.next_id,
                wall_id: wall.id,
                kind,
                center_mm: center as u32,
                width_mm: width,
                height_mm: height.min(wall.height_mm.saturating_sub(sill)),
                sill_mm: sill,
                style: self.opening_style.clone(),
                material: self.opening_material.clone(),
            };
            self.next_id += 1;
            self.selected = Some(Selection::Opening(opening.id));
            self.openings.push(opening);
            self.notice = if kind == OpeningKind::Door {
                "Porta inserida na parede".into()
            } else {
                "Janela inserida na parede".into()
            };
            self.notice_error = false;
        } else {
            self.notice = "Desenhe uma parede antes de inserir uma abertura.".into();
            self.notice_error = true;
        }
    }
    fn export_csv(&mut self) {
        let p = self.parts();
        if p.is_empty() {
            self.notice = "Adicione módulos ou painéis antes de exportar.".into();
            self.notice_error = true;
            return;
        }
        match write_file(&self.csv_path, &csv_for_parts(&p)) {
            Ok(()) => {
                self.notice = format!("Lista de peças salva em {}", self.csv_path);
                self.notice_error = false
            }
            Err(e) => {
                self.notice = format!("Não foi possível salvar: {e}");
                self.notice_error = true
            }
        }
    }
    fn export_ifc(&mut self) {
        let content = ifc::project(self);
        match write_file(&self.ifc_path, &content) {
            Ok(()) => {
                self.notice = format!("Projeto IFC salvo em {}", self.ifc_path);
                self.notice_error = false
            }
            Err(e) => {
                self.notice = format!("Não foi possível exportar IFC: {e}");
                self.notice_error = true
            }
        }
    }
    fn export_scene_view(&mut self) {
        if self.view_path.to_lowercase().ends_with(".png") {
            match visual::save(self, &self.view_path) {
                Ok(()) => {
                    self.notice = format!("Vista PNG salva em {}", self.view_path);
                    self.notice_error = false;
                }
                Err(e) => {
                    self.notice = e.to_string();
                    self.notice_error = true;
                }
            }
            return;
        }
        let svg = scene_view_svg(
            self.room,
            &self.walls,
            &self.openings,
            &self.modules,
            &self.panels,
            &self.gesso,
            &self.decor,
            &self.materials,
            &self.effective_hidden(),
            &self.floor_texture,
            self.camera,
            self.render_mode,
        );
        match write_file(&self.view_path, &svg) {
            Ok(()) => {
                self.notice = format!("Vista vetorial salva em {}", self.view_path);
                self.notice_error = false
            }
            Err(e) => {
                self.notice = format!("Não foi possível salvar a vista: {e}");
                self.notice_error = true
            }
        }
    }
    fn export_sheet(&mut self) {
        let svg = sheet_svg(self);
        match write_file(&self.sheet_path, &svg) {
            Ok(()) => {
                self.notice = format!("Prancha A4 salva em {}", self.sheet_path);
                self.notice_error = false
            }
            Err(e) => {
                self.notice = format!("Não foi possível salvar a prancha: {e}");
                self.notice_error = true
            }
        }
    }
    fn documentation_text(&self) -> String {
        let mut s=format!("MEMORIAL DO PROJETO\nMarcenaria Livre\n\nAMBIENTE\nDimensões: {} x {} x {} mm\nParedes: {}\nAberturas: {}\nMódulos de marcenaria: {}\nPainéis: {}\nElementos decorativos: {}\n\nPAREDES\n",self.room[0],self.room[1],self.room[2],self.walls.len(),self.openings.len(),self.modules.len(),self.panels.len(),self.decor.len());
        for (n, w) in self.walls.iter().enumerate() {
            s.push_str(&format!(
                "P{}: {:.0} mm, espessura {} mm, altura {} mm, de ({:.0},{:.0}) a ({:.0},{:.0})\n",
                n + 1,
                w.start.distance(w.end),
                w.thickness_mm,
                w.height_mm,
                w.start.x,
                w.start.z,
                w.end.x,
                w.end.z
            ));
        }
        s.push_str("\nMARCENARIA\n");
        for m in &self.modules {
            s.push_str(&format!(
                "{}: {} x {} x {} mm; posição {},{},{}; material {}; veio {}\n",
                m.name,
                m.width_mm,
                m.height_mm,
                m.depth_mm,
                m.x_mm,
                m.y_mm,
                m.z_mm,
                m.material,
                m.grain.label()
            ));
        }
        s
    }
    fn save_documentation(&mut self) {
        match write_file("pranchas-memorial.txt", &self.documentation_text()) {
            Ok(()) => {
                self.notice = "Memorial e quadro de cotas salvos em pranchas-memorial.txt".into();
                self.notice_error = false
            }
            Err(e) => {
                self.notice = format!("Não foi possível salvar a documentação: {e}");
                self.notice_error = true
            }
        }
    }

    fn top_bar(&mut self, ctx: &egui::Context) {
        if self.logo_texture.is_none() {
            let image = image::load_from_memory(include_bytes!("../assets/logo.png"))
                .expect("logo bundled")
                .to_rgba8();
            let size = [image.width() as usize, image.height() as usize];
            self.logo_texture = Some(ctx.load_texture(
                "marcenaria-logo",
                egui::ColorImage::from_rgba_unmultiplied(size, image.as_raw()),
                egui::TextureOptions::LINEAR,
            ));
        }
        egui::TopBottomPanel::top("top").exact_height(218.0).show(ctx,|ui|{
            ui.horizontal(|ui|{ui.add_space(5.0);if let Some(logo)=&self.logo_texture{ui.add(egui::Image::new((logo.id(),Vec2::new(34.0,34.0))));}ui.label(egui::RichText::new(i18n::tr("MARCENARIA LIVRE")).strong().size(17.0).color(GREEN));ui.separator();
                ui.menu_button(i18n::tr("Arquivo"),|ui|{if ui.button(i18n::tr("Novo ambiente")).clicked(){self.new_environment();ui.close_menu();}if ui.button(i18n::tr("Abrir projeto .mar…")).clicked(){self.choose_project_path(false);ui.close_menu();}if ui.button(i18n::tr("Salvar projeto .mar…")).clicked(){self.save_project_action();ui.close_menu();}ui.separator();if ui.button(i18n::tr("Exportar lista CSV")).clicked(){self.export_csv();ui.close_menu();}ui.horizontal(|ui|{ui.add(egui::TextEdit::singleline(&mut self.ifc_path).desired_width(140.0));if ui.button(i18n::tr("Exportar IFC")).clicked(){self.export_ifc();ui.close_menu();}});});
                self.edit_menu(ui);ui.menu_button(i18n::tr("Projeto"),|ui|{if ui.button(i18n::tr("Plano de corte")).clicked(){self.page=Page::Cut;ui.close_menu();}if ui.button(i18n::tr("Lista de peças")).clicked(){self.page=Page::Parts;ui.close_menu();}if ui.button(i18n::tr("Materiais")).clicked(){self.page=Page::Materials;ui.close_menu();}if ui.button(i18n::tr("Orçamento")).clicked(){self.page=Page::Budget;ui.close_menu();}if ui.button(i18n::tr("Método construtivo")).clicked(){self.page=Page::Method;ui.close_menu();}if ui.button(i18n::tr("Biblioteca de portas e janelas")).clicked(){self.page=Page::OpeningLibrary;ui.close_menu();}if ui.button(i18n::tr("Documentação e pranchas")).clicked(){self.page=Page::Documentation;ui.close_menu();}});
                if ui.add_sized([90.,34.],egui::Button::new(i18n::tr("Camadas"))).clicked(){self.show_layers=!self.show_layers;}ui.menu_button(i18n::tr("Visualizar"),|ui|{if ui.button(i18n::tr("Planta superior")).clicked(){self.page=Page::Plan;ui.close_menu();}if ui.button(i18n::tr("Frente ortogonal")).clicked(){self.camera.projection=Projection::Orthographic;self.camera.yaw=std::f32::consts::PI;self.camera.pitch=0.02;self.page=Page::Scene;ui.close_menu();}if ui.button(i18n::tr("Perspectiva")).clicked(){self.camera.projection=Projection::Perspective;self.camera.pitch=0.30;self.page=Page::Scene;ui.close_menu();}});
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center),|ui|{if ui.add(egui::TextEdit::singleline(&mut self.project_path).desired_width(170.0).hint_text("projeto.mar")).changed(){self.project_path_selected=true;}ui.label(i18n::tr("Projeto:"));});
            });ui.separator();
            egui::ScrollArea::horizontal().id_source("ribbon_row_1").show(ui,|ui|{ui.horizontal(|ui|{ui.add_space(4.0);if ribbon_button(ui,"✕","Desselecionar",false){self.cancel_current();}if ribbon_button(ui,"↶","Desfazer",!self.undo_stack.is_empty()){self.undo_action();}if ribbon_button(ui,"📂","Abrir .mar",false){self.choose_project_path(false);}if ribbon_button(ui,"💾","Salvar .mar",false){self.save_project_action();}if ribbon_button(ui,"⚙","Preferências",self.page==Page::Preferences){self.page=Page::Preferences;}if ribbon_button(ui,"⌖","Selecionar",self.tool==Tool::Select){self.toggle_tool(Tool::Select);}if ribbon_button(ui,"▦","Matriz",self.editing.array_open){self.editing.array_open=!self.editing.array_open;}if ribbon_button(ui,"✥","Mover",self.tool==Tool::Move){self.toggle_tool(Tool::Move);}ui.separator();if ribbon_button(ui,"⌂","Planta",self.page==Page::Plan){self.page=Page::Plan;}if ribbon_button(ui,"◩","Ambiente 3D",self.page==Page::Scene){self.page=Page::Scene;}if ribbon_button(ui,"▱","Ortogonal",self.page==Page::Scene&&self.camera.projection==Projection::Orthographic){self.page=Page::Scene;self.camera.projection=Projection::Orthographic;}if ribbon_button(ui,"","Pranchas",self.page==Page::Documentation){self.page=Page::Documentation;}if ribbon_button(ui,"","Método Construtivo",self.page==Page::Method){self.page=Page::Method;}if ribbon_button(ui,"","Puxadores",false){self.inspector=InspectorTab::Properties;self.show_inspector=true;self.page=Page::Scene;}if ribbon_button(ui,"▦","Criador de módulos",self.page==Page::ModuleBuilder){self.page=Page::ModuleBuilder;}});});
            egui::ScrollArea::horizontal().id_source("ribbon_row_2").show(ui,|ui|{ui.horizontal(|ui|{ui.add_space(4.0);if ribbon_button(ui,"▰","Parede reta",self.tool==Tool::Wall){self.toggle_tool(Tool::Wall);}if ribbon_button(ui,"⌁","Parede contínua",self.tool==Tool::WallChain){self.toggle_tool(Tool::WallChain);}if ribbon_button(ui,"◜","Parede curva",self.tool==Tool::WallCurve){self.toggle_tool(Tool::WallCurve);}if ribbon_button(ui,"▯","Porta",self.tool==Tool::Door){self.toggle_tool(Tool::Door);}if ribbon_button(ui,"▤","Janela",self.tool==Tool::Window){self.toggle_tool(Tool::Window);}if ribbon_button(ui,"▱","Rebaixo de gesso",self.page==Page::FinishDesigner&&self.finish_designer.plaster){self.cancel_current();self.finish_designer.plaster=true;self.page=Page::FinishDesigner;}if ribbon_button(ui,"▰","Rodapé decorativo",self.page==Page::FinishDesigner&&!self.finish_designer.plaster){self.tool=Tool::Select;self.finish_designer.plaster=false;self.page=Page::FinishDesigner;}if ribbon_button(ui,"▥","Painel ripado",self.page==Page::PanelDesigner&&self.panel_designer.slatted){self.cancel_current();self.panel_designer.slatted=true;self.page=Page::PanelDesigner;}if ribbon_button(ui,"▤","Painel TV",self.page==Page::PanelDesigner&&!self.panel_designer.slatted){self.cancel_current();self.panel_designer.slatted=false;self.page=Page::PanelDesigner;}if ribbon_button(ui,"⧉","Copiar material",self.tool==Tool::CopyMaterial){self.material_source=None;self.toggle_tool(Tool::CopyMaterial);}if ribbon_button(ui,"▨","Pintar material",self.tool==Tool::PaintMaterial){self.toggle_tool(Tool::PaintMaterial);}if ribbon_button(ui,"⇤","Parede de fundo",self.tool==Tool::WallAnchor){self.toggle_tool(Tool::WallAnchor);}if let Some(wall_id)=self.anchor_wall{if ribbon_button(ui,"✕",&format!("Limpar parede {wall_id}"),false){self.anchor_wall=None;self.notice="Parede de encaixe removida; os módulos voltarão a usar a parede mais próxima.".into();}}ui.separator();if ribbon_button(ui,"","Criar geometria",self.page==Page::GeometryDesigner){self.cancel_current();self.page=Page::GeometryDesigner;}if ribbon_button(ui,"▧","Aberturas",self.page==Page::OpeningLibrary){self.page=Page::OpeningLibrary;}if ribbon_button(ui,"▤","Materiais",self.page==Page::Materials){self.page=Page::Materials;}if ribbon_button(ui,"$","Orçamento",self.page==Page::Budget){self.page=Page::Budget;}if ribbon_button(ui,"⚙","Automatizações",self.page==Page::Automation){self.page=Page::Automation;}if ribbon_button(ui,"▤","Pranchas",self.page==Page::Documentation){self.page=Page::Documentation;}});});
        });
    }

    fn catalog_panel(&mut self, ctx: &egui::Context) {
        egui::SidePanel::left("catalog").resizable(true).default_width(276.0).width_range(244.0..=350.0).show(ctx,|ui|{
            ui.add_space(8.0);ui.label(egui::RichText::new(i18n::tr("BIBLIOTECA DE MÓDULOS")).strong().size(14.0).color(GREEN));ui.label(i18n::tr("Escolha uma peça para inserir no projeto."));ui.add_space(6.0);
            ui.horizontal_wrapped(|ui|{ui.selectable_value(&mut self.catalog,CatalogTab::Kitchen,i18n::tr("Cozinhas"));ui.selectable_value(&mut self.catalog,CatalogTab::Bathroom,i18n::tr("Banheiros"));ui.selectable_value(&mut self.catalog,CatalogTab::Bedroom,i18n::tr("Dormitórios"));ui.selectable_value(&mut self.catalog,CatalogTab::Living,i18n::tr("Salas"));ui.selectable_value(&mut self.catalog,CatalogTab::Office,i18n::tr("Escritórios"));ui.selectable_value(&mut self.catalog,CatalogTab::Store,i18n::tr("Lojas"));ui.selectable_value(&mut self.catalog,CatalogTab::Wardrobes,i18n::tr("Guarda-roupas (40)"));ui.selectable_value(&mut self.catalog,CatalogTab::Shelves,i18n::tr("Estantes (40)"));ui.selectable_value(&mut self.catalog,CatalogTab::Panels,i18n::tr("Painéis (20)"));ui.selectable_value(&mut self.catalog,CatalogTab::Decor,i18n::tr("Decoração"));});ui.separator();
            egui::ScrollArea::vertical().show(ui,|ui|{
                let presets=presets_for(self.catalog);let card_w=(ui.available_width()-10.0)/2.0;
                if self.catalog==CatalogTab::Decor{egui::ComboBox::from_label("Categoria de decoração").selected_text(designers::DECOR_CATEGORIES[self.decor_category]).show_ui(ui,|ui|{for(i,n)in designers::DECOR_CATEGORIES.iter().enumerate(){ui.selectable_value(&mut self.decor_category,i,*n);}});}if self.catalog==CatalogTab::Panels{for (name,w,h,t,mat,grain) in [("MDF vertical",600,2400,18,"Carvalho claro",Grain::Length),("MDF horizontal",1800,900,18,"Carvalho claro",Grain::Width),("Painel TV compacto",1600,1400,18,"Grafite fosco",Grain::Length),("Painel TV casal",2000,1800,18,"Freijó",Grain::Length),("Painel TV amplo",2600,2200,18,"Nogueira",Grain::Length),("Painel TV com prateleira",2200,2100,18,"Carvalho claro",Grain::Length),("Painel ripado freijó",1200,2400,18,"Freijó",Grain::Length),("Painel ripado carvalho",1600,2400,18,"Carvalho natural",Grain::Length),("Painel ripado nogueira",1200,2200,18,"Nogueira",Grain::Length),("Painel ripado horizontal",2000,1200,18,"Freijó",Grain::Width),("Painel cabeceira",1800,1200,18,"Amêndoa",Grain::Width),("Painel escritório",1800,2400,18,"MDF branco",Grain::Length),("Painel expositor loja",1600,2200,18,"Grafite fosco",Grain::Length),("Painel divisória",1200,2400,25,"Carvalho escuro",Grain::Length),("Painel canaletado",1200,1800,18,"MDF branco",Grain::Length),("Painel com nichos",1800,2200,18,"Carvalho claro",Grain::Length),("Painel com armário",2400,2400,18,"Freijó",Grain::Length),("Painel meia altura",2000,1200,18,"Carvalho natural",Grain::Width),("Painel lateral",450,2400,18,"Nogueira",Grain::Length),("Painel sob medida",1800,2400,18,"MDF cru",Grain::Length)]{if ui.add_sized([ui.available_width(),52.0],egui::Button::new(format!("▥  {name}\n{w} × {h} × {t} mm · editável"))).clicked(){self.panel_width=w;self.panel_height=h;self.panel_thickness=t;self.panel_material=mat.into();self.panel_grain=grain;self.panel_name=name.into();self.set_tool(Tool::Panel);self.notice=format!("{name} selecionado. Clique na planta para posicionar e editar.");}}}else if self.catalog==CatalogTab::Decor{for (name,w,h,d,color) in decor_presets().into_iter().filter(|(name,..)|self.decor_category==0||designers::decor_category(name)==self.decor_category).collect::<Vec<_>>(){if ui.add_sized([ui.available_width(),48.0],egui::Button::new(format!("◉  {name}\n{w} × {h} × {d} mm"))).clicked(){self.add_decor(&name,w,h,d,color);}}}else{for row in presets.chunks(2){ui.horizontal(|ui|{for p in row{if module_card(ui,card_w,*p){self.add_preset(*p);}}});ui.add_space(5.0);}}
                if self.catalog!=CatalogTab::Decor&&self.catalog!=CatalogTab::Panels{ui.add_space(8.0);if ui.add_sized([ui.available_width(),52.0],egui::Button::new(i18n::tr("🧰  ABRIR CRIADOR VISUAL\nPersonalizar módulo do zero"))).clicked(){self.page=Page::ModuleBuilder;}ui.collapsing("＋ Criar rapidamente",|ui|{ui.label(i18n::tr("Defina medidas e composição básica."));egui::ComboBox::from_label(i18n::tr("Tipo de módulo")).selected_text(module_kind_label(self.custom_kind)).show_ui(ui,|ui|{for kind in [ModuleKind::Base,ModuleKind::Wall,ModuleKind::Tall,ModuleKind::Drawer,ModuleKind::OpenShelf,ModuleKind::Custom]{ui.selectable_value(&mut self.custom_kind,kind,module_kind_label(kind));}});property_field(ui,"Largura",&mut self.custom_width,100..=5000);property_field(ui,"Altura",&mut self.custom_height,100..=5000);property_field(ui,"Profundidade",&mut self.custom_depth,100..=2000);property_field(ui,"Espessura",&mut self.custom_thickness,6..=40);ui.horizontal(|ui|{ui.label(i18n::tr("Portas"));ui.add(egui::DragValue::new(&mut self.custom_doors).clamp_range(0..=6));});ui.horizontal(|ui|{ui.label(i18n::tr("Prateleiras"));ui.add(egui::DragValue::new(&mut self.custom_shelves).clamp_range(0..=20));});if ui.add_sized([ui.available_width(),34.0],egui::Button::new(i18n::tr("＋ Criar módulo editável"))).clicked(){self.add_custom_module();}});}
            });
        });
    }

    fn inspector_panel(&mut self, ctx: &egui::Context) {
        egui::SidePanel::right("inspector")
            .resizable(true)
            .default_width(284.0)
            .width_range(250.0..=370.0)
            .show(ctx, |ui| {
                ui.add_space(8.0);
                ui.heading(i18n::tr("Ferramentas · Propriedades"));
                ui.horizontal(|ui| {
                    ui.selectable_value(
                        &mut self.inspector,
                        InspectorTab::Tools,
                        i18n::tr("Ferramentas"),
                    );
                    ui.selectable_value(
                        &mut self.inspector,
                        InspectorTab::Properties,
                        i18n::tr("Seleção"),
                    );
                    ui.selectable_value(
                        &mut self.inspector,
                        InspectorTab::Room,
                        i18n::tr("Ambiente"),
                    );
                });
                ui.separator();
                match self.inspector {
                    InspectorTab::Tools => self.tool_properties(ui),
                    InspectorTab::Properties => {
                        egui::ScrollArea::vertical().show(ui, |ui| self.selection_properties(ui));
                    }
                    InspectorTab::Room => self.room_properties(ui),
                }
            });
    }

    fn tool_properties(&mut self, ui: &mut egui::Ui) {
        let material_choices: Vec<String> = self.materials.iter().map(|m| m.name.clone()).collect();
        ui.label(
            egui::RichText::new(i18n::tr("CONSTRUÇÃO DO AMBIENTE"))
                .strong()
                .small()
                .color(Color32::GRAY),
        );
        ui.collapsing("🚪 Portas dos módulos", |ui| {
            let old_style = self.global_door_style;
            egui::ComboBox::from_label(i18n::tr("Estilo global"))
                .selected_text(self.global_door_style.label())
                .show_ui(ui, |ui| {
                    for style in [
                        DoorStyle::Plain,
                        DoorStyle::Provincial,
                        DoorStyle::Horizontal,
                        DoorStyle::Vertical,
                        DoorStyle::Cava,
                        DoorStyle::Glass,
                        DoorStyle::Aluminum,
                        DoorStyle::GlassHorizontal,
                        DoorStyle::GlassVertical,
                    ] {
                        ui.selectable_value(&mut self.global_door_style, style, style.label());
                    }
                });
            ui.checkbox(
                &mut self.door_apply_all,
                i18n::tr("Aplicar a todos os módulos"),
            );
            ui.checkbox(
                &mut self.door_edit_individually,
                i18n::tr("Permitir configurar cada porta"),
            );
            if self.global_door_style != old_style && self.door_apply_all {
                for m in &mut self.modules {
                    m.door_style = self.global_door_style;
                    m.door_styles = vec![self.global_door_style; m.door_count.max(1) as usize];
                }
            }
        });
        tool_picker(ui, self, Tool::Select, "↖ Selecionar");
        tool_picker(ui, self, Tool::Move, "✥ Mover módulo");
        tool_picker(ui, self, Tool::Wall, "▰ Parede reta (2 cliques)");
        tool_picker(ui, self, Tool::WallChain, "⌁ Parede contínua");
        tool_picker(ui, self, Tool::WallCurve, "◜ Parede em segmentos curvos");
        tool_picker(
            ui,
            self,
            Tool::WallAnchor,
            "⇤ Escolher parede de fundo do módulo",
        );
        if let Some(id) = self.anchor_wall {
            let number = self
                .walls
                .iter()
                .position(|w| w.id == id)
                .map(|i| i + 1)
                .unwrap_or(0);
            ui.label(format!("Parede de encaixe atual: {number}"));
            if ui.button(i18n::tr("Limpar parede de encaixe")).clicked() {
                self.anchor_wall = None;
            }
        }
        if ui
            .checkbox(&mut self.wall_grid_enabled, i18n::tr("Encaixar na malha"))
            .changed()
        {
            self.save_preferences();
        }
        if ui
            .checkbox(&mut self.wall_snap_ortho, i18n::tr("Snap ortogonal"))
            .changed()
        {
            self.save_preferences();
        }
        if ui
            .checkbox(
                &mut self.wall_snap_perpendicular,
                i18n::tr("Snap perpendicular à parede próxima"),
            )
            .changed()
        {
            self.save_preferences();
        }
        ui.horizontal(|ui| {
            if ui
                .checkbox(&mut self.wall_snap_angular, i18n::tr("Snap angular"))
                .changed()
            {
                self.save_preferences();
            }
            if self.wall_snap_angular
                && ui
                    .add(
                        egui::DragValue::new(&mut self.wall_angle_step)
                            .clamp_range(5..=90)
                            .suffix("°"),
                    )
                    .changed()
            {
                self.save_preferences();
            }
        });
        ui.horizontal(|ui| {
            ui.label(i18n::tr("Passo da malha"));
            if ui
                .add(
                    egui::DragValue::new(&mut self.modulation_mm)
                        .clamp_range(10..=500)
                        .suffix(" mm"),
                )
                .changed()
            {
                self.save_preferences();
            }
        });
        ui.horizontal(|ui| {
            ui.label(i18n::tr("Raio de encaixe"));
            if ui
                .add(
                    egui::DragValue::new(&mut self.wall_snap_distance)
                        .clamp_range(20..=500)
                        .suffix(" mm"),
                )
                .changed()
            {
                self.save_preferences();
            }
        });
        property_field(ui, "Espessura", &mut self.wall_thickness, 50..=500);
        tool_picker(ui, self, Tool::Door, "▯ Inserir porta");
        property_field(ui, "Largura da porta", &mut self.door_width, 500..=1500);
        property_field(ui, "Altura da porta", &mut self.door_height, 1500..=2600);
        tool_picker(ui, self, Tool::Window, "▤ Inserir janela");
        property_field(ui, "Largura da janela", &mut self.window_width, 300..=3000);
        property_field(ui, "Altura da janela", &mut self.window_height, 300..=2500);
        property_field(ui, "Peitoril", &mut self.window_sill, 0..=2000);
        ui.separator();
        tool_picker(ui, self, Tool::Gesso, "▱ Desenhar rebaixo de gesso");
        ui.label(i18n::tr("MODELOS DE REBAIXO · clique para ajustar"));
        ui.horizontal_wrapped(|ui| {
            if ui.button(i18n::tr("Leve\n100 / 80 mm")).clicked() {
                self.gesso_drop = 100;
                self.gesso_thickness = 80;
            }
            if ui.button(i18n::tr("Sanca\n180 / 100 mm")).clicked() {
                self.gesso_drop = 180;
                self.gesso_thickness = 100;
            }
            if ui.button(i18n::tr("Caixote\n300 / 120 mm")).clicked() {
                self.gesso_drop = 300;
                self.gesso_thickness = 120;
            }
            if ui.button(i18n::tr("Profundo\n450 / 150 mm")).clicked() {
                self.gesso_drop = 450;
                self.gesso_thickness = 150;
            }
        });
        property_field(
            ui,
            "Rebaixo vertical do teto",
            &mut self.gesso_drop,
            50..=1000,
        );
        property_field(
            ui,
            "Espessura da geometria",
            &mut self.gesso_thickness,
            20..=500,
        );
        ui.small(i18n::tr("Desenhe um contorno retangular em planta clicando nos dois cantos; cada geometria pode ser ajustada individualmente após a inserção."));
        ui.separator();
        ui.strong(i18n::tr("PAINÉIS DO AMBIENTE"));
        if ui
            .add_sized(
                [ui.available_width(), 44.0],
                egui::Button::new(i18n::tr("▥  Criar painel ripado editável")),
            )
            .clicked()
        {
            self.panel_width = 1200;
            self.panel_height = 2400;
            self.set_tool(Tool::Panel);
        }
        if ui
            .add_sized(
                [ui.available_width(), 44.0],
                egui::Button::new(i18n::tr("▤  Criar painel para TV editável")),
            )
            .clicked()
        {
            self.panel_width = 1800;
            self.panel_height = 2000;
            self.set_tool(Tool::Panel);
        }
        ui.label(i18n::tr(
            "Depois clique na planta para posicionar; ajuste dimensões e material na seleção.",
        ));
        property_field(ui, "Largura do painel", &mut self.panel_width, 100..=5000);
        property_field(ui, "Altura do painel", &mut self.panel_height, 100..=5000);
        property_field(ui, "Espessura do painel", &mut self.panel_thickness, 6..=60);
        grain_combo(ui, "Veio do painel", &mut self.panel_grain);
        material_combo(
            ui,
            "Acabamento",
            &mut self.panel_material,
            &material_choices,
        );
        if ui
            .button(i18n::tr(
                "▰ Gerar bancada de pedra + frontão para módulos inferiores",
            ))
            .clicked()
        {
            self.create_marble_countertop();
        }
        ui.separator();
        tool_picker(
            ui,
            self,
            Tool::CopyMaterial,
            "⧉ Copiar material · origem e destino",
        );
        tool_picker(
            ui,
            self,
            Tool::PaintMaterial,
            "▨ Pintar com o material selecionado",
        );
        if self.tool == Tool::CopyMaterial {
            ui.label(if self.material_source.is_some() {
                "Material de origem carregado. Clique nos objetos para aplicar."
            } else {
                "Clique primeiro no objeto cujo material deseja copiar."
            });
        }
        if self.tool == Tool::PaintMaterial {
            material_combo(
                ui,
                "Material da ferramenta",
                &mut self.panel_material,
                &material_choices,
            );
        }
        ui.separator();
        if ui
            .button(format!("Mostrar todos ({})", self.hidden_ids.len()))
            .clicked()
        {
            self.show_all();
        }
        if ui.button(i18n::tr("▱ Criar teto automático")).clicked() {
            self.auto_ceiling();
        }
        if ui
            .button(i18n::tr("Portas e janelas · 20 modelos"))
            .clicked()
        {
            self.page = Page::OpeningLibrary;
        }
        if ui.button(i18n::tr("▤ Documentação e pranchas")).clicked() {
            self.page = Page::Documentation;
        }
        ui.strong(i18n::tr("AUTOMATIZAÇÃO DE MÓDULOS"));
        if ui
            .add_sized(
                [220.0, 40.0],
                egui::Button::new(i18n::tr("⚙ Configurar automatizações")),
            )
            .clicked()
        {
            self.page = Page::Automation;
        }
        ui.horizontal_wrapped(|ui| {
            if ui.button(i18n::tr("＋ Tampo")).clicked() {
                self.run_automation("Tampo");
            }
            if ui.button(i18n::tr("＋ Rodapé")).clicked() {
                self.run_automation("Rodapé");
            }
            if ui.button(i18n::tr("＋ Fechamento")).clicked() {
                self.run_automation("Fechamento");
            }
            if ui.button(i18n::tr("＋ Envelopar")).clicked() {
                self.run_automation("Envelopamento");
            }
        });
        ui.separator();
        ui.label(i18n::tr("Parede contínua/curva: clique nos vértices e pressione Esc para terminar. Curvas são aproximadas por segmentos retos editáveis. Delete remove a parede selecionada e seus vãos."));
    }

    fn room_properties(&mut self, ui: &mut egui::Ui) {
        ui.label(egui::RichText::new(i18n::tr("CÔMODO E MODULAÇÃO")).strong());
        property_field(ui, "Largura", &mut self.room[0], 1000..=20000);
        property_field(ui, "Altura", &mut self.room[1], 1000..=10000);
        property_field(ui, "Profundidade", &mut self.room[2], 1000..=20000);
        property_field(ui, "Passo da modulação", &mut self.modulation_mm, 10..=500);
        ui.label(i18n::tr("O passo define o encaixe dos cliques na planta."));
        egui::ComboBox::from_label(i18n::tr("Textura do piso"))
            .selected_text(&self.floor_texture)
            .show_ui(ui, |ui| {
                for t in floor_textures() {
                    ui.selectable_value(&mut self.floor_texture, t.to_string(), t);
                }
            });
        if ui.button(i18n::tr("Criar teto automático")).clicked() {
            self.auto_ceiling();
        }
        if ui
            .button(format!(
                "Mostrar todos os elementos ({})",
                self.hidden_ids.len()
            ))
            .clicked()
        {
            self.show_all();
        }
        if ui.button(i18n::tr("Ambiente novo (apagar cena)")).clicked() {
            self.new_environment();
        }
        ui.separator();
        ui.label(format!(
            "{} paredes · {} portas/janelas",
            self.walls.len(),
            self.openings.len()
        ));
        ui.label(format!(
            "{} módulos · {} itens decorativos · {} painéis · {} geometrias de gesso",
            self.modules.len(),
            self.decor.len(),
            self.panels.len(),
            self.gesso.len()
        ));
    }

    fn selection_properties(&mut self, ui: &mut egui::Ui) {
        let material_choices: Vec<String> = self.materials.iter().map(|m| m.name.clone()).collect();
        match self.selected {
            Some(Selection::Module(id)) => {
                if let Some(m) = self.modules.iter_mut().find(|m| m.id == id) {
                    ui.heading(&m.name);
                    fronts::editor(m, ui);
                    let max_dividers = (m.width_mm.saturating_sub(2 * m.thickness_mm)
                        / (m.thickness_mm + 50))
                        .saturating_sub(1);
                    property_field(
                        ui,
                        "Divisórias verticais",
                        &mut m.divider_count,
                        0..=max_dividers,
                    );
                    ui.label(i18n::tr("MARCENARIA · medidas em milímetros"));
                    ui.separator();
                    property_field(ui, "Largura", &mut m.width_mm, 100..=5000);
                    property_field(ui, "Altura", &mut m.height_mm, 100..=5000);
                    property_field(ui, "Profundidade", &mut m.depth_mm, 100..=2500);
                    property_field(ui, "Posição X", &mut m.x_mm, 0..=20000);
                    property_field(ui, "Cota Y (altura)", &mut m.y_mm, 0..=10000);
                    property_field(ui, "Cota Z", &mut m.z_mm, 0..=20000);
                    ui.horizontal(|ui| {
                        ui.label(i18n::tr("Rotação"));
                        ui.add(
                            egui::DragValue::new(&mut m.rotation_deg)
                                .speed(1.0)
                                .suffix("°"),
                        );
                    });
                    property_field(ui, "Espessura", &mut m.thickness_mm, 6..=40);
                    ui.horizontal(|ui| {
                        ui.label(i18n::tr("Portas"));
                        ui.add(egui::DragValue::new(&mut m.door_count).clamp_range(0..=6));
                    });
                    ui.horizontal(|ui| {
                        ui.label(i18n::tr("Prateleiras"));
                        ui.add(egui::DragValue::new(&mut m.shelf_count).clamp_range(0..=20));
                    });
                    if m.kind == ModuleKind::Drawer {
                        ui.horizontal(|ui| {
                            ui.label(i18n::tr("Gavetas"));
                            ui.add(egui::DragValue::new(&mut m.drawer_count).clamp_range(1..=12));
                        });
                    }
                    if self.door_edit_individually {
                        m.door_styles.resize(m.door_count as usize, m.door_style);
                        ui.strong(i18n::tr("ESTILO POR FOLHA"));
                        for i in 0..m.door_count {
                            egui::ComboBox::from_id_source(("door_leaf", m.id, i))
                                .selected_text(format!(
                                    "Porta {} · {}",
                                    i + 1,
                                    m.door_styles[i as usize].label()
                                ))
                                .show_ui(ui, |ui| {
                                    for style in [
                                        DoorStyle::Plain,
                                        DoorStyle::Provincial,
                                        DoorStyle::Horizontal,
                                        DoorStyle::Vertical,
                                        DoorStyle::Cava,
                                        DoorStyle::Glass,
                                        DoorStyle::Aluminum,
                                        DoorStyle::GlassHorizontal,
                                        DoorStyle::GlassVertical,
                                    ] {
                                        ui.selectable_value(
                                            &mut m.door_styles[i as usize],
                                            style,
                                            style.label(),
                                        );
                                    }
                                });
                        }
                    } else {
                        let old_style = m.door_style;
                        egui::ComboBox::from_label(i18n::tr("Tipo de frente"))
                            .selected_text(m.door_style.label())
                            .show_ui(ui, |ui| {
                                for style in [
                                    DoorStyle::Plain,
                                    DoorStyle::Provincial,
                                    DoorStyle::Horizontal,
                                    DoorStyle::Vertical,
                                    DoorStyle::Cava,
                                    DoorStyle::Glass,
                                    DoorStyle::Aluminum,
                                    DoorStyle::GlassHorizontal,
                                    DoorStyle::GlassVertical,
                                ] {
                                    ui.selectable_value(&mut m.door_style, style, style.label());
                                }
                            });
                        if m.door_style != old_style {
                            m.door_styles = vec![m.door_style; m.door_count as usize];
                        }
                    }
                    material_combo(ui, "Estrutura", &mut m.material, &material_choices);
                    material_combo(
                        ui,
                        "Cor / textura da porta",
                        &mut m.door_material,
                        &material_choices,
                    );
                    grain_combo(ui, "Veio da chapa", &mut m.grain);
                    if ui
                        .button(if m.door_open {
                            "▣ Fechar portas do módulo"
                        } else {
                            "▣ Abrir portas do módulo"
                        })
                        .clicked()
                    {
                        m.door_open = !m.door_open;
                    }
                }
            }
            Some(Selection::Wall(id)) => {
                if let Some(w) = self.walls.iter_mut().find(|w| w.id == id) {
                    ui.heading(i18n::tr("Parede selecionada"));
                    property_field(ui, "Espessura", &mut w.thickness_mm, 50..=500);
                    property_field(ui, "Altura", &mut w.height_mm, 1000..=10000);
                    ui.label(format!("Comprimento: {:.0} mm", w.start.distance(w.end)));
                    ui.label("Revestimento decorativo • fora do orçamento");
                    egui::ScrollArea::vertical()
                        .max_height(220.)
                        .show(ui, |ui| {
                            ui.horizontal_wrapped(|ui| {
                                for mat in self.decor_materials.iter().take(100) {
                                    let label = egui::RichText::new("■").color(mat.color).size(24.);
                                    if ui.button(label).on_hover_text(&mat.name).clicked() {
                                        w.material = mat.name.clone();
                                        w.color = mat.color;
                                    }
                                }
                            });
                        });
                    ui.label(&w.material);
                }
            }
            Some(Selection::Opening(id)) => {
                if let Some(o) = self.openings.iter_mut().find(|o| o.id == id) {
                    ui.heading(if o.kind == OpeningKind::Door {
                        "Porta"
                    } else {
                        "Janela"
                    });
                    ui.label(i18n::tr("AMBIENTE · vão automático na parede"));
                    property_field(ui, "Largura", &mut o.width_mm, 300..=3000);
                    property_field(ui, "Altura", &mut o.height_mm, 300..=3000);
                    property_field(ui, "Peitoril", &mut o.sill_mm, 0..=5000);
                    egui::ComboBox::from_label("Modelo decorativo")
                        .selected_text(&o.style)
                        .show_ui(ui, |ui| {
                            for item in opening_presets(o.kind) {
                                ui.selectable_value(&mut o.style, item.name.into(), item.name);
                            }
                        });
                    if let Some(w) = self.walls.iter().find(|w| w.id == o.wall_id) {
                        let length = w.start.distance(w.end).max(1.) as u32;
                        o.width_mm = o.width_mm.min(length);
                        let half = o.width_mm / 2;
                        property_field(
                            ui,
                            "Posição na parede",
                            &mut o.center_mm,
                            half..=length.saturating_sub(half).max(half),
                        );
                        o.height_mm = o.height_mm.min(w.height_mm);
                        o.sill_mm = o.sill_mm.min(w.height_mm.saturating_sub(o.height_mm));
                    }
                    material_combo(ui, "Cor / textura", &mut o.material, &material_choices);
                }
            }
            Some(Selection::Panel(id)) => {
                if let Some(p) = self.panels.iter_mut().find(|p| p.id == id) {
                    ui.heading(&p.name);
                    ui.checkbox(&mut p.horizontal, i18n::tr("Painel horizontal / tampo"));
                    ui.add(
                        egui::DragValue::new(&mut p.rotation_deg)
                            .prefix("Rotação ")
                            .suffix("°"),
                    );
                    property_field(ui, "Largura", &mut p.width_mm, 100..=10000);
                    property_field(ui, "Altura", &mut p.height_mm, 100..=10000);
                    property_field(ui, "Espessura", &mut p.thickness_mm, 6..=100);
                    property_field(ui, "Posição X", &mut p.x_mm, 0..=20000);
                    property_field(ui, "Cota Y (altura)", &mut p.y_mm, 0..=10000);
                    property_field(ui, "Posição Z", &mut p.z_mm, 0..=20000);
                    grain_combo(ui, "Sentido do veio", &mut p.grain);
                    material_combo(ui, "Material", &mut p.material, &material_choices);
                }
            }
            Some(Selection::Gesso(id)) => {
                if let Some(g) = self.gesso.iter_mut().find(|g| g.id == id) {
                    ui.heading(i18n::tr("Geometria de gesso"));
                    property_field(ui, "Largura", &mut g.width_mm, 100..=10000);
                    property_field(ui, "Profundidade", &mut g.depth_mm, 100..=10000);
                    property_field(ui, "Rebaixo", &mut g.drop_mm, 50..=1500);
                    property_field(ui, "Espessura", &mut g.thickness_mm, 20..=500);
                }
            }
            Some(Selection::Decor(id)) => {
                if let Some(d) = self.decor.iter_mut().find(|d| d.id == id) {
                    ui.heading(&d.name);
                    ui.label(i18n::tr("DECORAÇÃO · fora da lista de fabricação"));
                    property_field(ui, "Elevação Y", &mut d.y_mm, 0..=10000);
                    ui.add(
                        egui::DragValue::new(&mut d.rotation_deg)
                            .prefix("Rotação ")
                            .suffix("°"),
                    );
                    property_field(ui, "Posição X", &mut d.x_mm, 0..=20000);
                    property_field(ui, "Posição Z", &mut d.z_mm, 0..=20000);
                    property_field(ui, "Largura", &mut d.width_mm, 100..=5000);
                    property_field(ui, "Altura", &mut d.height_mm, 100..=5000);
                    property_field(ui, "Profundidade", &mut d.depth_mm, 100..=5000);
                    let decor_choices: Vec<String> = self
                        .decor_materials
                        .iter()
                        .map(|m| m.name.clone())
                        .collect();
                    material_combo(ui, "Material decorativo", &mut d.material, &decor_choices);
                    if let Some(mat) = self.decor_materials.iter().find(|m| m.name == d.material) {
                        d.color = mat.color;
                    }
                }
            }
            None => {
                ui.label(i18n::tr(
                    "Selecione um elemento na cena ou na planta para editar as cotas.",
                ));
            }
        }
        if self.selected.is_some() {
            ui.separator();
            if ui
                .button(i18n::tr("Encaixar módulo na parede mais próxima"))
                .clicked()
            {
                self.snap_selected_module();
            }
            if ui
                .button(i18n::tr("Ocultar elemento selecionado"))
                .clicked()
            {
                self.hide_selected();
            }
            if ui.button(i18n::tr("Duplicar item")).clicked() {
                self.duplicate_selected();
            }
            if ui.button(i18n::tr("Remover item selecionado")).clicked() {
                self.delete_selected();
            }
        }
        if !self.hidden_ids.is_empty()
            && ui
                .button(format!("Mostrar todos ({})", self.hidden_ids.len()))
                .clicked()
        {
            self.show_all();
        }
    }

    fn scene_page(&mut self, ui: &mut egui::Ui, ctx: &egui::Context) {
        ui.horizontal_wrapped(|ui| {
            ui.heading(i18n::tr("Ambiente 3D"));
            ui.checkbox(&mut self.cutaway, i18n::tr("Ocultar paredes à frente"));
            if ui.button(i18n::tr("Enquadrar seleção")).clicked() {
                if let Some(m) = self
                    .modules
                    .iter()
                    .find(|m| self.selected == Some(Selection::Module(m.id)))
                {
                    let c = module_corners(m);
                    self.camera.target = V3::new(
                        c.iter().map(|p| p.x).sum::<f32>() / 4.,
                        m.y_mm as f32 + m.height_mm as f32 / 2.,
                        c.iter().map(|p| p.z).sum::<f32>() / 4.,
                    );
                    self.camera.distance =
                        m.height_mm.max(m.width_mm).max(m.depth_mm) as f32 * 3.0 + 2000.;
                }
            }
            if matches!(self.selected, Some(Selection::Module(_))) {
                ui.separator();
                ui.label(i18n::tr("Gizmo · 50 mm"));
                if ui.button(i18n::tr("◀\nX")).clicked() {
                    self.nudge_selected_module(-50.0, 0.0);
                }
                if ui.button(i18n::tr("X\n▶")).clicked() {
                    self.nudge_selected_module(50.0, 0.0);
                }
                if ui.button(i18n::tr("▲\nZ")).clicked() {
                    self.nudge_selected_module(0.0, -50.0);
                }
                if ui.button(i18n::tr("▼\nZ")).clicked() {
                    self.nudge_selected_module(0.0, 50.0);
                }
            }
            ui.separator();
            egui::ComboBox::from_id_source("render_mode")
                .selected_text(match self.render_mode {
                    RenderMode::Textures => "Texturas",
                    RenderMode::Colors => "Cores",
                    RenderMode::Untextured => "Sem textura",
                    RenderMode::Wireframe => "Wireframe",
                })
                .show_ui(ui, |ui| {
                    ui.selectable_value(
                        &mut self.render_mode,
                        RenderMode::Textures,
                        i18n::tr("Texturas"),
                    );
                    ui.selectable_value(
                        &mut self.render_mode,
                        RenderMode::Colors,
                        i18n::tr("Cores"),
                    );
                    ui.selectable_value(
                        &mut self.render_mode,
                        RenderMode::Untextured,
                        i18n::tr("Sem textura"),
                    );
                    ui.selectable_value(
                        &mut self.render_mode,
                        RenderMode::Wireframe,
                        i18n::tr("Wireframe"),
                    );
                });
            ui.add(egui::TextEdit::singleline(&mut self.view_path).desired_width(140.0));
            if ui.button(i18n::tr("Exportar PNG")).clicked() {
                self.view_path = Path::new(&self.view_path)
                    .with_extension("png")
                    .to_string_lossy()
                    .into_owned();
                self.export_scene_view();
            }
            if ui.button(i18n::tr("Salvar SVG")).clicked() {
                self.export_scene_view();
            }
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                if ui.button(i18n::tr("Vista inicial")).clicked() {
                    self.reset_camera();
                }
            });
        });
        ui.separator();
        let (rect, response) = ui.allocate_exact_size(ui.available_size(), Sense::click_and_drag());
        let painter = ui.painter_at(rect);
        draw_scene(
            &painter,
            rect,
            self.camera,
            self.room,
            &self.walls,
            &self.openings,
            &self.modules,
            &self.panels,
            &self.gesso,
            &self.decor,
            &self.materials,
            &self.effective_hidden(),
            &self.floor_texture,
            self.selected,
            self.render_mode,
            self.cutaway,
        );
        self.highlight_scene_selection(&painter, rect);
        self.handle_scene_input(ctx, &response, rect);
        painter.text(Pos2::new(rect.center().x,rect.bottom()-17.0),egui::Align2::CENTER_CENTER,"Roda: zoom · Alt: mover sem encaixe · Paredes frontais ocultadas na vista · Meio: orbitar · Shift + meio / direito: deslocar",egui::FontId::proportional(12.0),Color32::from_gray(85));
    }

    fn handle_scene_input(&mut self, ctx: &egui::Context, response: &egui::Response, rect: Rect) {
        if response.hovered() {
            let scroll = ctx.input(|i| i.smooth_scroll_delta.y);
            if scroll.abs() > 0.1 {
                self.camera.distance =
                    (self.camera.distance * (-scroll * 0.0025).exp()).clamp(100.0, 200000.0);
            }
        }
        if response.dragged_by(egui::PointerButton::Middle) {
            let d = ctx.input(|i| i.pointer.delta());
            if ctx.input(|i| i.modifiers.shift) {
                let (r, u, _) = self.camera.basis();
                let scale = self.camera.distance / 1700.0;
                self.camera.target = self
                    .camera
                    .target
                    .sub(r.mul(d.x * scale))
                    .add(u.mul(d.y * scale));
            } else {
                self.camera.yaw -= d.x * 0.008;
                self.camera.pitch = (self.camera.pitch + d.y * 0.006).clamp(-0.15, 1.4);
            }
        }
        if response.dragged_by(egui::PointerButton::Secondary) {
            let d = ctx.input(|i| i.pointer.delta());
            let (r, u, _) = self.camera.basis();
            let scale = self.camera.distance / 1700.0;
            self.camera.target = self
                .camera
                .target
                .sub(r.mul(d.x * scale))
                .add(u.mul(d.y * scale));
        }
        if matches!(self.tool, Tool::Move | Tool::Select)
            && response.drag_started_by(egui::PointerButton::Primary)
        {
            if let Some(pos) = ctx.input(|i| i.pointer.interact_pos()) {
                self.choose_selection(self.pick_scene(pos, rect), ctx.input(|i| i.modifiers.ctrl));
                self.scene_drag_offset = match self.selected {
                    Some(Selection::Module(id)) => self
                        .modules
                        .iter()
                        .find(|m| m.id == id)
                        .map(|m| P2::new(m.x_mm as f32, m.z_mm as f32)),
                    _ => None,
                };
            }
        }
        if matches!(self.tool, Tool::Move | Tool::Select)
            && response.dragged_by(egui::PointerButton::Primary)
        {
            if let Some(pos) = ctx.input(|i| i.pointer.interact_pos()) {
                if let Some(Selection::Module(id)) = self.selected {
                    if let Some(m) = self.modules.iter_mut().find(|m| m.id == id) {
                        let delta = visual::drag_delta(
                            self.camera,
                            rect,
                            V3::new(
                                m.x_mm as f32 + m.width_mm as f32 / 2.,
                                m.y_mm as f32 + m.height_mm as f32 / 2.,
                                m.z_mm as f32 + m.depth_mm as f32 / 2.,
                            ),
                            ctx.input(|i| i.pointer.delta()),
                        );
                        let raw = self
                            .scene_drag_offset
                            .get_or_insert(P2::new(m.x_mm as f32, m.z_mm as f32));
                        raw.x = (raw.x + delta.x).clamp(0., self.room[0] as f32);
                        raw.z = (raw.z + delta.z).clamp(0., self.room[2] as f32);
                        m.x_mm = raw.x.round() as u32;
                        m.z_mm = raw.z.round() as u32;
                        clamp_module_to_room(m, self.room);
                        if !ctx.input(|i| i.modifiers.alt) {
                            snap_module_to_wall_target_with_limit(
                                m,
                                &self.walls,
                                self.room,
                                self.anchor_wall,
                                self.wall_snap_distance as f32,
                            );
                        }
                        clamp_module_to_room(m, self.room);
                    }
                } else if let Some(Selection::Opening(id)) = self.selected {
                    if let Some(o) = self.openings.iter_mut().find(|o| o.id == id) {
                        if let Some(w) = self.walls.iter().find(|w| w.id == o.wall_id) {
                            let len = w.start.distance(w.end).max(1.);
                            let (a, b) = (
                                self.camera
                                    .project(V3::new(w.start.x, o.sill_mm as f32, w.start.z), rect),
                                self.camera
                                    .project(V3::new(w.end.x, o.sill_mm as f32, w.end.z), rect),
                            );
                            if let (Some(a), Some(b)) = (a, b) {
                                let dir = b.0 - a.0;
                                let delta = ctx.input(|i| i.pointer.delta());
                                let along = delta.dot(dir) / dir.length_sq().max(1.) * len;
                                let half = o.width_mm as f32 / 2.;
                                o.center_mm = (o.center_mm as f32 + along)
                                    .clamp(half, (len - half).max(half))
                                    .round() as u32;
                            }
                        }
                    }
                } else if let Some(Selection::Decor(id)) = self.selected {
                    let d = ctx.input(|i| i.pointer.delta());
                    if let Some(item) = self.decor.iter_mut().find(|d| d.id == id) {
                        let scale = self.camera.distance / 1700.0;
                        item.x_mm = (item.x_mm as f32 + d.x * scale).round().max(0.0) as u32;
                        item.z_mm = (item.z_mm as f32 + d.y * scale).round().max(0.0) as u32;
                    }
                }
            }
        } else if self.tool == Tool::Select && response.clicked() {
            if let Some(p) = ctx.input(|i| i.pointer.interact_pos()) {
                self.choose_selection(self.pick_scene(p, rect), ctx.input(|i| i.modifiers.ctrl));
            }
        }
        if !ctx.input(|i| i.pointer.button_down(egui::PointerButton::Primary)) {
            self.scene_drag_offset = None;
        }
    }

    fn plan_page(&mut self, ui: &mut egui::Ui, ctx: &egui::Context) {
        ui.horizontal(|ui| {
            ui.heading(i18n::tr("Planta · Construção do ambiente"));
            ui.label(format!(
                "{} paredes  ·  {} aberturas",
                self.walls.len(),
                self.openings.len()
            ));
            ui.separator();
            if ui.button(i18n::tr("＋ Zoom")).clicked() {
                self.plan_zoom = (self.plan_zoom * 1.2).min(4.0);
            }
            if ui.button(i18n::tr("− Zoom")).clicked() {
                self.plan_zoom = (self.plan_zoom / 1.2).max(0.35);
            }
            if ui.button(i18n::tr("←")).clicked() {
                self.plan_pan.x -= 50.0;
            }
            if ui.button(i18n::tr("→")).clicked() {
                self.plan_pan.x += 50.0;
            }
            if ui.button(i18n::tr("↑")).clicked() {
                self.plan_pan.y -= 50.0;
            }
            if ui.button(i18n::tr("↓")).clicked() {
                self.plan_pan.y += 50.0;
            }
            if ui.button(i18n::tr("⌖ Centralizar")).clicked() {
                self.plan_pan = Vec2::ZERO;
            }
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                if ui.button(i18n::tr("Vista 3D")).clicked() {
                    self.page = Page::Scene;
                }
            });
        });
        let wall_tool = matches!(self.tool, Tool::Wall | Tool::WallChain | Tool::WallCurve);
        if wall_tool {
            ui.horizontal(|ui| {
                ui.checkbox(&mut self.wall_dimensions_locked, i18n::tr("Medidas exatas"));
                ui.label(i18n::tr("Comprimento"));
                ui.add(
                    egui::DragValue::new(&mut self.wall_length_mm)
                        .clamp_range(100..=30000)
                        .suffix(" mm"),
                );
                ui.label(i18n::tr("Direção"));
                ui.add(
                    egui::DragValue::new(&mut self.wall_direction_deg)
                        .speed(1.0)
                        .clamp_range(-360.0..=360.0)
                        .suffix("°"),
                );
                if self.pending_point.is_some() {
                    ui.colored_label(GREEN, "Defina o próximo trecho e clique para confirmar");
                } else {
                    ui.label(i18n::tr("Clique para iniciar a parede"));
                }
            });
        }
        if ui
            .checkbox(
                &mut self.plan_rulers,
                i18n::tr("Exibir réguas e medidas na planta"),
            )
            .changed()
        {
            self.save_preferences();
        }
        ui.separator();
        let (rect, response) = ui.allocate_exact_size(ui.available_size(), Sense::click_and_drag());
        let painter = ui.painter_at(rect);
        let tr = PlanTransform::new(rect, self.room, self.plan_zoom, self.plan_pan);
        draw_plan(
            &painter,
            tr,
            self.room,
            &self.walls,
            &self.openings,
            &self.modules,
            &self.panels,
            &self.gesso,
            &self.decor,
            &self.materials,
            &self.effective_hidden(),
            self.selected,
            self.pending_point,
            self.tool,
            self.plan_rulers,
            ctx,
        );
        self.highlight_plan_selection(&painter, tr);
        if wall_tool {
            if let (Some(start), Some(screen)) = (
                self.pending_point,
                ctx.input(|i| i.pointer.hover_pos())
                    .filter(|p| rect.contains(*p)),
            ) {
                let mut end = tr.world(screen);
                if self.wall_grid_enabled {
                    end.x = snap(end.x, self.modulation_mm as f32);
                    end.z = snap(end.z, self.modulation_mm as f32);
                }
                end.x = end.x.clamp(0.0, self.room[0] as f32);
                end.z = end.z.clamp(0.0, self.room[2] as f32);
                if self.wall_dimensions_locked {
                    end = wall_point_from_measure(
                        start,
                        self.wall_length_mm,
                        self.wall_direction_deg,
                    );
                } else if self.wall_snap_ortho
                    || self.wall_snap_perpendicular
                    || self.wall_snap_angular
                {
                    end = constrain_wall_point(
                        start,
                        end,
                        &self.walls,
                        self.wall_snap_ortho,
                        self.wall_snap_perpendicular,
                        self.wall_snap_angular,
                        self.wall_angle_step,
                    );
                }
                let a = tr.screen(start);
                let b = tr.screen(end);
                painter.line_segment([a, b], Stroke::new(3.0, GREEN));
                let len = start.distance(end);
                let angle = (end.z - start.z).atan2(end.x - start.x).to_degrees();
                painter.text(
                    a + (b - a) * 0.5 + Vec2::new(0.0, -14.0),
                    egui::Align2::CENTER_CENTER,
                    format!("{:.0} mm  ·  {:.1}°", len, angle),
                    egui::FontId::proportional(13.0),
                    GREEN,
                );
            }
        }
        self.handle_plan_input(ctx, &response, tr, rect);
    }

    fn handle_plan_input(
        &mut self,
        ctx: &egui::Context,
        response: &egui::Response,
        tr: PlanTransform,
        rect: Rect,
    ) {
        if response.hovered() {
            let scroll = ctx.input(|i| i.smooth_scroll_delta.y);
            if scroll.abs() > 0.1 {
                self.plan_zoom = (self.plan_zoom * (-scroll * 0.002).exp()).clamp(0.35, 4.0);
            }
        }
        if response.dragged_by(egui::PointerButton::Middle)
            || response.dragged_by(egui::PointerButton::Secondary)
        {
            self.plan_pan += ctx.input(|i| i.pointer.delta());
            return;
        }
        let pos = ctx.input(|i| i.pointer.interact_pos());
        if matches!(self.tool, Tool::Move | Tool::Select)
            && response.dragged_by(egui::PointerButton::Primary)
        {
            if response.drag_started_by(egui::PointerButton::Primary) {
                if let Some(p) = pos {
                    self.choose_selection(
                        pick_plan_any(
                            p,
                            tr,
                            &self.walls,
                            &self.openings,
                            &self.modules,
                            &self.panels,
                            &self.gesso,
                            &self.decor,
                            &self.effective_hidden(),
                        ),
                        ctx.input(|i| i.modifiers.ctrl),
                    );
                    self.scene_drag_offset = self
                        .modules
                        .iter()
                        .find(|m| self.selected == Some(Selection::Module(m.id)))
                        .map(|m| P2::new(m.x_mm as f32, m.z_mm as f32));
                }
            }
            let d = ctx.input(|i| i.pointer.delta());
            match self.selected {
                Some(Selection::Module(id)) => {
                    if let Some(m) = self.modules.iter_mut().find(|m| m.id == id) {
                        let raw = self
                            .scene_drag_offset
                            .get_or_insert(P2::new(m.x_mm as f32, m.z_mm as f32));
                        raw.x = (raw.x + d.x / tr.scale).clamp(0., self.room[0] as f32);
                        raw.z = (raw.z + d.y / tr.scale).clamp(0., self.room[2] as f32);
                        m.x_mm = raw.x.round() as u32;
                        m.z_mm = raw.z.round() as u32;
                        clamp_module_to_room(m, self.room);
                        if !ctx.input(|i| i.modifiers.alt) {
                            snap_module_to_wall_target_with_limit(
                                m,
                                &self.walls,
                                self.room,
                                self.anchor_wall,
                                self.wall_snap_distance as f32,
                            );
                        }
                        clamp_module_to_room(m, self.room);
                    }
                }
                Some(Selection::Opening(id)) => {
                    if let Some(o) = self.openings.iter_mut().find(|o| o.id == id) {
                        if let Some(w) = self.walls.iter().find(|w| w.id == o.wall_id) {
                            let len = w.start.distance(w.end).max(1.);
                            let along = (d.x * (w.end.x - w.start.x) + d.y * (w.end.z - w.start.z))
                                / (tr.scale * len);
                            let half = o.width_mm as f32 / 2.;
                            o.center_mm = (o.center_mm as f32 + along)
                                .clamp(half, (len - half).max(half))
                                .round() as u32;
                        }
                    }
                }
                Some(Selection::Decor(id)) => {
                    if let Some(item) = self.decor.iter_mut().find(|d| d.id == id) {
                        item.x_mm = (item.x_mm as f32 + d.x / tr.scale).round().max(0.0) as u32;
                        item.z_mm = (item.z_mm as f32 + d.y / tr.scale).round().max(0.0) as u32;
                    }
                }
                _ => {}
            }
            return;
        }
        if !response.clicked() {
            return;
        }
        let Some(screen) = pos.filter(|p| rect.contains(*p)) else {
            return;
        };
        let wall_tool = matches!(self.tool, Tool::Wall | Tool::WallChain | Tool::WallCurve);
        let mut point = tr.world(screen);
        let exact_wall_end = wall_tool
            && self.tool != Tool::WallCurve
            && self.pending_point.is_some()
            && self.wall_dimensions_locked;
        if exact_wall_end {
            point = wall_point_from_measure(
                self.pending_point.unwrap(),
                self.wall_length_mm,
                self.wall_direction_deg,
            );
        } else {
            if self.wall_grid_enabled {
                point.x = snap(point.x, self.modulation_mm as f32);
                point.z = snap(point.z, self.modulation_mm as f32);
            }
            point.x = point.x.clamp(0.0, self.room[0] as f32);
            point.z = point.z.clamp(0.0, self.room[2] as f32);
        }
        if wall_tool && self.tool != Tool::WallCurve && !exact_wall_end {
            if let Some(anchor) = self.pending_point {
                point = constrain_wall_point(
                    anchor,
                    point,
                    &self.walls,
                    self.wall_snap_ortho,
                    self.wall_snap_perpendicular,
                    self.wall_snap_angular,
                    self.wall_angle_step,
                );
            }
        }
        if exact_wall_end
            && (point.x < 0.0
                || point.z < 0.0
                || point.x > self.room[0] as f32
                || point.z > self.room[2] as f32)
        {
            self.notice =
                "Esse trecho ultrapassa o limite da planta. Ajuste o comprimento ou a direção."
                    .into();
            self.notice_error = true;
            return;
        }
        if wall_tool && self.pending_point.is_some() {
            let start = self.pending_point.unwrap();
            let dx = point.x - start.x;
            let dz = point.z - start.z;
            self.wall_length_mm = start.distance(point).round().max(100.0) as u32;
            self.wall_direction_deg = dz.atan2(dx).to_degrees();
        }
        match self.tool {
            Tool::Wall => {
                if let Some(start) = self.pending_point.take() {
                    self.add_wall_segment(start, point);
                } else {
                    self.pending_point = Some(point);
                    self.notice = "Agora clique no ponto final da parede.".into();
                    self.notice_error = false;
                }
            }
            Tool::WallCurve => self.curve_click(point),
            Tool::WallChain => {
                if let Some(start) = self.pending_point {
                    self.add_wall_segment(start, point);
                    self.pending_point = Some(point);
                    self.notice = if self.tool == Tool::WallCurve {
                        "Segmento curvo aproximado criado; continue clicando para definir a curva. Esc encerra.".into()
                    } else {
                        "Segmento criado; continue clicando para prolongar a parede. Esc encerra."
                            .into()
                    };
                } else {
                    self.pending_point = Some(point);
                    self.notice = if self.tool == Tool::WallCurve {
                        "Clique nos pontos do contorno curvo; use segmentos curtos. Esc encerra."
                            .into()
                    } else {
                        "Clique no próximo ponto da parede contínua. Esc encerra.".into()
                    };
                }
                self.notice_error = false;
            }
            Tool::Door => self.add_opening_near(point, OpeningKind::Door),
            Tool::Window => self.add_opening_near(point, OpeningKind::Window),
            Tool::Panel => {
                self.add_panel_at(point);
                self.notice="Painel inserido na posição da planta. Edite altura e posição no painel Seleção.".into();
            }
            Tool::Gesso => {
                if let Some(start) = self.pending_point.take() {
                    let x = start.x.min(point.x);
                    let z = start.z.min(point.z);
                    let g = GessoBlock {
                        id: self.next_id,
                        x_mm: x as u32,
                        z_mm: z as u32,
                        width_mm: (start.x - point.x).abs() as u32,
                        depth_mm: (start.z - point.z).abs() as u32,
                        drop_mm: self.gesso_drop,
                        thickness_mm: self.gesso_thickness,
                    };
                    if g.width_mm > 100 && g.depth_mm > 100 {
                        self.next_id += 1;
                        self.selected = Some(Selection::Gesso(g.id));
                        self.gesso.push(g);
                        self.notice = "Geometria de gesso criada.".into();
                    } else {
                        self.notice =
                            "Marque dois cantos com pelo menos 100 mm de distância.".into();
                        self.notice_error = true;
                    }
                } else {
                    self.pending_point = Some(point);
                    self.notice = "Agora marque o canto oposto da geometria.".into();
                }
            }
            Tool::WallAnchor => {
                if let Some(wall_id) =
                    pick_wall_plan(screen, tr, &self.walls, &self.effective_hidden())
                {
                    self.anchor_wall = Some(wall_id);
                    self.tool = Tool::Select;
                    self.pending_point = None;
                    self.snap_selected_module();
                    let wall_number = self
                        .walls
                        .iter()
                        .position(|w| w.id == wall_id)
                        .map(|i| i + 1)
                        .unwrap_or(0);
                    self.notice=format!("Parede {wall_number} escolhida como fundo. Módulos inseridos ou movidos serão encostados nela.");
                    self.notice_error = false;
                } else {
                    self.notice =
                        "Clique sobre uma parede visível para defini-la como fundo dos módulos."
                            .into();
                    self.notice_error = true;
                }
            }
            Tool::Select => {
                self.choose_selection(
                    pick_plan_any(
                        screen,
                        tr,
                        &self.walls,
                        &self.openings,
                        &self.modules,
                        &self.panels,
                        &self.gesso,
                        &self.decor,
                        &self.effective_hidden(),
                    ),
                    ctx.input(|i| i.modifiers.ctrl),
                );
            }
            Tool::CopyMaterial | Tool::PaintMaterial => {
                let target = pick_plan_any(
                    screen,
                    tr,
                    &self.walls,
                    &self.openings,
                    &self.modules,
                    &self.panels,
                    &self.gesso,
                    &self.decor,
                    &self.effective_hidden(),
                );
                if let Some(target) = target {
                    self.selected = Some(target);
                    if self.tool == Tool::CopyMaterial {
                        if let Some(source) = self.material_source.clone() {
                            self.apply_material_to(target, &source);
                            self.notice = format!("Material aplicado: {source}");
                        } else if let Some(source) = self.material_of_selection(target) {
                            self.material_source = Some(source.clone());
                            self.notice = format!("Material copiado: {source}. Clique no destino.");
                        } else {
                            self.notice = "Esse elemento não tem material copiável.".into();
                        }
                    } else {
                        let material = self.panel_material.clone();
                        self.apply_material_to(target, &material);
                        self.notice = format!("Material aplicado: {material}");
                    }
                }
            }
            Tool::Move => {}
        }
    }

    fn parts_page(&mut self, ui: &mut egui::Ui) {
        ui.horizontal(|ui| {
            ui.heading(i18n::tr("Lista de peças"));
            if ui.button(i18n::tr("Plano de corte")).clicked() {
                self.page = Page::Cut;
            }
            ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                if ui.button(i18n::tr("Exportar CSV")).clicked() {
                    self.export_csv();
                }
                ui.add(
                    egui::TextEdit::singleline(&mut self.csv_path)
                        .desired_width(260.0)
                        .hint_text("caminho/arquivo.csv"),
                );
            });
        });
        if !self.notice.is_empty() {
            ui.colored_label(
                if self.notice_error {
                    Color32::DARK_RED
                } else {
                    GREEN
                },
                &self.notice,
            );
        }
        ui.separator();
        let parts = self.parts();
        if parts.is_empty() {
            ui.centered_and_justified(|ui| {
                ui.label(i18n::tr(
                    "A lista está vazia. Insira módulos ou painéis pelo catálogo e pela planta.",
                ))
            });
            return;
        }
        egui::ScrollArea::both().show(ui, |ui| {
            egui::Grid::new("parts")
                .striped(true)
                .min_col_width(72.0)
                .show(ui, |ui| {
                    for h in [
                        "Grupo",
                        "Peça",
                        "Qtd.",
                        "Comprimento",
                        "Largura",
                        "Espessura",
                        "Material",
                        "Fita",
                        "Veio",
                    ] {
                        ui.strong(h);
                    }
                    ui.end_row();
                    for p in parts {
                        ui.label(p.group);
                        ui.label(p.name);
                        ui.label(p.quantity.to_string());
                        ui.label(p.length_mm.to_string());
                        ui.label(p.width_mm.to_string());
                        ui.label(p.thickness_mm.to_string());
                        ui.label(p.material);
                        ui.label(p.edge);
                        ui.label(p.grain);
                        ui.end_row();
                    }
                });
        });
    }

    fn opening_library_page(&mut self, ui: &mut egui::Ui) {
        ui.heading(i18n::tr("Biblioteca de portas e janelas"));
        ui.label(i18n::tr(
            "Escolha um modelo. Ao inserir na planta, o vão é criado automaticamente na parede.",
        ));
        ui.horizontal(|ui| {
            ui.selectable_value(
                &mut self.opening_catalog_kind,
                OpeningKind::Door,
                i18n::tr("Portas (20 modelos)"),
            );
            ui.selectable_value(
                &mut self.opening_catalog_kind,
                OpeningKind::Window,
                i18n::tr("Janelas (20 modelos)"),
            );
        });
        ui.separator();
        let entries = opening_presets(self.opening_catalog_kind);
        egui::ScrollArea::vertical().show(ui, |ui| {
            for row in entries.chunks(4) {
                ui.horizontal(|ui| {
                    for item in row {
                        if opening_card(ui, *item) {
                            self.door_width = item.width;
                            self.door_height = item.height;
                            self.window_width = item.width;
                            self.window_height = item.height;
                            self.window_sill = item.sill;
                            self.opening_style = item.name.into();
                            self.set_tool(if self.opening_catalog_kind == OpeningKind::Door {
                                Tool::Door
                            } else {
                                Tool::Window
                            });
                            self.notice = format!(
                                "{} selecionada. Clique na parede para posicioná-la.",
                                item.name
                            );
                        }
                    }
                });
                ui.add_space(6.0);
            }
        });
    }
    fn documentation_page(&mut self, ui: &mut egui::Ui) {
        documentation::editor(self, ui);
    }
    fn preferences_page(&mut self, ui: &mut egui::Ui) {
        ui.heading(i18n::tr("Preferências"));
        commands::settings(self, ui);
        ui.label(i18n::tr("Ajuste visual e atalhos do ambiente de trabalho."));
        ui.separator();
        let mut changed = false;
        ui.strong(i18n::tr("APARÊNCIA E ORGANIZAÇÃO"));
        ui.horizontal_wrapped(|ui| {
            ui.label(i18n::tr("☀ Interface clara"));
            let old = self.language;
            egui::ComboBox::from_label(i18n::tr("Idioma"))
                .selected_text(["Português", "English", "Español"][self.language])
                .show_ui(ui, |ui| {
                    for (i, name) in ["Português", "English", "Español"].iter().enumerate() {
                        ui.selectable_value(&mut self.language, i, *name);
                    }
                });
            changed |= old != self.language;

            changed |= preference_tile(
                ui,
                "▦",
                "Biblioteca",
                "Mostrar módulos à esquerda",
                self.show_catalog,
                || self.show_catalog = !self.show_catalog,
            );
            changed |= preference_tile(
                ui,
                "⚙",
                "Propriedades",
                "Mostrar painel à direita",
                self.show_inspector,
                || self.show_inspector = !self.show_inspector,
            );
            changed |= preference_tile(
                ui,
                "⌨",
                "Dicas de comando",
                "Exibir comando na barra inferior",
                self.show_command_hints,
                || self.show_command_hints = !self.show_command_hints,
            );
            changed |= preference_tile(
                ui,
                "↔",
                "Réguas da planta",
                "Exibir medidas nos eixos da planta",
                self.plan_rulers,
                || self.plan_rulers = !self.plan_rulers,
            );
        });
        ui.separator();
        ui.strong(i18n::tr("ATALHOS PERSONALIZÁVEIS"));
        ui.label(i18n::tr("Escolha uma tecla para cada ferramenta."));
        ui.columns(2, |c| {
            for (i, (icon, label, key)) in [
                ("↶", "Desfazer (Ctrl +)", &mut self.shortcut_undo),
                ("⌖", "Selecionar ferramenta", &mut self.shortcut_select),
                ("⌁", "Parede contínua", &mut self.shortcut_wall),
                ("⧉", "Copiar material", &mut self.shortcut_copy),
                ("▨", "Pintar material", &mut self.shortcut_paint),
            ]
            .into_iter()
            .enumerate()
            {
                c[i % 2].group(|ui| {
                    ui.horizontal(|ui| {
                        ui.label(egui::RichText::new(icon).size(24.0));
                        changed |= shortcut_combo(ui, label, key);
                    });
                });
            }
        });
        ui.separator();
        ui.strong(i18n::tr("SNAP E MODULAÇÃO DE PAREDES"));
        ui.horizontal_wrapped(|ui| {
            changed |= preference_tile(
                ui,
                "▦",
                "Malha",
                "Encaixe na modulação",
                self.wall_grid_enabled,
                || self.wall_grid_enabled = !self.wall_grid_enabled,
            );
            changed |= preference_tile(
                ui,
                "↔",
                "Ortogonal",
                "Ângulos de 90°",
                self.wall_snap_ortho,
                || self.wall_snap_ortho = !self.wall_snap_ortho,
            );
            changed |= preference_tile(
                ui,
                "⊥",
                "Perpendicular",
                "Alinhar à parede próxima",
                self.wall_snap_perpendicular,
                || self.wall_snap_perpendicular = !self.wall_snap_perpendicular,
            );
            changed |= preference_tile(
                ui,
                "∠",
                "Ângulo fixo",
                "Restringir por incremento",
                self.wall_snap_angular,
                || self.wall_snap_angular = !self.wall_snap_angular,
            );
        });
        ui.horizontal(|ui| {
            ui.add_enabled(
                self.wall_snap_angular,
                egui::DragValue::new(&mut self.wall_angle_step)
                    .clamp_range(5..=90)
                    .prefix("Ângulo ")
                    .suffix("°"),
            );
            changed |= ui
                .add(
                    egui::DragValue::new(&mut self.modulation_mm)
                        .clamp_range(10..=500)
                        .prefix("Malha ")
                        .suffix(" mm"),
                )
                .changed();
            changed |= ui
                .add(
                    egui::DragValue::new(&mut self.wall_snap_distance)
                        .clamp_range(20..=500)
                        .prefix("Distância de snap ")
                        .suffix(" mm"),
                )
                .changed();
        });
        if changed {
            self.save_preferences();
            self.notice = "Preferências salvas neste computador.".into();
            self.notice_error = false;
        }
    }
    fn module_builder_page(&mut self, ui: &mut egui::Ui) {
        ui.heading(i18n::tr("Criador visual de módulos"));
        ui.label(i18n::tr("Configure a caixa, os componentes internos e o acabamento antes de inserir no ambiente."));
        ui.separator();
        ui.columns(2,|cols|{cols[0].group(|ui|{ui.strong(i18n::tr("ESTRUTURA"));egui::ComboBox::from_label(i18n::tr("Composição")).selected_text(module_kind_label(self.custom_kind)).show_ui(ui,|ui|{for kind in [ModuleKind::Base,ModuleKind::Wall,ModuleKind::Tall,ModuleKind::Drawer,ModuleKind::OpenShelf,ModuleKind::Custom]{ui.selectable_value(&mut self.custom_kind,kind,module_kind_label(kind));}});property_field(ui,"Largura",&mut self.custom_width,100..=5000);property_field(ui,"Altura",&mut self.custom_height,100..=5000);property_field(ui,"Profundidade",&mut self.custom_depth,100..=2000);property_field(ui,"Espessura da chapa",&mut self.custom_thickness,6..=40);ui.strong(i18n::tr("COMPONENTES"));ui.horizontal(|ui|{ui.label("Divisórias verticais");ui.add(egui::DragValue::new(&mut self.custom_dividers).clamp_range(0..=10));});ui.horizontal(|ui|{ui.label("Gavetas");ui.add(egui::DragValue::new(&mut self.custom_drawers).clamp_range(0..=12));});ui.label("Gaveteiro: frentes externas. Demais composições: gavetas internas inferiores, com prateleiras acima.");property_field(ui,"Altura da zona de gavetas",&mut self.custom_drawer_height,100..=self.custom_height.saturating_sub(80).max(100));ui.horizontal(|ui|{ui.label("Topo");egui::ComboBox::from_id_source("custom_top").selected_text(["Chapa inteira","Sem chapa superior","Duas travessas"][self.custom_top.min(2) as usize]).show_ui(ui,|ui|{for (i,n) in ["Chapa inteira","Sem chapa superior","Duas travessas"].iter().enumerate(){ui.selectable_value(&mut self.custom_top,i as u8,*n);}});});ui.horizontal(|ui|{ui.label(i18n::tr("Portas"));ui.add(egui::DragValue::new(&mut self.custom_doors).clamp_range(0..=8));});ui.horizontal(|ui|{ui.label(i18n::tr("Prateleiras horizontais"));ui.add(egui::DragValue::new(&mut self.custom_shelves).clamp_range(0..=20));});});cols[1].group(|ui|{ui.strong(i18n::tr("FRENTES E ACABAMENTO"));egui::ComboBox::from_label(i18n::tr("Estilo da porta")).selected_text(self.custom_style.label()).show_ui(ui,|ui|{for style in [DoorStyle::Plain,DoorStyle::Provincial,DoorStyle::Horizontal,DoorStyle::Vertical,DoorStyle::Cava,DoorStyle::Glass,DoorStyle::Aluminum,DoorStyle::GlassHorizontal,DoorStyle::GlassVertical]{ui.selectable_value(&mut self.custom_style,style,style.label());}});let choices:Vec<String>=self.materials.iter().map(|m|m.name.clone()).collect();material_combo(ui,"Material",&mut self.custom_material,&choices);ui.label(format!("Veio padrão: {}",self.panel_grain.label()));grain_combo(ui,"Sentido do veio",&mut self.panel_grain);ui.separator();ui.strong(i18n::tr("PRÉ-VISUALIZAÇÃO"));let pr=preset("Prévia",self.custom_kind,self.custom_width,self.custom_height,self.custom_depth,0,self.custom_doors,self.custom_shelves,0);fabrication::module_preview(self,ui,pr);});});
        ui.separator();
        ui.horizontal(|ui| {
            if ui.button(i18n::tr("Voltar ao catálogo")).clicked() {
                self.page = Page::Scene;
            }
            if ui
                .add_sized(
                    [260.0, 46.0],
                    egui::Button::new(i18n::tr("Criar e posicionar na parede")),
                )
                .clicked()
            {
                self.add_custom_module();
            }
        });
    }
    fn auto_ceiling(&mut self) {
        if self.gesso.iter().any(|g| {
            g.x_mm == 0 && g.z_mm == 0 && g.width_mm == self.room[0] && g.depth_mm == self.room[2]
        }) {
            self.notice = "O teto automático já existe.".into();
            return;
        }
        let g = GessoBlock {
            id: self.next_id,
            x_mm: 0,
            z_mm: 0,
            width_mm: self.room[0],
            depth_mm: self.room[2],
            drop_mm: 0,
            thickness_mm: 100,
        };
        self.next_id += 1;
        self.gesso.push(g);
        self.selected = Some(Selection::Gesso(self.next_id - 1));
        self.page = Page::Scene;
        self.notice = "Teto automático criado para cobrir todo o ambiente.".into();
    }
    fn materials_page(&mut self, ui: &mut egui::Ui) {
        ui.heading(i18n::tr("Biblioteca de materiais"));
        ui.label(i18n::tr("Marcenaria e decoração têm catálogos separados. Escolha o componente que receberá o acabamento."));
        ui.horizontal_wrapped(|ui| {
            ui.selectable_value(&mut self.material_target, 0, i18n::tr("▦ Módulo inteiro"));
            ui.selectable_value(&mut self.material_target, 1, i18n::tr("▤ Corpo"));
            ui.selectable_value(&mut self.material_target, 2, i18n::tr("▯ Portas e frentes"));
        });
        let choices = self
            .materials
            .iter()
            .map(|m| m.name.clone())
            .collect::<Vec<_>>();
        material_combo(
            ui,
            "Acabamento a aplicar",
            &mut self.panel_material,
            &choices,
        );
        ui.horizontal(|ui| {
            if ui
                .add_sized(
                    [180.0, 40.0],
                    egui::Button::new(i18n::tr("▨ Aplicar na seleção")),
                )
                .clicked()
            {
                if let Some(s) = self.selected {
                    let mat = self.panel_material.clone();
                    self.apply_material_to(s, &mat);
                }
            }
            if ui
                .add_sized(
                    [220.0, 40.0],
                    egui::Button::new(i18n::tr("▨ Aplicar em todos os módulos")),
                )
                .clicked()
            {
                let ids = self.modules.iter().map(|m| m.id).collect::<Vec<_>>();
                let mat = self.panel_material.clone();
                for id in ids {
                    self.apply_material_to(Selection::Module(id), &mat);
                }
                self.notice =
                    "Acabamento aplicado ao componente escolhido em todos os módulos.".into();
            }
        });
        ui.horizontal(|ui| {
            ui.selectable_value(
                &mut self.decor_material_view,
                false,
                format!("Módulos · {} materiais", self.materials.len()),
            );
            ui.selectable_value(
                &mut self.decor_material_view,
                true,
                format!("Decoração · {} materiais", self.decor_materials.len()),
            );
        });
        ui.separator();
        let list = if self.decor_material_view {
            &mut self.decor_materials
        } else {
            &mut self.materials
        };
        material_editor(ui, list, &mut self.material_name, &mut self.material_price);
    }

    fn method_page(&mut self, ui: &mut egui::Ui) {
        fabrication::editor(self, ui);
    }
    fn budget_page(&mut self, ui: &mut egui::Ui) {
        ui.heading(i18n::tr("Orçamento configurável"));
        production::edge_editor(self, ui);
        if ui
            .button(i18n::tr("Plano de corte / Exportar peças"))
            .clicked()
        {
            self.page = Page::Cut;
        }
        ui.label(i18n::tr(
            "Ajuste mão de obra, perdas, ferragens, impostos e margem conforme sua marcenaria.",
        ));
        ui.horizontal_wrapped(|ui| {
            ui.label(i18n::tr("Margem / multiplicador"));
            ui.add(egui::Slider::new(&mut self.sale_markup, 1.0..=3.0).suffix(" ×"));
            ui.label(i18n::tr("Mão de obra %"));
            ui.add(
                egui::DragValue::new(&mut self.budget_labor)
                    .clamp_range(0.0..=300.0)
                    .suffix("%"),
            );
            ui.label(i18n::tr("Perda %"));
            ui.add(
                egui::DragValue::new(&mut self.budget_waste)
                    .clamp_range(0.0..=100.0)
                    .suffix("%"),
            );
            ui.label(i18n::tr("Ferragens por módulo R$"));
            ui.add(egui::DragValue::new(&mut self.budget_hardware).clamp_range(0.0..=10000.0));
            ui.label(i18n::tr("Impostos %"));
            ui.add(
                egui::DragValue::new(&mut self.budget_tax)
                    .clamp_range(0.0..=100.0)
                    .suffix("%"),
            );
        });
        ui.separator();
        let parts = self.parts();
        let mut materials_cost = 0.0_f32;
        egui::Grid::new("budget_table")
            .striped(true)
            .show(ui, |ui| {
                ui.strong(i18n::tr("Material"));
                ui.strong(i18n::tr("Área estimada"));
                ui.strong(i18n::tr("Custo"));
                ui.strong(i18n::tr("Venda"));
                ui.end_row();
                for mat in &self.materials {
                    let area = parts
                        .iter()
                        .filter(|p| {
                            p.material == mat.name
                                || p.material == format!("{} {} mm", mat.name, p.thickness_mm)
                        })
                        .map(|p| {
                            p.length_mm as f32 * p.width_mm as f32 * p.quantity as f32 / 1_000_000.0
                        })
                        .sum::<f32>();
                    if area > 0.0 {
                        let cost = area * mat.price_m2;
                        materials_cost += cost;
                        ui.label(&mat.name);
                        ui.label(format!("{area:.2} m²"));
                        ui.label(format!("R$ {cost:.2}"));
                        ui.label(format!("R$ {:.2}", cost * self.sale_markup));
                        ui.end_row();
                    }
                }
            });
        let waste = materials_cost * self.budget_waste / 100.0;
        let labor = (materials_cost + waste) * self.budget_labor / 100.0;
        let hardware = self.modules.len() as f32 * self.budget_hardware;
        let edge_cost = production::edge_cost(&parts, &self.production);
        ui.label(format!("Fita de borda: R$ {edge_cost:.2}"));
        let subtotal = materials_cost + waste + labor + hardware + edge_cost;
        let taxes = subtotal * self.budget_tax / 100.0;
        let cost = subtotal + taxes;
        ui.separator();
        ui.label(format!("Materiais R$ {materials_cost:.2} + perdas R$ {waste:.2} + mão de obra R$ {labor:.2} + ferragens R$ {hardware:.2} + impostos R$ {taxes:.2}"));
        ui.heading(format!(
            "Custo: R$ {cost:.2}  ·  Preço sugerido: R$ {:.2}",
            cost * self.sale_markup
        ));
        ui.small(i18n::tr("Orçamento considera somente marcenaria e materiais de módulos/painéis. Decoração e acabamentos de ambiente permanecem separados."));
    }
}

impl eframe::App for FurnitureApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if let Ok(path) = std::env::var("MAR_CAPTURE_UI") {
            let frame = ctx.data_mut(|d| {
                let v = d.get_temp_mut_or_default::<u32>(egui::Id::new("capture_frame"));
                *v += 1;
                *v
            });
            if frame == 1 {
                self.preferences_loaded = true;
                self.language = std::env::var("MAR_CAPTURE_LANG")
                    .ok()
                    .and_then(|s| s.parse().ok())
                    .unwrap_or(0)
                    .min(2);
                self.page = match std::env::var("MAR_CAPTURE_PAGE").as_deref() {
                    Ok("scene") => Page::Scene,
                    Ok("layers") => {
                        self.show_layers = true;
                        Page::Scene
                    }
                    Ok("fronts") => {
                        self.inspector = InspectorTab::Properties;
                        Page::Scene
                    }
                    Ok("preferences") => Page::Preferences,
                    Ok("builder") => {
                        self.custom_drawers = 2;
                        self.custom_drawer_height = 320;
                        self.custom_shelves = 2;
                        self.custom_top = 2;
                        Page::ModuleBuilder
                    }
                    Ok("panels") => Page::PanelDesigner,
                    Ok("finishes") => {
                        self.finish_designer.profile = 2;
                        Page::FinishDesigner
                    }
                    Ok("geometry") => {
                        self.geometry.points = vec![
                            P2::new(0., 0.),
                            P2::new(1., 0.),
                            P2::new(1., 0.5),
                            P2::new(0.5, 0.5),
                            P2::new(0.5, 1.),
                            P2::new(0., 1.),
                        ];
                        self.geometry.closed = true;
                        Page::GeometryDesigner
                    }
                    Ok("method") => Page::Method,
                    Ok("materials") => Page::Materials,
                    Ok("plan") => Page::Plan,
                    Ok("budget") => Page::Budget,
                    Ok("cut") => Page::Cut,
                    _ => Page::Documentation,
                };
            }
            if frame == 4 {
                ctx.send_viewport_cmd(egui::ViewportCommand::Screenshot);
            }
            let shot = ctx.input(|i| {
                i.events.iter().find_map(|e| {
                    if let egui::Event::Screenshot { image, .. } = e {
                        Some(image.clone())
                    } else {
                        None
                    }
                })
            });
            if let Some(image) = shot {
                let rgba: Vec<u8> = image.pixels.iter().flat_map(|p| p.to_array()).collect();
                image::save_buffer(
                    &path,
                    &rgba,
                    image.size[0] as u32,
                    image.size[1] as u32,
                    image::ColorType::Rgba8,
                )
                .expect("captura de interface");
                ctx.send_viewport_cmd(egui::ViewportCommand::Close);
            }
            ctx.request_repaint();
        }
        if !self.preferences_loaded {
            self.load_preferences();
        }
        i18n::set(self.language);
        ctx.set_visuals(egui::Visuals::light());
        let before_edit = self.project_snapshot();
        let before_history = self.history_signature.clone();
        commands::handle(self, ctx);
        if !ctx.wants_keyboard_input() && !ctx.input(|i| i.modifiers.alt) {
            if ctx.input(|i| i.modifiers.ctrl && i.key_pressed(self.shortcut_undo)) {
                self.undo_action();
            } else if ctx.input(|i| !i.modifiers.ctrl && i.key_pressed(self.shortcut_select)) {
                self.set_tool(Tool::Select);
            } else if ctx.input(|i| !i.modifiers.ctrl && i.key_pressed(self.shortcut_wall)) {
                self.set_tool(Tool::WallChain);
            } else if ctx.input(|i| !i.modifiers.ctrl && i.key_pressed(self.shortcut_copy)) {
                self.material_source = None;
                self.set_tool(Tool::CopyMaterial);
            } else if ctx.input(|i| !i.modifiers.ctrl && i.key_pressed(self.shortcut_paint)) {
                self.set_tool(Tool::PaintMaterial);
            }
        }
        if !ctx.wants_keyboard_input() && ctx.input(|i| i.key_pressed(egui::Key::Delete)) {
            self.delete_selected();
        }
        if ctx.input(|i| i.key_pressed(egui::Key::Escape)) {
            self.cancel_current();
        }
        self.top_bar(ctx);
        self.layers_editor(ctx);
        if self.editing.array_open {
            self.array_editor(ctx);
        }
        egui::TopBottomPanel::bottom("status")
            .exact_height(34.0)
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    ui.selectable_value(&mut self.page, Page::Plan, i18n::tr("Planta"));
                    ui.selectable_value(&mut self.page, Page::Scene, i18n::tr("Ambiente 3D"));
                    ui.selectable_value(&mut self.page, Page::Parts, i18n::tr("Peças"));
                    if self.show_command_hints {
                        ui.separator();
                        ui.label(
                            egui::RichText::new(self.command_hint())
                                .size(11.0)
                                .color(Color32::from_gray(115)),
                        );
                    }
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui
                            .small_button(if self.show_command_hints {
                                "◉"
                            } else {
                                "◎"
                            })
                            .on_hover_text(i18n::tr("Mostrar ou ocultar as dicas de comando"))
                            .clicked()
                        {
                            self.show_command_hints = !self.show_command_hints;
                            self.save_preferences();
                        }
                        ui.label(if let Some(s) = self.selected {
                            format!("Selecionado: {s:?}")
                        } else {
                            format!(
                                "{} módulos · {} paredes",
                                self.modules.len(),
                                self.walls.len()
                            )
                        });
                    });
                });
            });
        if matches!(self.page, Page::Plan | Page::Scene) {
            if self.show_catalog {
                self.catalog_panel(ctx);
            }
            if self.show_inspector {
                self.inspector_panel(ctx);
            }
        }
        egui::CentralPanel::default()
            .frame(
                egui::Frame::default()
                    .fill(Color32::from_rgb(239, 241, 243))
                    .inner_margin(egui::Margin::same(10.0)),
            )
            .show(ctx, |ui| match self.page {
                Page::GeometryDesigner => self.geometry_designer(ui),
                Page::FinishDesigner => self.finish_designer(ui),
                Page::PanelDesigner => self.panel_designer(ui),
                Page::Plan => self.plan_page(ui, ctx),
                Page::Scene => self.scene_page(ui, ctx),
                Page::Parts => self.parts_page(ui),
                Page::Materials => self.materials_page(ui),
                Page::Method => self.method_page(ui),
                Page::Budget => self.budget_page(ui),
                Page::OpeningLibrary => self.opening_library_page(ui),
                Page::Documentation => self.documentation_page(ui),
                Page::ModuleBuilder => self.module_builder_page(ui),
                Page::Preferences => self.preferences_page(ui),
                Page::Automation => automation::editor(self, ui),
                Page::Cut => production::editor(self, ui),
            });
        if self.history_signature == before_history {
            self.follow_group_translation(&before_edit);
            self.enforce_layer_locks(&before_edit);
            self.enforce_collisions(&before_edit);
        }
        if !ctx.input(|i| i.pointer.button_down(egui::PointerButton::Primary)) {
            self.track_history();
        }
    }
}

fn mar_escape(s: &str) -> String {
    s.replace('%', "%25")
        .replace('|', "%7C")
        .replace('\n', "%0A")
        .replace('\r', "%0D")
}
fn mar_unescape(s: &str) -> String {
    s.replace("%0D", "\r")
        .replace("%0A", "\n")
        .replace("%7C", "|")
        .replace("%25", "%")
}
fn project_to_mar(app: &FurnitureApp) -> String {
    let mut out = String::from("MARCENARIA_LIVRE|1\n");
    let mut row = |fields: Vec<String>| {
        out.push_str(&fields.join("|"));
        out.push('\n');
    };
    row(vec!["PROJECT_ID".into(), app.project_id.to_string()]);
    row(vec![
        "ROOM".into(),
        app.room[0].to_string(),
        app.room[1].to_string(),
        app.room[2].to_string(),
    ]);
    row(vec!["FLOOR".into(), mar_escape(&app.floor_texture)]);
    row(vec![
        "ANCHOR".into(),
        app.anchor_wall.unwrap_or(0).to_string(),
    ]);
    row(vec![
        "SETTINGS".into(),
        app.method_side.to_string(),
        app.method_top.to_string(),
        app.method_back.to_string(),
        app.method_gap.to_string(),
        mar_escape(&app.standard_edge),
        mar_escape(&app.back_mount),
        app.sale_markup.to_string(),
        app.budget_labor.to_string(),
        app.budget_waste.to_string(),
        app.budget_hardware.to_string(),
        app.budget_tax.to_string(),
    ]);
    row(vec![
        "SHEET".into(),
        mar_escape(&app.sheet_title),
        mar_escape(&app.sheet_client),
        mar_escape(&app.sheet_author),
        app.sheet_landscape.to_string(),
        app.sheet_dimensions.to_string(),
        app.dimension_text_size.to_string(),
    ]);
    for d in &app.sheet_options.dimensions {
        row(vec![
            "SHEET_DIM".into(),
            d.view.to_string(),
            d.a.x.to_string(),
            d.a.y.to_string(),
            d.b.x.to_string(),
            d.b.y.to_string(),
            d.offset.to_string(),
        ]);
    }
    row(app.production.fields());
    row(app.automation.fields());
    row(app.fabrication.fields());
    row(vec![
        "SHEET_OPTIONS".into(),
        mar_escape(&app.sheet_options.revision),
        mar_escape(&app.sheet_options.notes),
        app.sheet_options.table.to_string(),
        app.sheet_options.color.to_string(),
        app.sheet_options.line_width.to_string(),
        mar_escape(&app.sheet_options.number),
    ]);
    for v in &app.sheet_views {
        row(vec![
            "VIEW".into(),
            format!("{:?}", v.kind),
            v.x.to_string(),
            v.y.to_string(),
            v.width.to_string(),
            v.height.to_string(),
            v.offset_x.to_string(),
            v.offset_y.to_string(),
        ]);
    }
    for w in &app.walls {
        row(vec![
            "WALL".into(),
            w.id.to_string(),
            w.start.x.to_string(),
            w.start.z.to_string(),
            w.end.x.to_string(),
            w.end.z.to_string(),
            w.thickness_mm.to_string(),
            w.height_mm.to_string(),
            mar_escape(&w.material),
            w.color.r().to_string(),
            w.color.g().to_string(),
            w.color.b().to_string(),
        ]);
    }
    for o in &app.openings {
        row(vec![
            "OPENING".into(),
            o.id.to_string(),
            o.wall_id.to_string(),
            if o.kind == OpeningKind::Door {
                "Door"
            } else {
                "Window"
            }
            .into(),
            o.center_mm.to_string(),
            o.width_mm.to_string(),
            o.height_mm.to_string(),
            o.sill_mm.to_string(),
            mar_escape(&o.style),
            mar_escape(&o.material),
        ]);
    }
    for m in &app.modules {
        row(vec![
            "MODULE".into(),
            m.id.to_string(),
            mar_escape(&m.name),
            format!("{:?}", m.kind),
            m.x_mm.to_string(),
            m.y_mm.to_string(),
            m.z_mm.to_string(),
            m.rotation_deg.to_string(),
            m.width_mm.to_string(),
            m.height_mm.to_string(),
            m.depth_mm.to_string(),
            m.thickness_mm.to_string(),
            m.door_count.to_string(),
            m.shelf_count.to_string(),
            m.drawer_count.to_string(),
            mar_escape(&m.material),
            mar_escape(&m.door_material),
            format!("{:?}", m.grain),
            format!("{:?}", m.door_style),
            m.door_styles
                .iter()
                .map(|s| format!("{:?}", s))
                .collect::<Vec<_>>()
                .join(","),
            m.door_open.to_string(),
            m.divider_count.to_string(),
            fronts::encode(&m.handles),
            m.top_mode.to_string(),
            m.internal_drawer_height.to_string(),
        ]);
    }
    for b in &app.panels {
        row(vec![
            "PANEL".into(),
            b.id.to_string(),
            mar_escape(&b.name),
            b.x_mm.to_string(),
            b.y_mm.to_string(),
            b.z_mm.to_string(),
            b.width_mm.to_string(),
            b.height_mm.to_string(),
            b.thickness_mm.to_string(),
            mar_escape(&b.material),
            format!("{:?}", b.grain),
            b.rotation_deg.to_string(),
            b.horizontal.to_string(),
        ]);
    }
    for g in &app.gesso {
        row(vec![
            "GESSO".into(),
            g.id.to_string(),
            g.x_mm.to_string(),
            g.z_mm.to_string(),
            g.width_mm.to_string(),
            g.depth_mm.to_string(),
            g.drop_mm.to_string(),
            g.thickness_mm.to_string(),
        ]);
    }
    for d in &app.decor {
        row(vec![
            "DECOR".into(),
            d.id.to_string(),
            mar_escape(&d.name),
            mar_escape(&d.material),
            d.x_mm.to_string(),
            d.y_mm.to_string(),
            d.z_mm.to_string(),
            d.width_mm.to_string(),
            d.height_mm.to_string(),
            d.depth_mm.to_string(),
            d.color.r().to_string(),
            d.color.g().to_string(),
            d.color.b().to_string(),
            d.rotation_deg.to_string(),
            d.outline
                .iter()
                .map(|p| format!("{},{}", p.x, p.z))
                .collect::<Vec<_>>()
                .join(";"),
        ]);
    }
    for group in &app.groups {
        row(vec![
            "GROUP".into(),
            group
                .iter()
                .map(|id| id.to_string())
                .collect::<Vec<_>>()
                .join(","),
        ]);
    }
    for i in 0..7 {
        row(vec![
            "LAYER".into(),
            i.to_string(),
            app.layers.visible[i].to_string(),
            app.layers.locked[i].to_string(),
        ]);
    }
    for id in &app.hidden_ids {
        row(vec!["HIDE".into(), id.to_string()]);
    }
    for m in &app.materials {
        row(vec![
            "MATERIAL".into(),
            mar_escape(&m.name),
            m.price_m2.to_string(),
            m.has_grain.to_string(),
            m.gloss.to_string(),
            m.reflect.to_string(),
            m.color.r().to_string(),
            m.color.g().to_string(),
            m.color.b().to_string(),
            mar_escape(&m.texture_path),
        ]);
    }
    for m in &app.decor_materials {
        row(vec![
            "DECMATERIAL".into(),
            mar_escape(&m.name),
            m.price_m2.to_string(),
            m.has_grain.to_string(),
            m.gloss.to_string(),
            m.reflect.to_string(),
            m.color.r().to_string(),
            m.color.g().to_string(),
            m.color.b().to_string(),
            mar_escape(&m.texture_path),
        ]);
    }
    out
}
fn mar_num<T: std::str::FromStr>(f: &[&str], i: usize) -> Result<T, String> {
    f.get(i)
        .ok_or_else(|| format!("Campo {} ausente", i + 1))?
        .parse()
        .map_err(|_| format!("Valor inválido no campo {}", i + 1))
}
fn mar_text(f: &[&str], i: usize) -> Result<String, String> {
    f.get(i)
        .map(|s| mar_unescape(s))
        .ok_or_else(|| format!("Campo {} ausente", i + 1))
}
fn mar_material(f: &[&str]) -> Result<MaterialData, String> {
    let color = Color32::from_rgb(mar_num(f, 6)?, mar_num(f, 7)?, mar_num(f, 8)?);
    Ok(MaterialData {
        texture_path: f.get(9).map(|s| mar_unescape(s)).unwrap_or_default(),
        name: mar_text(f, 1)?,
        price_m2: mar_num(f, 2)?,
        has_grain: mar_num::<bool>(f, 3)?,
        gloss: mar_num(f, 4)?,
        reflect: mar_num(f, 5)?,
        color,
    })
}
fn parse_mar_project(text: &str) -> Result<ProjectFile, String> {
    let mut lines = text.lines();
    if lines.next() != Some("MARCENARIA_LIVRE|1") {
        return Err("Formato .mar não reconhecido ou versão incompatível".into());
    }
    let mut p = ProjectFile {
        room: [4200, 2700, 3200],
        anchor_wall: None,
        walls: vec![],
        openings: vec![],
        modules: vec![],
        panels: vec![],
        gesso: vec![],
        decor: vec![],
        hidden_ids: vec![],
        groups: vec![],
        layers: layers::Layers::default(),
        project_id: project_identity(),
        floor_texture: "Cimento claro".into(),
        materials: vec![],
        decor_materials: vec![],
        production: production::Settings::default(),
        automation: automation::Settings::default(),
        fabrication: fabrication::Settings::default(),
        sheet_options: documentation::Options::default(),
        sheet_title: "Projeto de marcenaria".into(),
        sheet_client: String::new(),
        sheet_author: String::new(),
        sheet_views: vec![],
        sheet_dimensions: true,
        dimension_text_size: 2.6,
        sheet_landscape: true,
        method_side: 18,
        method_top: 18,
        method_back: 6,
        method_gap: 3,
        standard_edge: "PVC 1 mm".into(),
        back_mount: "Encaixado".into(),
        sale_markup: 1.35,
        budget_labor: 20.0,
        budget_waste: 10.0,
        budget_hardware: 45.0,
        budget_tax: 0.0,
    };
    for line in lines.filter(|l| !l.is_empty()) {
        let f: Vec<&str> = line.split('|').collect();
        match f.first().copied().unwrap_or("") {
            "PROJECT_ID" => p.project_id = mar_num(&f, 1)?,
            "ROOM" => p.room = [mar_num(&f, 1)?, mar_num(&f, 2)?, mar_num(&f, 3)?],
            "ANCHOR" => {
                let id = mar_num::<u32>(&f, 1)?;
                p.anchor_wall = if id == 0 { None } else { Some(id) }
            }
            "FLOOR" => p.floor_texture = mar_text(&f, 1)?,
            "SETTINGS" => {
                p.method_side = mar_num(&f, 1)?;
                p.method_top = mar_num(&f, 2)?;
                p.method_back = mar_num(&f, 3)?;
                p.method_gap = mar_num(&f, 4)?;
                p.standard_edge = mar_text(&f, 5)?;
                p.back_mount = mar_text(&f, 6)?;
                p.sale_markup = mar_num(&f, 7)?;
                p.budget_labor = mar_num(&f, 8)?;
                p.budget_waste = mar_num(&f, 9)?;
                p.budget_hardware = mar_num(&f, 10)?;
                p.budget_tax = mar_num(&f, 11)?
            }
            "SHEET" => {
                p.sheet_title = mar_text(&f, 1)?;
                p.sheet_client = mar_text(&f, 2)?;
                p.sheet_author = mar_text(&f, 3)?;
                p.sheet_landscape = mar_num(&f, 4)?;
                p.sheet_dimensions = mar_num(&f, 5)?;
                p.dimension_text_size = mar_num(&f, 6)?
            }
            "PRODUCTION" => {
                p.production = production::Settings::parse(&f)?;
            }
            "AUTOMATION" => {
                p.automation = automation::Settings::parse(&f)?;
            }
            "FABRICATION" => {
                p.fabrication = fabrication::Settings::parse(&f)?;
            }
            "SHEET_DIM" => p.sheet_options.dimensions.push(documentation::Dimension {
                view: mar_num(&f, 1)?,
                a: Pos2::new(mar_num(&f, 2)?, mar_num(&f, 3)?),
                b: Pos2::new(mar_num(&f, 4)?, mar_num(&f, 5)?),
                offset: mar_num(&f, 6)?,
            }),
            "SHEET_OPTIONS" => {
                p.sheet_options.revision = mar_text(&f, 1)?;
                p.sheet_options.notes = mar_text(&f, 2)?;
                p.sheet_options.table = mar_num(&f, 3)?;
                p.sheet_options.color = mar_num(&f, 4)?;
                p.sheet_options.line_width = mar_num(&f, 5)?;
                p.sheet_options.number = mar_text(&f, 6)?;
            }
            "VIEW" => p.sheet_views.push(SheetViewport {
                offset_x: f.get(6).and_then(|v| v.parse().ok()).unwrap_or(0.0),
                offset_y: f.get(7).and_then(|v| v.parse().ok()).unwrap_or(0.0),
                kind: match f.get(1).copied() {
                    Some("Plan") => ViewKind::Plan,
                    Some("ThreeD") => ViewKind::ThreeD,
                    Some("Front") => ViewKind::Front,
                    Some("Side") => ViewKind::Side,
                    _ => return Err("Tipo de vista inválido".into()),
                },
                x: mar_num(&f, 2)?,
                y: mar_num(&f, 3)?,
                width: mar_num(&f, 4)?,
                height: mar_num(&f, 5)?,
            }),
            "WALL" => p.walls.push(Wall {
                material: f
                    .get(8)
                    .map(|v| mar_unescape(v))
                    .unwrap_or_else(|| "Pintura branca".into()),
                color: Color32::from_rgb(
                    f.get(9).and_then(|v| v.parse().ok()).unwrap_or(220),
                    f.get(10).and_then(|v| v.parse().ok()).unwrap_or(221),
                    f.get(11).and_then(|v| v.parse().ok()).unwrap_or(218),
                ),
                id: mar_num(&f, 1)?,
                start: P2::new(mar_num(&f, 2)?, mar_num(&f, 3)?),
                end: P2::new(mar_num(&f, 4)?, mar_num(&f, 5)?),
                thickness_mm: mar_num(&f, 6)?,
                height_mm: mar_num(&f, 7)?,
            }),
            "OPENING" => p.openings.push(Opening {
                id: mar_num(&f, 1)?,
                wall_id: mar_num(&f, 2)?,
                kind: match f.get(3).copied() {
                    Some("Door") => OpeningKind::Door,
                    Some("Window") => OpeningKind::Window,
                    _ => return Err("Tipo de abertura inválido".into()),
                },
                center_mm: mar_num(&f, 4)?,
                width_mm: mar_num(&f, 5)?,
                height_mm: mar_num(&f, 6)?,
                sill_mm: mar_num(&f, 7)?,
                style: mar_text(&f, 8)?,
                material: mar_text(&f, 9)?,
            }),
            "MODULE" => {
                let kind = match f.get(3).copied() {
                    Some("Base") => ModuleKind::Base,
                    Some("Wall") => ModuleKind::Wall,
                    Some("Tall") => ModuleKind::Tall,
                    Some("Drawer") => ModuleKind::Drawer,
                    Some("OpenShelf") => ModuleKind::OpenShelf,
                    Some("Custom") => ModuleKind::Custom,
                    _ => return Err("Tipo de módulo inválido".into()),
                };
                let grain = match f.get(17).copied() {
                    Some("Length") => Grain::Length,
                    Some("Width") => Grain::Width,
                    _ => return Err("Sentido do veio inválido".into()),
                };
                let parse_style = |v: Option<&&str>| match v.copied() {
                    Some("GlassHorizontal") => Some(DoorStyle::GlassHorizontal),
                    Some("GlassVertical") => Some(DoorStyle::GlassVertical),
                    Some("Plain") => Some(DoorStyle::Plain),
                    Some("Provincial") => Some(DoorStyle::Provincial),
                    Some("Horizontal") => Some(DoorStyle::Horizontal),
                    Some("Vertical") => Some(DoorStyle::Vertical),
                    Some("Cava") => Some(DoorStyle::Cava),
                    Some("Glass") => Some(DoorStyle::Glass),
                    Some("Aluminum") => Some(DoorStyle::Aluminum),
                    _ => None,
                };
                let door_style = parse_style(f.get(18)).ok_or("Estilo de porta inválido")?;
                let door_styles = if f.get(19).copied().unwrap_or("").is_empty() {
                    vec![]
                } else {
                    f[19]
                        .split(',')
                        .map(|s| {
                            parse_style(Some(&s)).ok_or("Estilo de porta inválido".to_string())
                        })
                        .collect::<Result<Vec<_>, _>>()?
                };
                p.modules.push(Module {
                    top_mode: f.get(23).and_then(|s| s.parse().ok()).unwrap_or(0),
                    internal_drawer_height: f.get(24).and_then(|s| s.parse().ok()).unwrap_or(400),
                    handles: fronts::decode(f.get(22).copied().unwrap_or("")),
                    divider_count: f.get(21).and_then(|v| v.parse().ok()).unwrap_or(0),
                    id: mar_num(&f, 1)?,
                    name: mar_text(&f, 2)?,
                    kind,
                    x_mm: mar_num(&f, 4)?,
                    y_mm: mar_num(&f, 5)?,
                    z_mm: mar_num(&f, 6)?,
                    rotation_deg: mar_num(&f, 7)?,
                    width_mm: mar_num(&f, 8)?,
                    height_mm: mar_num(&f, 9)?,
                    depth_mm: mar_num(&f, 10)?,
                    thickness_mm: mar_num(&f, 11)?,
                    door_count: mar_num(&f, 12)?,
                    shelf_count: mar_num(&f, 13)?,
                    drawer_count: mar_num(&f, 14)?,
                    material: mar_text(&f, 15)?,
                    door_material: mar_text(&f, 16)?,
                    grain,
                    door_style,
                    door_styles,
                    door_open: mar_num(&f, 20)?,
                });
            }
            "PANEL" => {
                let grain = match f.get(10).copied() {
                    Some("Length") => Grain::Length,
                    Some("Width") => Grain::Width,
                    _ => return Err("Veio do painel inválido".into()),
                };
                p.panels.push(WoodPanel {
                    rotation_deg: f.get(11).and_then(|v| v.parse().ok()).unwrap_or(0.0),
                    horizontal: f.get(12).and_then(|v| v.parse().ok()).unwrap_or(false),
                    id: mar_num(&f, 1)?,
                    name: mar_text(&f, 2)?,
                    x_mm: mar_num(&f, 3)?,
                    y_mm: mar_num(&f, 4)?,
                    z_mm: mar_num(&f, 5)?,
                    width_mm: mar_num(&f, 6)?,
                    height_mm: mar_num(&f, 7)?,
                    thickness_mm: mar_num(&f, 8)?,
                    material: mar_text(&f, 9)?,
                    grain,
                });
            }
            "GESSO" => p.gesso.push(GessoBlock {
                id: mar_num(&f, 1)?,
                x_mm: mar_num(&f, 2)?,
                z_mm: mar_num(&f, 3)?,
                width_mm: mar_num(&f, 4)?,
                depth_mm: mar_num(&f, 5)?,
                drop_mm: mar_num(&f, 6)?,
                thickness_mm: mar_num(&f, 7)?,
            }),
            "DECOR" => p.decor.push(DecorItem {
                outline: f
                    .get(14)
                    .map(|s| {
                        s.split(';')
                            .filter_map(|v| {
                                let (x, z) = v.split_once(',')?;
                                Some(P2::new(x.parse().ok()?, z.parse().ok()?))
                            })
                            .collect()
                    })
                    .unwrap_or_default(),
                rotation_deg: f.get(13).and_then(|v| v.parse().ok()).unwrap_or(0.),
                id: mar_num(&f, 1)?,
                name: mar_text(&f, 2)?,
                material: mar_text(&f, 3)?,
                x_mm: mar_num(&f, 4)?,
                y_mm: mar_num(&f, 5)?,
                z_mm: mar_num(&f, 6)?,
                width_mm: mar_num(&f, 7)?,
                height_mm: mar_num(&f, 8)?,
                depth_mm: mar_num(&f, 9)?,
                color: Color32::from_rgb(mar_num(&f, 10)?, mar_num(&f, 11)?, mar_num(&f, 12)?),
            }),
            "GROUP" => {
                let ids = f
                    .get(1)
                    .unwrap_or(&"")
                    .split(',')
                    .filter_map(|s| s.parse::<u32>().ok())
                    .collect::<Vec<_>>();
                if ids.len() > 1 {
                    p.groups.push(ids);
                }
            }
            "LAYER" => {
                let i: usize = mar_num(&f, 1)?;
                if i < 7 {
                    p.layers.visible[i] = mar_num(&f, 2)?;
                    p.layers.locked[i] = mar_num(&f, 3)?;
                }
            }
            "HIDE" => p.hidden_ids.push(mar_num(&f, 1)?),
            "MATERIAL" => p.materials.push(mar_material(&f)?),
            "DECMATERIAL" => p.decor_materials.push(mar_material(&f)?),
            _ => {}
        }
    }
    if !text.lines().any(|line| line.starts_with("PROJECT_ID|")) {
        p.project_id = text.bytes().fold(14695981039346656037u64, |h, b| {
            (h ^ b as u64).wrapping_mul(1099511628211)
        });
    }
    if p.room.iter().any(|v| *v == 0) {
        return Err("O arquivo contém medidas inválidas de ambiente".into());
    }
    if p.materials.is_empty() {
        p.materials = default_materials();
    }
    if p.decor_materials.is_empty() {
        p.decor_materials = decorative_materials();
    }
    if p.sheet_views.is_empty() {
        p.sheet_views.push(SheetViewport {
            offset_x: 0.0,
            offset_y: 0.0,
            kind: ViewKind::Plan,
            x: 16.0,
            y: 24.0,
            width: 250.0,
            height: 140.0,
        });
    }
    Ok(p)
}
fn snap_module_to_wall(m: &mut Module, walls: &[Wall], room: [u32; 3]) {
    snap_module_to_wall_target(m, walls, room, None)
}
fn snap_module_to_wall_target(
    m: &mut Module,
    walls: &[Wall],
    room: [u32; 3],
    target_wall: Option<u32>,
) {
    snap_module_to_wall_target_with_limit(m, walls, room, target_wall, 900.0)
}
fn snap_module_to_wall_target_with_limit(
    m: &mut Module,
    walls: &[Wall],
    room: [u32; 3],
    target_wall: Option<u32>,
    radius: f32,
) {
    let corners = module_corners(m);
    let center = P2::new(
        corners.iter().map(|p| p.x).sum::<f32>() / 4.0,
        corners.iter().map(|p| p.z).sum::<f32>() / 4.0,
    );
    let candidate = walls
        .iter()
        .filter(|w| target_wall.map(|id| w.id == id).unwrap_or(true))
        .map(|w| (w, project_to_wall(center, w)))
        .min_by(|a, b| a.1 .1.total_cmp(&b.1 .1));
    if let Some((w, (offset, dist))) = candidate {
        if target_wall.is_none()
            && dist > radius + m.depth_mm as f32 / 2.0 + w.thickness_mm as f32 / 2.0
        {
            return;
        }
        let len = w.start.distance(w.end);
        if len < m.width_mm as f32 || len < 1.0 {
            return;
        }
        let ux = (w.end.x - w.start.x) / len;
        let uz = (w.end.z - w.start.z) / len;
        let mut nx = -uz;
        let mut nz = ux;
        let mx = (w.start.x + w.end.x) / 2.0;
        let mz = (w.start.z + w.end.z) / 2.0;
        if nx * (room[0] as f32 / 2.0 - mx) + nz * (room[2] as f32 / 2.0 - mz) < 0.0 {
            nx = -nx;
            nz = -nz;
        }
        let half = m.width_mm as f32 / 2.0;
        let along = offset.clamp(half, len - half);
        let back = P2::new(
            w.start.x + ux * along + nx * w.thickness_mm as f32 / 2.0,
            w.start.z + uz * along + nz * w.thickness_mm as f32 / 2.0,
        );
        let lx = -nz;
        let lz = nx;
        m.x_mm = (back.x - lx * half + nx * m.depth_mm as f32)
            .round()
            .max(0.0) as u32;
        m.z_mm = (back.z - lz * half + nz * m.depth_mm as f32)
            .round()
            .max(0.0) as u32;
        m.rotation_deg = lz.atan2(lx).to_degrees();
    }
}
fn clamp_module_to_room(m: &mut Module, room: [u32; 3]) {
    let corners = module_corners(m);
    let min_x = corners.iter().map(|p| p.x).fold(f32::INFINITY, f32::min);
    let max_x = corners
        .iter()
        .map(|p| p.x)
        .fold(f32::NEG_INFINITY, f32::max);
    let min_z = corners.iter().map(|p| p.z).fold(f32::INFINITY, f32::min);
    let max_z = corners
        .iter()
        .map(|p| p.z)
        .fold(f32::NEG_INFINITY, f32::max);
    let dx = if min_x < 0.0 {
        -min_x
    } else if max_x > room[0] as f32 {
        room[0] as f32 - max_x
    } else {
        0.0
    };
    let dz = if min_z < 0.0 {
        -min_z
    } else if max_z > room[2] as f32 {
        room[2] as f32 - max_z
    } else {
        0.0
    };
    m.x_mm = (m.x_mm as f32 + dx).round().max(0.0) as u32;
    m.z_mm = (m.z_mm as f32 + dz).round().max(0.0) as u32;
}
fn module_kind_label(k: ModuleKind) -> &'static str {
    match k {
        ModuleKind::Base => "Inferior",
        ModuleKind::Wall => "Aéreo",
        ModuleKind::Tall => "Torre",
        ModuleKind::Drawer => "Gaveteiro",
        ModuleKind::OpenShelf => "Nicho aberto",
        ModuleKind::Custom => "Personalizado",
    }
}

fn preset(
    name: &'static str,
    kind: ModuleKind,
    width: u32,
    height: u32,
    depth: u32,
    y: u32,
    doors: u32,
    shelves: u32,
    drawers: u32,
) -> Preset {
    Preset {
        name,
        kind,
        width,
        height,
        depth,
        y,
        doors,
        shelves,
        drawers,
    }
}
fn make_module(id: u32, p: Preset, x: u32, z: u32) -> Module {
    Module {
        top_mode: if p.name.contains("sem topo") { 1 } else { 0 },
        internal_drawer_height: 400,
        handles: vec![],
        divider_count: 0,
        id,
        name: p.name.into(),
        kind: p.kind,
        x_mm: x,
        y_mm: p.y,
        z_mm: z,
        rotation_deg: 0.0,
        width_mm: p.width,
        height_mm: p.height,
        depth_mm: p.depth,
        thickness_mm: 18,
        door_count: p.doors,
        shelf_count: p.shelves,
        drawer_count: p.drawers,
        material: "Carvalho claro".into(),
        door_material: "Carvalho claro".into(),
        grain: Grain::Length,
        door_style: DoorStyle::Plain,
        door_styles: vec![DoorStyle::Plain; p.doors as usize],
        door_open: false,
    }
}
fn presets_for(tab: CatalogTab) -> Vec<Preset> {
    let mut items = base_presets_for(tab);
    items.extend(extra_presets(tab));
    items
}
fn base_presets_for(tab: CatalogTab) -> Vec<Preset> {
    match tab {
        CatalogTab::Kitchen => vec![
            preset("Balcão 600", ModuleKind::Base, 600, 720, 550, 0, 2, 1, 0),
            preset("Balcão 800", ModuleKind::Base, 800, 720, 550, 0, 2, 1, 0),
            preset("Balcão 900", ModuleKind::Base, 900, 720, 550, 0, 2, 1, 0),
            preset("Balcão 1200", ModuleKind::Base, 1200, 720, 550, 0, 2, 1, 0),
            preset("Aéreo 600", ModuleKind::Wall, 600, 720, 350, 1320, 2, 1, 0),
            preset("Aéreo 800", ModuleKind::Wall, 800, 720, 350, 1320, 2, 1, 0),
            preset(
                "Aéreo 1200",
                ModuleKind::Wall,
                1200,
                720,
                350,
                1320,
                2,
                2,
                0,
            ),
            preset(
                "Gaveteiro 600",
                ModuleKind::Drawer,
                600,
                720,
                550,
                0,
                0,
                0,
                3,
            ),
            preset("Torre 600", ModuleKind::Tall, 600, 2100, 600, 0, 2, 2, 0),
            preset(
                "Nicho aberto",
                ModuleKind::OpenShelf,
                800,
                600,
                300,
                850,
                0,
                3,
                0,
            ),
            preset(
                "Balcão de canto",
                ModuleKind::Base,
                900,
                720,
                900,
                0,
                2,
                1,
                0,
            ),
            preset(
                "Módulo pia 1200",
                ModuleKind::Base,
                1200,
                720,
                550,
                0,
                2,
                1,
                0,
            ),
            preset("Cooktop 900", ModuleKind::Base, 900, 720, 600, 0, 2, 0, 0),
            preset(
                "Aéreo basculante",
                ModuleKind::Wall,
                900,
                400,
                350,
                1500,
                1,
                0,
                0,
            ),
            preset(
                "Torre para forno",
                ModuleKind::Tall,
                700,
                2100,
                650,
                0,
                2,
                1,
                0,
            ),
            preset(
                "Maleiro 1200",
                ModuleKind::Wall,
                1200,
                500,
                600,
                1950,
                2,
                0,
                0,
            ),
            preset(
                "Nicho horizontal",
                ModuleKind::OpenShelf,
                1200,
                350,
                300,
                900,
                0,
                1,
                0,
            ),
            preset(
                "Adega 6 garrafas",
                ModuleKind::OpenShelf,
                300,
                720,
                550,
                0,
                0,
                1,
                0,
            ),
            preset(
                "Adega 12 garrafas",
                ModuleKind::OpenShelf,
                450,
                720,
                550,
                0,
                0,
                2,
                0,
            ),
            preset(
                "Adega 20 garrafas",
                ModuleKind::OpenShelf,
                600,
                900,
                550,
                0,
                0,
                3,
                0,
            ),
            preset(
                "Adega vertical estreita",
                ModuleKind::OpenShelf,
                300,
                1200,
                550,
                0,
                0,
                4,
                0,
            ),
            preset(
                "Adega horizontal",
                ModuleKind::OpenShelf,
                900,
                450,
                550,
                0,
                0,
                2,
                0,
            ),
            preset(
                "Adega com porta",
                ModuleKind::Base,
                600,
                720,
                550,
                0,
                1,
                3,
                0,
            ),
            preset(
                "Porta-latas 2 fileiras",
                ModuleKind::OpenShelf,
                300,
                720,
                550,
                0,
                0,
                2,
                0,
            ),
            preset(
                "Porta-latas 3 fileiras",
                ModuleKind::OpenShelf,
                400,
                720,
                550,
                0,
                0,
                3,
                0,
            ),
            preset(
                "Porta-latas aéreo",
                ModuleKind::Wall,
                450,
                600,
                350,
                1350,
                0,
                3,
                0,
            ),
            preset(
                "Porta-latas extraível",
                ModuleKind::Drawer,
                200,
                600,
                500,
                0,
                0,
                0,
                1,
            ),
            preset(
                "Adega e porta-latas combinado",
                ModuleKind::OpenShelf,
                600,
                720,
                550,
                0,
                0,
                4,
                0,
            ),
        ],
        CatalogTab::Bathroom => vec![
            preset(
                "Gabinete banheiro 450",
                ModuleKind::Base,
                450,
                720,
                450,
                0,
                1,
                1,
                0,
            ),
            preset(
                "Gabinete banheiro 600",
                ModuleKind::Base,
                600,
                720,
                500,
                0,
                2,
                1,
                0,
            ),
            preset(
                "Gabinete banheiro 800",
                ModuleKind::Base,
                800,
                720,
                500,
                0,
                2,
                1,
                0,
            ),
            preset(
                "Gabinete banheiro 1000",
                ModuleKind::Base,
                1000,
                720,
                500,
                0,
                2,
                1,
                0,
            ),
            preset(
                "Gabinete cuba central",
                ModuleKind::Base,
                900,
                720,
                500,
                0,
                2,
                1,
                0,
            ),
            preset(
                "Gabinete cuba dupla",
                ModuleKind::Base,
                1400,
                720,
                500,
                0,
                4,
                1,
                0,
            ),
            preset(
                "Gabinete suspenso",
                ModuleKind::Base,
                800,
                600,
                450,
                300,
                2,
                1,
                0,
            ),
            preset(
                "Gabinete com gavetas",
                ModuleKind::Drawer,
                700,
                720,
                500,
                0,
                0,
                0,
                3,
            ),
            preset(
                "Gaveteiro banheiro",
                ModuleKind::Drawer,
                450,
                650,
                450,
                0,
                0,
                0,
                4,
            ),
            preset(
                "Aéreo banheiro 450",
                ModuleKind::Wall,
                450,
                600,
                200,
                1400,
                1,
                0,
                0,
            ),
            preset(
                "Aéreo banheiro 600",
                ModuleKind::Wall,
                600,
                600,
                200,
                1400,
                2,
                0,
                0,
            ),
            preset(
                "Aéreo banheiro 800",
                ModuleKind::Wall,
                800,
                700,
                220,
                1400,
                2,
                1,
                0,
            ),
            preset(
                "Espelheira 600",
                ModuleKind::Wall,
                600,
                800,
                180,
                1350,
                2,
                1,
                0,
            ),
            preset(
                "Espelheira 900",
                ModuleKind::Wall,
                900,
                800,
                180,
                1350,
                2,
                1,
                0,
            ),
            preset(
                "Torre banheiro estreita",
                ModuleKind::Tall,
                400,
                1800,
                350,
                0,
                1,
                4,
                0,
            ),
            preset(
                "Torre banheiro com cesto",
                ModuleKind::Tall,
                500,
                1800,
                400,
                0,
                1,
                3,
                1,
            ),
            preset(
                "Nicho banheiro",
                ModuleKind::OpenShelf,
                600,
                400,
                180,
                1200,
                0,
                1,
                0,
            ),
            preset(
                "Nicho duplo banheiro",
                ModuleKind::OpenShelf,
                600,
                700,
                180,
                1100,
                0,
                2,
                0,
            ),
            preset(
                "Armário sobre vaso",
                ModuleKind::Wall,
                700,
                650,
                200,
                1500,
                2,
                1,
                0,
            ),
            preset(
                "Coluna rouparia",
                ModuleKind::Tall,
                600,
                2000,
                450,
                0,
                2,
                4,
                0,
            ),
        ],
        CatalogTab::Bedroom => vec![
            preset(
                "Mesa de cabeceira 1 gaveta",
                ModuleKind::Drawer,
                450,
                500,
                400,
                0,
                0,
                0,
                1,
            ),
            preset(
                "Mesa de cabeceira 2 gavetas",
                ModuleKind::Drawer,
                500,
                600,
                420,
                0,
                0,
                0,
                2,
            ),
            preset(
                "Mesa de cabeceira suspensa",
                ModuleKind::Base,
                450,
                300,
                350,
                450,
                1,
                0,
                0,
            ),
            preset(
                "Cômoda 4 gavetas",
                ModuleKind::Drawer,
                900,
                900,
                450,
                0,
                0,
                0,
                4,
            ),
            preset(
                "Cômoda 6 gavetas",
                ModuleKind::Drawer,
                1200,
                900,
                450,
                0,
                0,
                0,
                6,
            ),
            preset(
                "Painel de cabeceira",
                ModuleKind::Wall,
                1800,
                1200,
                80,
                900,
                0,
                0,
                0,
            ),
            preset(
                "Maleiro sobre cama",
                ModuleKind::Wall,
                1800,
                500,
                450,
                1900,
                3,
                0,
                0,
            ),
            preset(
                "Sapateira baixa",
                ModuleKind::Base,
                900,
                700,
                400,
                0,
                2,
                2,
                0,
            ),
            preset(
                "Criado-mudo com nicho",
                ModuleKind::OpenShelf,
                500,
                550,
                400,
                0,
                0,
                1,
                1,
            ),
            preset(
                "Armário lateral compacto",
                ModuleKind::Tall,
                600,
                2000,
                500,
                0,
                2,
                3,
                0,
            ),
        ],
        CatalogTab::Wardrobes => {
            const N: [&str; 40] = [
                "Guarda-roupa 2 portas compacto",
                "Guarda-roupa 3 portas compacto",
                "Guarda-roupa 4 portas casal",
                "Guarda-roupa 6 portas familiar",
                "Guarda-roupa 2 portas de correr",
                "Guarda-roupa 3 portas de correr",
                "Guarda-roupa com 2 gavetas",
                "Guarda-roupa com 4 gavetas",
                "Guarda-roupa com maleiro",
                "Guarda-roupa com espelho",
                "Guarda-roupa canto esquerdo",
                "Guarda-roupa canto direito",
                "Closet aberto compacto",
                "Closet aberto casal",
                "Closet com nichos",
                "Closet com gaveteiro",
                "Roupeiro solteiro",
                "Roupeiro casal",
                "Roupeiro infantil",
                "Roupeiro juvenil",
                "Roupeiro 1800 mm",
                "Roupeiro 2000 mm",
                "Roupeiro 2400 mm",
                "Roupeiro 3 módulos",
                "Roupeiro 4 módulos",
                "Roupeiro com cabideiro duplo",
                "Roupeiro com sapateira",
                "Roupeiro com maleiro superior",
                "Roupeiro portas provençais",
                "Roupeiro portas com cava",
                "Roupeiro portas perfil horizontal",
                "Roupeiro portas perfil vertical",
                "Roupeiro com nicho lateral",
                "Roupeiro com escrivaninha",
                "Roupeiro com TV central",
                "Roupeiro com espelho central",
                "Roupeiro 2 portas e gavetas",
                "Roupeiro 4 portas e gavetas",
                "Roupeiro sob medida baixo",
                "Roupeiro sob medida alto",
            ];
            N.iter()
                .enumerate()
                .map(|(i, n)| {
                    let w = [1200, 1600, 1800, 2000, 2400][i % 5];
                    let h = [2000, 2200, 2400, 2600][i % 4];
                    let d = if i % 4 == 0 { 450 } else { 600 };
                    let doors = if i % 6 == 4 || i % 6 == 5 {
                        2
                    } else {
                        2 + (i % 3) as u32
                    };
                    preset(
                        n,
                        ModuleKind::Tall,
                        w,
                        h,
                        d,
                        0,
                        doors,
                        2 + (i % 5) as u32,
                        if i % 3 == 0 { 2 } else { 0 },
                    )
                })
                .collect()
        }
        CatalogTab::Shelves => {
            const N: [&str; 40] = [
                "Estante biblioteca compacta",
                "Estante biblioteca alta",
                "Estante aberta 3 nichos",
                "Estante aberta 5 nichos",
                "Estante com portas inferiores",
                "Estante com gavetas inferiores",
                "Estante modular 2 colunas",
                "Estante modular 3 colunas",
                "Estante modular 4 colunas",
                "Estante para escritório",
                "Estante para loja",
                "Estante expositor baixa",
                "Estante expositor alta",
                "Estante cubos 3×3",
                "Estante cubos 4×4",
                "Estante assimétrica",
                "Estante escada",
                "Estante de canto",
                "Estante para livros largos",
                "Estante com nicho para TV",
                "Estante com painel central",
                "Estante com armário baixo",
                "Estante com portas superiores",
                "Estante com gaveteiro",
                "Estante suspensa",
                "Estante industrial aberta",
                "Estante dupla face",
                "Estante para arquivo",
                "Estante para brinquedos",
                "Estante para decoração",
                "Estante horizontal baixa",
                "Estante horizontal longa",
                "Estante vertical estreita",
                "Estante vertical larga",
                "Estante 800 mm",
                "Estante 1000 mm",
                "Estante 1200 mm",
                "Estante 1600 mm",
                "Estante 1800 mm",
                "Estante 2400 mm",
            ];
            N.iter()
                .enumerate()
                .map(|(i, n)| {
                    let w = [600, 800, 1000, 1200, 1600, 1800, 2000][i % 7];
                    let h = [900, 1200, 1500, 1800, 2000, 2200, 2400][i % 7];
                    let d = [250, 300, 350, 400][i % 4];
                    preset(
                        n,
                        ModuleKind::OpenShelf,
                        w,
                        h,
                        d,
                        0,
                        if i % 5 == 4 { 2 } else { 0 },
                        2 + (i % 7) as u32,
                        if i % 6 == 5 { 2 } else { 0 },
                    )
                })
                .collect()
        }
        CatalogTab::Panels | CatalogTab::Decor => vec![],
        CatalogTab::Living => vec![
            preset("Rack 1200", ModuleKind::Base, 1200, 600, 450, 0, 2, 1, 0),
            preset("Rack 1800", ModuleKind::Base, 1800, 600, 450, 0, 2, 1, 0),
            preset(
                "Aéreo 1200",
                ModuleKind::Wall,
                1200,
                600,
                350,
                1500,
                2,
                1,
                0,
            ),
            preset(
                "Nicho aberto 800",
                ModuleKind::OpenShelf,
                800,
                600,
                300,
                900,
                0,
                2,
                0,
            ),
            preset(
                "Torre lateral",
                ModuleKind::Tall,
                600,
                1800,
                450,
                0,
                1,
                2,
                0,
            ),
        ],
        CatalogTab::Office => vec![
            preset(
                "Mesa reta 1200",
                ModuleKind::Base,
                1200,
                740,
                600,
                0,
                0,
                0,
                0,
            ),
            preset(
                "Mesa reta 1600",
                ModuleKind::Base,
                1600,
                740,
                700,
                0,
                0,
                0,
                0,
            ),
            preset(
                "Gaveteiro escritório",
                ModuleKind::Drawer,
                450,
                600,
                500,
                0,
                0,
                0,
                3,
            ),
            preset("Armário baixo", ModuleKind::Base, 900, 720, 450, 0, 2, 1, 0),
            preset("Armário alto", ModuleKind::Tall, 900, 2000, 450, 0, 2, 4, 0),
            preset(
                "Estante aberta",
                ModuleKind::OpenShelf,
                1000,
                2000,
                350,
                0,
                0,
                5,
                0,
            ),
        ],
        CatalogTab::Store => vec![
            preset(
                "Balcão expositor",
                ModuleKind::Base,
                1600,
                1000,
                600,
                0,
                2,
                2,
                0,
            ),
            preset(
                "Gôndola baixa",
                ModuleKind::OpenShelf,
                1200,
                1400,
                500,
                0,
                0,
                4,
                0,
            ),
            preset(
                "Prateleira de parede",
                ModuleKind::OpenShelf,
                1200,
                250,
                300,
                1500,
                0,
                1,
                0,
            ),
            preset(
                "Caixa de atendimento",
                ModuleKind::Base,
                1800,
                1050,
                700,
                0,
                3,
                2,
                0,
            ),
            preset(
                "Vitrine torre",
                ModuleKind::Tall,
                700,
                2000,
                450,
                0,
                2,
                4,
                0,
            ),
            preset(
                "Nicho expositor",
                ModuleKind::OpenShelf,
                900,
                1800,
                350,
                0,
                0,
                5,
                0,
            ),
        ],
    }
}
fn decor_presets() -> Vec<(String, u32, u32, u32, Color32)> {
    let bases = [
        ("Cadeira", 450, 900, 450, 148, 102, 69),
        ("Mesa de centro", 900, 400, 600, 160, 120, 81),
        ("Sofá", 1800, 850, 850, 115, 126, 132),
        ("Poltrona", 850, 900, 800, 110, 122, 130),
        ("Vaso", 280, 500, 280, 116, 139, 96),
        ("Geladeira", 700, 1800, 700, 205, 208, 206),
        ("Fogão", 600, 850, 600, 87, 90, 91),
        ("Micro-ondas", 500, 300, 400, 65, 69, 72),
        ("Televisão", 1200, 700, 80, 35, 38, 40),
        ("Luminária", 350, 1600, 350, 198, 179, 127),
        ("Estante", 1000, 1800, 350, 155, 115, 75),
        ("Tapete", 1600, 40, 1200, 120, 102, 84),
        ("Bancada", 1400, 900, 600, 180, 150, 110),
        ("Cama", 1600, 1100, 2000, 150, 130, 115),
        ("Escrivaninha", 1200, 740, 600, 170, 135, 95),
        ("Banco", 900, 450, 400, 140, 110, 80),
        ("Armário", 900, 1900, 500, 165, 130, 90),
        ("Planta", 500, 1200, 500, 70, 120, 70),
        ("Quadro", 700, 900, 50, 190, 180, 160),
        ("Aparador", 1200, 800, 400, 145, 105, 72),
        ("Balcão expositor", 1400, 1100, 600, 120, 100, 85),
        ("Gôndola", 1000, 1500, 500, 170, 140, 100),
        ("Cadeira escritório", 650, 1100, 650, 55, 70, 80),
        ("Arquivo", 500, 1300, 600, 130, 120, 110),
        ("Puff", 600, 450, 600, 160, 100, 100),
    ];
    let mut out = Vec::with_capacity(700);
    for i in 0..500 {
        let (name, w, h, d, r, g, b) = bases[i % bases.len()];
        let variant = i / bases.len();
        let shift = (variant as i32 * 7 % 41) - 20;
        let col = Color32::from_rgb(
            (r as i32 + shift).clamp(0, 255) as u8,
            (g as i32 + shift).clamp(0, 255) as u8,
            (b as i32 + shift).clamp(0, 255) as u8,
        );
        out.push((format!("{name} · modelo {:03}", i + 1), w, h, d, col));
    }
    out.extend(designers::extra_decor());
    out
}
fn shortcut_keys() -> &'static [(egui::Key, &'static str)] {
    &[
        (egui::Key::A, "A"),
        (egui::Key::B, "B"),
        (egui::Key::C, "C"),
        (egui::Key::D, "D"),
        (egui::Key::E, "E"),
        (egui::Key::F, "F"),
        (egui::Key::G, "G"),
        (egui::Key::H, "H"),
        (egui::Key::I, "I"),
        (egui::Key::J, "J"),
        (egui::Key::K, "K"),
        (egui::Key::L, "L"),
        (egui::Key::M, "M"),
        (egui::Key::N, "N"),
        (egui::Key::O, "O"),
        (egui::Key::P, "P"),
        (egui::Key::Q, "Q"),
        (egui::Key::R, "R"),
        (egui::Key::S, "S"),
        (egui::Key::T, "T"),
        (egui::Key::U, "U"),
        (egui::Key::V, "V"),
        (egui::Key::W, "W"),
        (egui::Key::X, "X"),
        (egui::Key::Y, "Y"),
        (egui::Key::Z, "Z"),
    ]
}
fn key_label(key: egui::Key) -> &'static str {
    shortcut_keys()
        .iter()
        .find(|(k, _)| *k == key)
        .map(|(_, s)| *s)
        .unwrap_or("Z")
}
fn key_from_label(s: &str) -> Option<egui::Key> {
    shortcut_keys()
        .iter()
        .find(|(_, label)| *label == s)
        .map(|(k, _)| *k)
}
fn preference_tile(
    ui: &mut egui::Ui,
    icon: &str,
    title: &str,
    desc: &str,
    selected: bool,
    mut toggle: impl FnMut(),
) -> bool {
    let button = egui::Button::new(
        egui::RichText::new(format!("{icon}\n{title}\n{desc}"))
            .size(15.0)
            .strong(),
    )
    .min_size(Vec2::new(155.0, 92.0))
    .fill(if selected {
        Color32::from_rgb(220, 236, 228)
    } else {
        Color32::from_rgb(246, 248, 247)
    });
    if ui.add(button).clicked() {
        toggle();
        true
    } else {
        false
    }
}
fn shortcut_combo(ui: &mut egui::Ui, label: &str, key: &mut egui::Key) -> bool {
    egui::ComboBox::from_label(label)
        .selected_text(key_label(*key))
        .show_ui(ui, |ui| {
            for (candidate, name) in shortcut_keys() {
                ui.selectable_value(key, *candidate, *name);
            }
        })
        .response
        .changed()
}
fn ribbon_button(ui: &mut egui::Ui, _icon: &str, label: &str, selected: bool) -> bool {
    let (r, response) = ui.allocate_exact_size(Vec2::new(86.0, 82.0), Sense::click());
    let bg = if selected {
        Color32::from_rgb(220, 236, 228)
    } else {
        Color32::from_rgb(247, 248, 248)
    };
    ui.painter().rect_filled(r, 7.0, bg);
    ui.painter().rect_stroke(
        r,
        7.0,
        Stroke::new(
            1.0,
            if selected {
                GREEN
            } else {
                Color32::from_gray(210)
            },
        ),
    );
    icons::draw(
        ui.painter(),
        Rect::from_center_size(Pos2::new(r.center().x, r.top() + 25.0), Vec2::splat(32.0)),
        label,
        if selected {
            GREEN
        } else {
            Color32::from_rgb(62, 85, 83)
        },
    );
    let text = ui.painter().layout(
        i18n::tr(label),
        egui::FontId::proportional(12.0),
        Color32::from_gray(50),
        80.0,
    );
    let at = Pos2::new(
        r.center().x - text.size().x / 2.0,
        r.bottom() - 7.0 - text.size().y,
    );
    ui.painter().galley(at, text, Color32::from_gray(50));
    response.on_hover_text(i18n::tr(label)).clicked()
}
fn module_card(ui: &mut egui::Ui, width: f32, p: Preset) -> bool {
    let (r, response) = ui.allocate_exact_size(Vec2::new(width, 100.0), Sense::click());
    let painter = ui.painter();
    painter.rect_filled(r, 7.0, Color32::from_rgb(250, 250, 248));
    painter.rect_stroke(
        r,
        7.0,
        Stroke::new(
            1.0,
            if response.hovered() {
                GREEN
            } else {
                Color32::from_gray(210)
            },
        ),
    );
    let color = match p.kind {
        ModuleKind::Base | ModuleKind::Tall | ModuleKind::Custom => Color32::from_rgb(172, 125, 82),
        ModuleKind::Wall => Color32::from_rgb(194, 155, 114),
        ModuleKind::Drawer => Color32::from_rgb(126, 143, 147),
        ModuleKind::OpenShelf => Color32::from_rgb(161, 138, 107),
    };
    let icon = Rect::from_center_size(
        Pos2::new(r.center().x, r.top() + 31.0),
        Vec2::new(38.0, 39.0),
    );
    painter.rect_filled(icon, 2.0, color);
    painter.rect_stroke(icon, 2.0, Stroke::new(1.3, Color32::from_gray(76)));
    if p.kind == ModuleKind::OpenShelf {
        for n in 1..3 {
            let y = icon.top() + n as f32 * 13.0;
            painter.line_segment(
                [
                    Pos2::new(icon.left() + 2.0, y),
                    Pos2::new(icon.right() - 2.0, y),
                ],
                Stroke::new(1.6, Color32::from_rgb(244, 236, 222)),
            );
        }
    } else if p.doors > 1 || p.drawers > 0 {
        let mid = icon.center().x;
        painter.line_segment(
            [
                Pos2::new(mid, icon.top() + 2.0),
                Pos2::new(mid, icon.bottom() - 2.0),
            ],
            Stroke::new(1.2, Color32::from_rgb(235, 224, 205)),
        );
        painter.circle_filled(
            Pos2::new(mid - 3.0, icon.center().y),
            1.4,
            Color32::from_gray(75),
        );
        painter.circle_filled(
            Pos2::new(mid + 3.0, icon.center().y),
            1.4,
            Color32::from_gray(75),
        );
    }
    painter.text(
        Pos2::new(r.center().x, r.top() + 63.0),
        egui::Align2::CENTER_CENTER,
        p.name,
        egui::FontId::proportional(11.5),
        Color32::from_gray(45),
    );
    painter.text(
        Pos2::new(r.center().x, r.bottom() - 8.0),
        egui::Align2::CENTER_CENTER,
        format!("{} × {} × {}", p.width, p.height, p.depth),
        egui::FontId::proportional(9.5),
        Color32::from_gray(105),
    );
    response.clicked()
}
#[derive(Clone, Copy)]
struct OpeningPreset {
    name: &'static str,
    width: u32,
    height: u32,
    sill: u32,
}
fn opening_presets(kind: OpeningKind) -> Vec<OpeningPreset> {
    if kind == OpeningKind::Door {
        let rows = [
            ("Lisa 600", 600, 2100),
            ("Lisa 700", 700, 2100),
            ("Lisa 800", 800, 2100),
            ("Lisa 900", 900, 2100),
            ("Provençal 600", 600, 2100),
            ("Provençal 700", 700, 2100),
            ("Provençal 800", 800, 2100),
            ("Provençal 900", 900, 2100),
            ("Perfil horizontal 600", 600, 2100),
            ("Perfil horizontal 700", 700, 2100),
            ("Perfil horizontal 800", 800, 2100),
            ("Perfil vertical 700", 700, 2100),
            ("Perfil vertical 800", 800, 2100),
            ("Cava 600", 600, 2100),
            ("Cava 700", 700, 2100),
            ("Cava 800", 800, 2100),
            ("Vidro 700", 700, 2100),
            ("Vidro 800", 800, 2100),
            ("Pivotante 900", 900, 2200),
            ("Correr 1200", 1200, 2100),
        ];
        rows.into_iter()
            .map(|(name, width, height)| OpeningPreset {
                name,
                width,
                height,
                sill: 0,
            })
            .collect()
    } else {
        let rows = [
            ("Maxim-ar 600×600", 600, 600, 1200),
            ("Maxim-ar 800×600", 800, 600, 1200),
            ("Basculante 600×800", 600, 800, 1000),
            ("Basculante 800×800", 800, 800, 1000),
            ("Correr 1000×1000", 1000, 1000, 900),
            ("Correr 1200×1000", 1200, 1000, 900),
            ("Correr 1500×1200", 1500, 1200, 800),
            ("Correr 1800×1200", 1800, 1200, 800),
            ("Fixa 600×1000", 600, 1000, 1000),
            ("Fixa 800×1200", 800, 1200, 800),
            ("Fixa 1000×1500", 1000, 1500, 600),
            ("Panorâmica 1800×1200", 1800, 1200, 800),
            ("Panorâmica 2400×1200", 2400, 1200, 800),
            ("Veneziana 1000×1000", 1000, 1000, 1000),
            ("Veneziana 1200×1000", 1200, 1000, 1000),
            ("Bandeira 1200×400", 1200, 400, 1800),
            ("Cozinha 1200×800", 1200, 800, 1100),
            ("Banheiro 600×600", 600, 600, 1500),
            ("Quarto 1500×1200", 1500, 1200, 900),
            ("Sacada 2000×2100", 2000, 2100, 0),
        ];
        rows.into_iter()
            .map(|(name, width, height, sill)| OpeningPreset {
                name,
                width,
                height,
                sill,
            })
            .collect()
    }
}
fn opening_card(ui: &mut egui::Ui, p: OpeningPreset) -> bool {
    let (r, response) = ui.allocate_exact_size(Vec2::new(144.0, 72.0), Sense::click());
    ui.painter().rect_filled(
        r,
        6.0,
        if response.hovered() {
            Color32::from_rgb(230, 241, 235)
        } else {
            Color32::WHITE
        },
    );
    ui.painter().rect_stroke(
        r,
        6.0,
        Stroke::new(
            1.0,
            if response.hovered() {
                GREEN
            } else {
                Color32::from_gray(210)
            },
        ),
    );
    ui.painter().rect_stroke(
        Rect::from_center_size(
            Pos2::new(r.left() + 25.0, r.center().y),
            Vec2::new(25.0, 42.0),
        ),
        1.0,
        Stroke::new(2.0, Color32::from_rgb(137, 103, 71)),
    );
    ui.painter().text(
        Pos2::new(r.left() + 44.0, r.center().y - 8.0),
        egui::Align2::LEFT_CENTER,
        p.name,
        egui::FontId::proportional(11.0),
        Color32::from_gray(45),
    );
    ui.painter().text(
        Pos2::new(r.left() + 44.0, r.center().y + 11.0),
        egui::Align2::LEFT_CENTER,
        format!("{} × {} mm", p.width, p.height),
        egui::FontId::proportional(10.0),
        Color32::from_gray(100),
    );
    response.clicked()
}
fn floor_textures() -> Vec<&'static str> {
    vec![
        "Cimento claro",
        "Concreto queimado",
        "Porcelanato branco",
        "Porcelanato cinza",
        "Porcelanato bege",
        "Mármore branco",
        "Mármore travertino",
        "Granito preto",
        "Granito cinza",
        "Madeira carvalho",
        "Madeira freijó",
        "Madeira nogueira",
        "Madeira clara",
        "Madeira escura",
        "Taco tradicional",
        "Ladrilho hidráulico",
        "Cerâmica terracota",
        "Ardósia",
        "Pedra natural",
        "Vinílico neutro",
    ]
}
fn default_materials() -> Vec<MaterialData> {
    let rows = [
        ("Carvalho claro", 185.0, true, 190, 143, 95),
        ("Carvalho escuro", 210.0, true, 113, 77, 49),
        ("MDF branco", 105.0, false, 224, 227, 222),
        ("Grafite fosco", 165.0, false, 72, 76, 80),
        ("Freijó", 195.0, true, 205, 158, 91),
        ("Nogueira", 235.0, true, 103, 67, 43),
        ("Amêndoa", 180.0, true, 186, 137, 89),
        ("Louro freijó", 205.0, true, 178, 123, 68),
        ("Cinza cristal", 140.0, false, 166, 169, 170),
        ("Preto TX", 175.0, false, 45, 47, 49),
        ("Areia", 145.0, false, 204, 190, 161),
        ("Azul petróleo", 195.0, false, 47, 83, 91),
        ("Verde oliva", 190.0, false, 100, 110, 74),
        ("Rosa antigo", 185.0, false, 179, 133, 131),
        ("MDF cru", 85.0, false, 190, 176, 151),
        ("Branco brilho", 155.0, false, 242, 242, 238),
        ("Carvalho natural", 215.0, true, 170, 127, 79),
        ("Pau-ferro", 260.0, true, 87, 64, 48),
        ("Linho", 155.0, false, 190, 181, 164),
        ("Concreto urbano", 160.0, false, 129, 132, 132),
    ];
    let mut v: Vec<MaterialData> = rows
        .into_iter()
        .map(|(name, price, has_grain, r, g, b)| MaterialData {
            texture_path: String::new(),
            name: name.into(),
            price_m2: price,
            has_grain,
            gloss: 16,
            reflect: 8,
            color: Color32::from_rgb(r, g, b),
        })
        .collect();
    for i in 20..100 {
        let r = (54 + (i * 73 % 190)) as u8;
        let g = (51 + (i * 37 % 190)) as u8;
        let b = (48 + (i * 97 % 190)) as u8;
        v.push(MaterialData {
            texture_path: String::new(),
            name: format!("MDF sob medida {:03}", i + 1),
            price_m2: 100.0 + (i % 90) as f32,
            has_grain: i % 3 != 0,
            gloss: (i * 7 % 80) as u32,
            reflect: (i * 11 % 50) as u32,
            color: Color32::from_rgb(r, g, b),
        });
    }
    let glass = [
        ("Vidro incolor 4 mm", 190, 220, 232),
        ("Vidro incolor temperado", 185, 220, 232),
        ("Vidro extra clear", 205, 235, 242),
        ("Vidro bronze", 146, 104, 75),
        ("Vidro fumê", 91, 105, 112),
        ("Vidro cinza", 139, 151, 154),
        ("Vidro verde", 112, 156, 143),
        ("Vidro azul", 94, 151, 178),
        ("Vidro reflecta bronze", 158, 116, 82),
        ("Vidro reflecta prata", 179, 191, 194),
        ("Vidro reflecta champanhe", 194, 162, 119),
        ("Vidro canelado", 174, 197, 199),
        ("Vidro mini boreal", 191, 208, 208),
        ("Vidro pontilhado", 178, 196, 194),
        ("Vidro acidato", 206, 214, 211),
        ("Vidro jateado", 199, 207, 204),
        ("Vidro serigrafado preto", 66, 69, 72),
        ("Vidro serigrafado branco", 226, 228, 224),
        ("Espelho prata", 190, 201, 205),
        ("Espelho bronze", 147, 117, 94),
        ("Vidro verde claro", 161, 209, 178),
        ("Vidro âmbar", 201, 160, 78),
        ("Vidro rosa", 219, 175, 181),
        ("Vidro azul acinzentado", 123, 157, 178),
        ("Vidro fumê claro", 150, 163, 170),
        ("Vidro fumê escuro", 65, 77, 89),
        ("Vidro opalino creme", 231, 224, 201),
        ("Vidro opalino cinza", 181, 184, 182),
        ("Vidro bronze claro", 194, 164, 138),
        ("Vidro verde profundo", 68, 117, 101),
    ];
    for (name, r, g, b) in glass {
        v.push(MaterialData {
            texture_path: String::new(),
            name: name.into(),
            price_m2: 240.0,
            has_grain: false,
            gloss: 65,
            reflect: 38,
            color: Color32::from_rgb(r, g, b),
        });
    }
    for (name, r, g, b) in [
        ("Alumínio fosco", 150, 158, 162),
        ("Mármore branco", 220, 218, 208),
        ("Granito São Gabriel", 38, 40, 42),
    ] {
        v.push(MaterialData {
            texture_path: String::new(),
            name: name.into(),
            price_m2: 260.0,
            has_grain: false,
            gloss: 20,
            reflect: 10,
            color: Color32::from_rgb(r, g, b),
        });
    }
    v
}
fn decorative_materials() -> Vec<MaterialData> {
    let names = [
        "Linho",
        "Couro",
        "Veludo",
        "Algodão",
        "Metal escovado",
        "Aço",
        "Cerâmica",
        "Vidro",
        "Pedra",
        "Mármore",
        "Cimento",
        "Pintura",
        "Madeira",
        "Palha",
        "Rattan",
        "Plástico",
        "Bambu",
        "Granito",
        "Pastilha cerâmica",
        "Pastilha vidro",
        "Granito preto",
        "Granito branco",
        "Tecido",
        "Resina",
    ];
    (0..500)
        .map(|i| {
            let r = (38 + (i * 31 % 205)) as u8;
            let g = (40 + (i * 67 % 200)) as u8;
            let b = (42 + (i * 97 % 198)) as u8;
            MaterialData {
                texture_path: String::new(),
                name: format!("{} decorativo {:03}", names[i % names.len()], i + 1),
                price_m2: 35.0 + (i % 240) as f32,
                has_grain: i % 5 == 0,
                gloss: (i * 13 % 100) as u32,
                reflect: (i * 17 % 100) as u32,
                color: Color32::from_rgb(r, g, b),
            }
        })
        .collect()
}

fn tool_picker(ui: &mut egui::Ui, app: &mut FurnitureApp, target: Tool, label: &str) {
    let label = label.trim_start_matches(|c: char| !c.is_alphabetic());
    let selected = app.tool == target;
    let (r, response) =
        ui.allocate_exact_size(Vec2::new(ui.available_width(), 56.), Sense::click());
    ui.painter().rect_filled(
        r,
        7.,
        if selected {
            Color32::from_rgb(220, 236, 228)
        } else {
            Color32::from_rgb(240, 243, 242)
        },
    );
    icons::draw(
        ui.painter(),
        Rect::from_min_size(r.min + Vec2::new(10., 11.), Vec2::splat(34.)),
        label,
        GREEN,
    );
    ui.painter().text(
        r.left_center() + Vec2::new(54., 0.),
        egui::Align2::LEFT_CENTER,
        i18n::tr(label),
        egui::FontId::proportional(15.),
        Color32::DARK_GRAY,
    );
    if response.clicked() {
        app.toggle_tool(target);
    }
}

fn property_field(
    ui: &mut egui::Ui,
    label: &str,
    value: &mut u32,
    range: std::ops::RangeInclusive<u32>,
) {
    ui.horizontal(|ui| {
        ui.label(i18n::tr(label));
        ui.add(
            egui::DragValue::new(value)
                .speed(1)
                .clamp_range(range)
                .suffix(" mm"),
        );
    });
}
fn material_combo(ui: &mut egui::Ui, label: &str, value: &mut String, choices: &[String]) {
    egui::ComboBox::from_label(label)
        .selected_text(value.as_str())
        .show_ui(ui, |ui| {
            for v in choices {
                ui.selectable_value(value, v.clone(), v);
            }
        });
}
fn material_editor(
    ui: &mut egui::Ui,
    list: &mut Vec<MaterialData>,
    name: &mut String,
    price: &mut f32,
) {
    ui.horizontal(|ui| {
        ui.add(
            egui::TextEdit::singleline(name)
                .desired_width(180.0)
                .hint_text("Nome do acabamento"),
        );
        ui.add(
            egui::DragValue::new(price)
                .speed(1.0)
                .prefix("R$ ")
                .clamp_range(0.0..=100000.0),
        );
        if ui.button(i18n::tr("＋ Adicionar material")).clicked() && !name.trim().is_empty() {
            list.push(MaterialData {
                texture_path: String::new(),
                name: name.trim().to_string(),
                price_m2: *price,
                has_grain: true,
                gloss: 20,
                reflect: 10,
                color: Color32::from_rgb(175, 133, 93),
            });
            name.clear();
        }
    });
    ui.label(format!(
        "{} opções cadastradas · preço, veio e aparência podem ser editados",
        list.len()
    ));
    egui::ScrollArea::vertical().show(ui, |ui| {
        egui::Grid::new("materials_catalog")
            .striped(true)
            .min_col_width(75.0)
            .show(ui, |ui| {
                for h in [
                    "Amostra", "Material", "R$/m²", "Veio", "Brilho", "Reflexo", "Cor", "Imagem",
                ] {
                    ui.strong(h);
                }
                ui.end_row();
                for m in list.iter_mut() {
                    let (r, _) = ui.allocate_exact_size(Vec2::new(42.0, 22.0), Sense::hover());
                    ui.painter().rect_filled(r, 3.0, m.color);
                    ui.painter()
                        .rect_stroke(r, 3.0, Stroke::new(1.0, Color32::DARK_GRAY));
                    ui.add(egui::TextEdit::singleline(&mut m.name).desired_width(150.0));
                    ui.add(
                        egui::DragValue::new(&mut m.price_m2)
                            .speed(1.0)
                            .prefix("R$ ")
                            .clamp_range(0.0..=100000.0),
                    );
                    ui.checkbox(&mut m.has_grain, i18n::tr("Sim"));
                    ui.add(egui::Slider::new(&mut m.gloss, 0..=100).show_value(false));
                    ui.add(egui::Slider::new(&mut m.reflect, 0..=100).show_value(false));
                    egui::ComboBox::from_id_source(("mat_color", &m.name))
                        .selected_text(i18n::tr("Paleta"))
                        .show_ui(ui, |ui| {
                            for (label, color) in [
                                ("Madeira clara", Color32::from_rgb(190, 143, 95)),
                                ("Madeira escura", Color32::from_rgb(113, 77, 49)),
                                ("Branco", Color32::from_rgb(224, 227, 222)),
                                ("Grafite", Color32::from_rgb(72, 76, 80)),
                                ("Freijó", Color32::from_rgb(205, 158, 91)),
                                ("Azul", Color32::from_rgb(65, 105, 160)),
                                ("Verde", Color32::from_rgb(72, 130, 91)),
                            ] {
                                ui.selectable_value(&mut m.color, color, label);
                            }
                        });
                    if ui
                        .button(if m.texture_path.is_empty() {
                            "Importar PNG"
                        } else {
                            "Trocar PNG"
                        })
                        .clicked()
                    {
                        if let Ok(result) = Command::new("zenity")
                            .args(["--file-selection", "--file-filter=Textura PNG | *.png"])
                            .output()
                        {
                            if result.status.success() {
                                let path =
                                    String::from_utf8_lossy(&result.stdout).trim().to_owned();
                                if visual::texture(&path).is_some() {
                                    m.texture_path = path;
                                }
                            }
                        }
                    }
                    if !m.texture_path.is_empty() {
                        if ui.small_button("Remover imagem").clicked() {
                            m.texture_path.clear();
                        }
                    }
                    ui.end_row();
                }
            });
    });
}
fn grain_combo(ui: &mut egui::Ui, label: &str, value: &mut Grain) {
    egui::ComboBox::from_label(label)
        .selected_text(value.label())
        .show_ui(ui, |ui| {
            ui.selectable_value(value, Grain::Length, Grain::Length.label());
            ui.selectable_value(value, Grain::Width, Grain::Width.label());
        });
}
fn wall_point_from_measure(start: P2, length_mm: u32, direction_deg: f32) -> P2 {
    let a = direction_deg.to_radians();
    P2::new(
        start.x + length_mm as f32 * a.cos(),
        start.z + length_mm as f32 * a.sin(),
    )
}
fn constrain_wall_point(
    anchor: P2,
    point: P2,
    walls: &[Wall],
    ortho: bool,
    perpendicular: bool,
    angular: bool,
    step_deg: u32,
) -> P2 {
    let dx = point.x - anchor.x;
    let dz = point.z - anchor.z;
    let length = (dx * dx + dz * dz).sqrt();
    if length < 1.0 {
        return point;
    }
    let target = dz.atan2(dx);
    let mut candidates = Vec::new();
    if ortho {
        candidates.extend([
            0.0,
            std::f32::consts::FRAC_PI_2,
            std::f32::consts::PI,
            std::f32::consts::PI * 1.5,
        ]);
    }
    if perpendicular {
        if let Some((wall, _)) = walls
            .iter()
            .map(|w| (w, project_to_wall(anchor, w).1))
            .min_by(|a, b| a.1.total_cmp(&b.1))
        {
            let base = (wall.end.z - wall.start.z).atan2(wall.end.x - wall.start.x)
                + std::f32::consts::FRAC_PI_2;
            candidates.extend([base, base + std::f32::consts::PI]);
        }
    }
    if angular {
        let step = (step_deg.max(1) as f32).to_radians();
        candidates.push((target / step).round() * step);
    }
    if let Some(angle) = candidates
        .into_iter()
        .min_by(|a, b| angle_difference(*a, target).total_cmp(&angle_difference(*b, target)))
    {
        P2::new(
            anchor.x + length * angle.cos(),
            anchor.z + length * angle.sin(),
        )
    } else {
        point
    }
}
fn angle_difference(a: f32, b: f32) -> f32 {
    let d = (a - b).abs() % std::f32::consts::TAU;
    d.min(std::f32::consts::TAU - d)
}
fn snap(value: f32, step: f32) -> f32 {
    (value / step).round() * step
}
fn material_color(material: &str) -> Color32 {
    match material {
        "MDF branco" => Color32::from_rgb(224, 227, 222),
        "Grafite fosco" => Color32::from_rgb(72, 76, 80),
        "Carvalho escuro" => Color32::from_rgb(113, 77, 49),
        "Freijó" => Color32::from_rgb(205, 158, 91),
        _ => Color32::from_rgb(190, 143, 95),
    }
}
fn material_color_for(material: &str, materials: &[MaterialData]) -> Color32 {
    materials
        .iter()
        .filter(|m| material == m.name || material.starts_with(&format!("{} ", m.name)))
        .max_by_key(|m| m.name.len())
        .map(|m| m.color)
        .unwrap_or_else(|| material_color(material))
}
fn csv_escape(s: &str) -> String {
    if s.chars().any(|c| matches!(c, ';' | '"' | '\n' | '\r')) {
        format!("\"{}\"", s.replace('"', "\"\""))
    } else {
        s.to_owned()
    }
}
fn csv_for_parts(parts: &[Part]) -> String {
    let mut csv=String::from("Módulo;Peça;Quantidade;Comprimento (mm);Largura (mm);Espessura (mm);Material;Fita de borda;Sentido do veio\r\n");
    for p in parts {
        csv.push_str(&format!(
            "{};{};{};{};{};{};{};{};{}\r\n",
            csv_escape(&p.group),
            csv_escape(&p.name),
            p.quantity,
            p.length_mm,
            p.width_mm,
            p.thickness_mm,
            csv_escape(&p.material),
            csv_escape(&p.edge),
            csv_escape(&p.grain)
        ));
    }
    csv
}
fn write_file(path: &str, contents: &str) -> io::Result<()> {
    if let Some(parent) = Path::new(path).parent() {
        if !parent.as_os_str().is_empty() {
            fs::create_dir_all(parent)?;
        }
    }
    fs::write(path, contents)
}

fn parts_for_module(m: &Module) -> Vec<Part> {
    let board = format!("{} {} mm", m.material, m.thickness_mm);
    let group = m.name.clone();
    let mut p = vec![
        Part {
            group: group.clone(),
            name: "Lateral".into(),
            quantity: 2,
            length_mm: m.height_mm,
            width_mm: m.depth_mm,
            thickness_mm: m.thickness_mm,
            material: board.clone(),
            edge: "2 lados longos".into(),
            grain: m.grain.label().into(),
        },
        Part {
            group: group.clone(),
            name: "Base e tampo".into(),
            quantity: 2,
            length_mm: m.width_mm.saturating_sub(2 * m.thickness_mm),
            width_mm: m.depth_mm,
            thickness_mm: m.thickness_mm,
            material: board.clone(),
            edge: "borda frontal".into(),
            grain: m.grain.label().into(),
        },
        Part {
            group: group.clone(),
            name: "Fundo".into(),
            quantity: 1,
            length_mm: m.height_mm.saturating_sub(2 * m.thickness_mm),
            width_mm: m.width_mm.saturating_sub(2 * m.thickness_mm),
            thickness_mm: 6,
            material: "MDF branco 6 mm".into(),
            edge: "sem fita".into(),
            grain: "Sem restrição".into(),
        },
    ];
    if m.shelf_count > 0 {
        p.push(Part {
            group: group.clone(),
            name: "Prateleira".into(),
            quantity: m.shelf_count,
            length_mm: m.width_mm.saturating_sub(2 * m.thickness_mm),
            width_mm: m.depth_mm.saturating_sub(20),
            thickness_mm: m.thickness_mm,
            material: board.clone(),
            edge: "borda frontal".into(),
            grain: m.grain.label().into(),
        });
    }
    if m.kind == ModuleKind::Drawer {
        let n = m.drawer_count.max(1);
        p.push(Part {
            group,
            name: "Frente de gaveta".into(),
            quantity: n,
            length_mm: m.width_mm.saturating_sub(4),
            width_mm: m.height_mm.saturating_sub(20) / n,
            thickness_mm: m.thickness_mm,
            material: board,
            edge: "4 lados".into(),
            grain: m.grain.label().into(),
        });
    } else if m.door_count > 0 {
        p.push(Part {
            group,
            name: "Porta".into(),
            quantity: m.door_count,
            length_mm: m.height_mm.saturating_sub(4),
            width_mm: m.width_mm.saturating_sub(4 * m.door_count) / m.door_count,
            thickness_mm: m.thickness_mm,
            material: board,
            edge: "4 lados".into(),
            grain: m.grain.label().into(),
        });
    }
    p
}

fn parts_for_module_configured(
    m: &Module,
    top: u32,
    back: u32,
    gap: u32,
    edge: &str,
    back_mount: &str,
) -> Vec<Part> {
    let mut p = parts_for_module(m);
    for item in &mut p {
        if item.name == "Base e tampo" {
            item.thickness_mm = top;
        } else if item.name == "Fundo" {
            item.thickness_mm = back;
            if back_mount == "Sobreposto" {
                item.length_mm = m.height_mm;
                item.width_mm = m.width_mm;
            } else if back_mount == "Canaleta" {
                item.length_mm = item.length_mm.saturating_sub(4);
                item.width_mm = item.width_mm.saturating_sub(4);
            }
        } else if item.name == "Porta" {
            item.width_mm = item.width_mm.saturating_sub(gap);
            item.material = format!("{} {} mm", m.door_material, m.thickness_mm);
        } else if item.name == "Frente de gaveta" {
            item.width_mm = item.width_mm.saturating_sub(gap);
            item.material = format!("{} {} mm", m.door_material, m.thickness_mm);
        }
        if item.edge != "sem fita" {
            item.edge = edge.to_string();
        }
    }
    p
}
fn hardware_for_module(m: &Module) -> Vec<Part> {
    let group = m.name.clone();
    let drawer_count = if m.kind == ModuleKind::Drawer {
        m.drawer_count.max(1)
    } else {
        m.drawer_count
    };
    let hinges = if m.door_count == 0 {
        0
    } else {
        m.door_count * if m.height_mm > 1200 { 3 } else { 2 }
    };
    let screw_count = 8 + m.shelf_count * 4 + m.door_count * 2 + drawer_count * 4;
    let nail_count = ((m.width_mm + m.height_mm) * 2 / 100).max(8);
    let mut h = vec![
        ("Parafuso confirmat 7x50", screw_count, "Fixação estrutural"),
        ("Prego para fundo", nail_count, "Montagem do fundo"),
    ];
    if hinges > 0 {
        h.push(("Dobradiça com caneco", hinges, "Ferragem"));
    }
    if drawer_count > 0 {
        h.push(("Par de corrediças telescópicas", drawer_count, "Ferragem"));
        h.push(("Parafuso para corrediça", drawer_count * 8, "Ferragem"));
    }
    if m.door_count > 0 {
        h.push(("Puxador", m.door_count, "Ferragem"));
    }
    h.into_iter()
        .map(|(name, quantity, kind)| Part {
            group: group.clone(),
            name: name.into(),
            quantity,
            length_mm: 0,
            width_mm: 0,
            thickness_mm: 0,
            material: kind.into(),
            edge: "—".into(),
            grain: "—".into(),
        })
        .collect()
}

fn project_to_wall(p: P2, w: &Wall) -> (f32, f32) {
    let dx = w.end.x - w.start.x;
    let dz = w.end.z - w.start.z;
    let len = (dx * dx + dz * dz).sqrt().max(1.0);
    let ux = dx / len;
    let uz = dz / len;
    let px = p.x - w.start.x;
    let pz = p.z - w.start.z;
    let raw = px * ux + pz * uz;
    let t = raw.clamp(0.0, len);
    let q = P2::new(w.start.x + ux * t, w.start.z + uz * t);
    (t, p.distance(q))
}
fn distance_to_segment(p: P2, a: P2, b: P2) -> f32 {
    let w = Wall {
        material: "Pintura branca".into(),
        color: Color32::from_rgb(220, 221, 218),
        id: 0,
        start: a,
        end: b,
        thickness_mm: 0,
        height_mm: 0,
    };
    project_to_wall(p, &w).1
}

fn draw_plan(
    p: &egui::Painter,
    tr: PlanTransform,
    room: [u32; 3],
    walls: &[Wall],
    openings: &[Opening],
    modules: &[Module],
    panels: &[WoodPanel],
    gesso: &[GessoBlock],
    decor: &[DecorItem],
    materials: &[MaterialData],
    hidden: &[u32],
    selected: Option<Selection>,
    pending: Option<P2>,
    tool: Tool,
    show_rulers: bool,
    ctx: &egui::Context,
) {
    let floor = Color32::from_rgb(250, 250, 248);
    p.rect_filled(tr.rect, 0.0, floor);
    if show_rulers {
        let ink = Color32::from_rgb(72, 91, 86);
        let origin = tr.screen(P2::new(0.0, 0.0));
        let top = origin.y - 18.0;
        let left = origin.x - 18.0;
        p.line_segment(
            [
                Pos2::new(origin.x, top),
                Pos2::new(tr.screen(P2::new(room[0] as f32, 0.0)).x, top),
            ],
            Stroke::new(1.0, ink),
        );
        for x in (0..=room[0]).step_by(500) {
            let sx = tr.screen(P2::new(x as f32, 0.0)).x;
            p.line_segment(
                [Pos2::new(sx, top - 3.0), Pos2::new(sx, top + 3.0)],
                Stroke::new(1.0, ink),
            );
            p.text(
                Pos2::new(sx, top - 5.0),
                egui::Align2::CENTER_BOTTOM,
                format!("{x}"),
                egui::FontId::proportional(9.0),
                ink,
            );
        }
        p.line_segment(
            [
                Pos2::new(left, origin.y),
                Pos2::new(left, tr.screen(P2::new(0.0, room[2] as f32)).y),
            ],
            Stroke::new(1.0, ink),
        );
        for z in (0..=room[2]).step_by(500) {
            let sy = tr.screen(P2::new(0.0, z as f32)).y;
            p.line_segment(
                [Pos2::new(left - 3.0, sy), Pos2::new(left + 3.0, sy)],
                Stroke::new(1.0, ink),
            );
            p.text(
                Pos2::new(left - 5.0, sy),
                egui::Align2::RIGHT_CENTER,
                format!("{z}"),
                egui::FontId::proportional(9.0),
                ink,
            );
        }
    }
    for x in (0..=room[0]).step_by(250) {
        let a = tr.screen(P2::new(x as f32, 0.0));
        let b = tr.screen(P2::new(x as f32, room[2] as f32));
        p.line_segment([a, b], Stroke::new(0.6, GRID));
    }
    for z in (0..=room[2]).step_by(250) {
        let a = tr.screen(P2::new(0.0, z as f32));
        let b = tr.screen(P2::new(room[0] as f32, z as f32));
        p.line_segment([a, b], Stroke::new(0.6, GRID));
    }
    for wall in walls.iter().filter(|w| !hidden.contains(&w.id)) {
        let a = tr.screen(wall.start);
        let b = tr.screen(wall.end);
        p.line_segment(
            [a, b],
            Stroke::new(
                (wall.thickness_mm as f32 * tr.scale).max(3.0),
                Color32::from_rgb(92, 98, 101),
            ),
        );
        let len = wall.start.distance(wall.end);
        let angle = (wall.end.z - wall.start.z)
            .atan2(wall.end.x - wall.start.x)
            .to_degrees();
        let mid = a + (b - a) * 0.5;
        p.text(
            mid + Vec2::new(0.0, -12.0),
            egui::Align2::CENTER_CENTER,
            format!("{:.0} mm  ·  {:.0}°", len, angle),
            egui::FontId::proportional(10.0),
            Color32::from_rgb(63, 73, 76),
        );
    }
    for opening in openings.iter().filter(|o| !hidden.contains(&o.id)) {
        if let Some(w) = walls
            .iter()
            .find(|w| w.id == opening.wall_id && !hidden.contains(&w.id))
        {
            let len = w.start.distance(w.end).max(1.0);
            let t = (opening.center_mm as f32 / len).clamp(0.0, 1.0);
            let dx = w.end.x - w.start.x;
            let dz = w.end.z - w.start.z;
            let ux = dx / len;
            let uz = dz / len;
            let a = P2::new(
                w.start.x + ux * (opening.center_mm as f32 - opening.width_mm as f32 / 2.0),
                w.start.z + uz * (opening.center_mm as f32 - opening.width_mm as f32 / 2.0),
            );
            let b = P2::new(
                a.x + ux * opening.width_mm as f32,
                a.z + uz * opening.width_mm as f32,
            );
            let sa = tr.screen(a);
            let sb = tr.screen(b);
            p.line_segment(
                [sa, sb],
                Stroke::new((w.thickness_mm as f32 * tr.scale + 4.0).max(5.0), floor),
            );
            if opening.kind == OpeningKind::Window {
                let n = Vec2::new(-(sb.y - sa.y), sb.x - sa.x).normalized() * 3.0;
                p.line_segment(
                    [sa + n, sb + n],
                    Stroke::new(1.5, Color32::from_rgb(61, 128, 157)),
                );
                p.line_segment(
                    [sa - n, sb - n],
                    Stroke::new(1.5, Color32::from_rgb(61, 128, 157)),
                );
            } else {
                let leaf = Pos2::new(sa.x + (sb.x - sa.x) * 0.65, sa.y + (sb.y - sa.y) * 0.65);
                p.line_segment([sa, leaf], Stroke::new(1.4, Color32::from_rgb(126, 93, 58)));
            }
            let _ = t;
        }
    }
    for g in gesso.iter().filter(|g| !hidden.contains(&g.id)) {
        let a = tr.screen(P2::new(g.x_mm as f32, g.z_mm as f32));
        let b = tr.screen(P2::new(
            (g.x_mm + g.width_mm) as f32,
            (g.z_mm + g.depth_mm) as f32,
        ));
        let r = Rect::from_two_pos(a, b);
        p.rect_filled(r, 0.0, Color32::from_rgba_unmultiplied(167, 132, 195, 90));
        p.rect_stroke(r, 0.0, Stroke::new(1.5, Color32::from_rgb(120, 85, 151)));
        p.text(
            r.center(),
            egui::Align2::CENTER_CENTER,
            "GESSO",
            egui::FontId::proportional(11.0),
            Color32::from_rgb(91, 62, 116),
        );
    }
    for panel in panels.iter().filter(|v| !hidden.contains(&v.id)) {
        let pts: Vec<_> = automation::corners(panel)
            .iter()
            .map(|p| tr.screen(*p))
            .collect();
        let center = Rect::from_points(&pts).center();
        p.add(egui::Shape::convex_polygon(
            pts,
            material_color_for(&panel.material, materials),
            Stroke::new(1.3, GREEN),
        ));
        p.text(
            center,
            egui::Align2::CENTER_CENTER,
            &panel.name,
            egui::FontId::proportional(9.0),
            Color32::DARK_GRAY,
        );
    }

    for m in modules.iter().filter(|v| !hidden.contains(&v.id)) {
        let points: Vec<Pos2> = module_corners(m).iter().map(|v| tr.screen(*v)).collect();
        let center = points
            .iter()
            .copied()
            .fold(Pos2::ZERO, |a, b| a + b.to_vec2())
            / 4.0;
        p.add(egui::Shape::convex_polygon(
            points.clone(),
            material_color_for(&m.material, materials),
            Stroke::new(
                1.4,
                if selected == Some(Selection::Module(m.id)) {
                    GREEN
                } else {
                    Color32::from_rgb(72, 73, 70)
                },
            ),
        ));
        p.text(
            center,
            egui::Align2::CENTER_CENTER,
            format!("{}\n{} × {}", m.name, m.width_mm, m.depth_mm),
            egui::FontId::proportional(10.5),
            Color32::from_rgb(49, 50, 49),
        );
    }
    for d in decor.iter().filter(|d| !hidden.contains(&d.id)) {
        let pts: Vec<_> = geometry::footprint(d)
            .iter()
            .map(|p| tr.screen(*p))
            .collect();
        let color = if selected == Some(Selection::Decor(d.id)) {
            GREEN
        } else {
            Color32::DARK_GRAY
        };
        for i in 0..pts.len() {
            p.line_segment([pts[i], pts[(i + 1) % pts.len()]], Stroke::new(2., color));
        }
        p.text(
            Rect::from_points(&pts).center(),
            egui::Align2::CENTER_CENTER,
            &d.name,
            egui::FontId::proportional(10.),
            color,
        );
    }
    if let Some(Selection::Wall(id)) = selected {
        if let Some(w) = walls.iter().find(|w| w.id == id) {
            p.line_segment(
                [tr.screen(w.start), tr.screen(w.end)],
                Stroke::new(w.thickness_mm as f32 * tr.scale + 4.0, GREEN),
            );
            p.line_segment(
                [tr.screen(w.start), tr.screen(w.end)],
                Stroke::new(
                    w.thickness_mm as f32 * tr.scale,
                    Color32::from_rgb(92, 98, 101),
                ),
            );
        }
    }
    if let Some(start) = pending {
        if let Some(pos) = ctx
            .input(|i| i.pointer.hover_pos())
            .filter(|p| tr.rect.contains(*p))
        {
            let a = tr.screen(start);
            let b = tr.world(pos);
            p.line_segment(
                [a, tr.screen(P2::new(snap(b.x, 50.0), snap(b.z, 50.0)))],
                Stroke::new(2.0, GREEN),
            );
            p.circle_filled(a, 4.0, GREEN);
        }
    }
    p.rect_stroke(
        Rect::from_min_max(
            tr.screen(P2::new(0.0, 0.0)),
            tr.screen(P2::new(room[0] as f32, room[2] as f32)),
        ),
        0.0,
        Stroke::new(1.0, Color32::from_gray(110)),
    );
    p.text(
        tr.rect.left_top() + Vec2::new(12.0, 10.0),
        egui::Align2::LEFT_TOP,
        "PLANTA SUPERIOR  ·  GRADE 250 mm",
        egui::FontId::proportional(12.0),
        Color32::from_gray(90),
    );
    p.text(
        Pos2::new(tr.rect.center().x, tr.rect.bottom() - 14.0),
        egui::Align2::CENTER_CENTER,
        format!("{} × {} mm   ·   Ferramenta: {:?}", room[0], room[2], tool),
        egui::FontId::proportional(12.0),
        Color32::from_gray(90),
    );
}

fn module_corners(m: &Module) -> [P2; 4] {
    let a = m.rotation_deg.to_radians();
    let (s, c) = a.sin_cos();
    let x = m.x_mm as f32;
    let z = m.z_mm as f32;
    let w = m.width_mm as f32;
    let d = m.depth_mm as f32;
    let tr = |lx: f32, lz: f32| P2::new(x + lx * c - lz * s, z + lx * s + lz * c);
    [tr(0.0, 0.0), tr(w, 0.0), tr(w, d), tr(0.0, d)]
}
fn point_in_poly(p: Pos2, poly: &[Pos2]) -> bool {
    let mut inside = false;
    let mut j = poly.len() - 1;
    for i in 0..poly.len() {
        let a = poly[i];
        let b = poly[j];
        if ((a.y > p.y) != (b.y > p.y))
            && (p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y + 0.0001) + a.x)
        {
            inside = !inside;
        }
        j = i;
    }
    inside
}
fn pick_plan(p: Pos2, tr: PlanTransform, modules: &[Module], hidden: &[u32]) -> Option<u32> {
    modules
        .iter()
        .rev()
        .filter(|m| !hidden.contains(&m.id))
        .find(|m| {
            let poly: Vec<Pos2> = module_corners(m).iter().map(|v| tr.screen(*v)).collect();
            point_in_poly(p, &poly)
        })
        .map(|m| m.id)
}
fn pick_wall_plan(p: Pos2, tr: PlanTransform, walls: &[Wall], hidden: &[u32]) -> Option<u32> {
    let world = tr.world(p);
    walls
        .iter()
        .filter(|w| !hidden.contains(&w.id))
        .map(|w| (w, project_to_wall(world, w).1))
        .filter(|(w, d)| *d <= w.thickness_mm as f32 / 2.0 + 180.0)
        .min_by(|a, b| a.1.total_cmp(&b.1))
        .map(|(w, _)| w.id)
}
fn pick_plan_any(
    p: Pos2,
    tr: PlanTransform,
    walls: &[Wall],
    openings: &[Opening],
    modules: &[Module],
    panels: &[WoodPanel],
    gesso: &[GessoBlock],
    decor: &[DecorItem],
    hidden: &[u32],
) -> Option<Selection> {
    if let Some(id) = pick_plan(p, tr, modules, hidden) {
        return Some(Selection::Module(id));
    }
    let world = tr.world(p);
    for d in decor.iter().rev().filter(|d| !hidden.contains(&d.id)) {
        let pts: Vec<_> = geometry::footprint(d)
            .iter()
            .map(|v| tr.screen(*v))
            .collect();
        if point_in_poly(p, &pts) {
            return Some(Selection::Decor(d.id));
        }
    }
    for o in openings.iter().rev().filter(|o| !hidden.contains(&o.id)) {
        if let Some(w) = walls
            .iter()
            .find(|w| w.id == o.wall_id && !hidden.contains(&w.id))
        {
            let (off, d) = project_to_wall(world, w);
            if d < w.thickness_mm as f32 / 2.0 + 70.0
                && (off - o.center_mm as f32).abs() < o.width_mm as f32 / 2.0
            {
                return Some(Selection::Opening(o.id));
            }
        }
    }
    for w in walls.iter().rev().filter(|w| !hidden.contains(&w.id)) {
        if distance_to_segment(world, w.start, w.end) < w.thickness_mm as f32 / 2.0 + 70.0 {
            return Some(Selection::Wall(w.id));
        }
    }
    for b in panels.iter().rev().filter(|b| !hidden.contains(&b.id)) {
        let pts: Vec<_> = automation::corners(b)
            .iter()
            .map(|p| tr.screen(*p))
            .collect();
        if point_in_poly(p, &pts) {
            return Some(Selection::Panel(b.id));
        }
    }
    for g in gesso.iter().rev().filter(|g| !hidden.contains(&g.id)) {
        if Rect::from_min_max(
            tr.screen(P2::new(g.x_mm as f32, g.z_mm as f32)),
            tr.screen(P2::new(
                (g.x_mm + g.width_mm) as f32,
                (g.z_mm + g.depth_mm) as f32,
            )),
        )
        .contains(p)
        {
            return Some(Selection::Gesso(g.id));
        }
    }
    None
}

fn face(faces: &mut Vec<Face>, camera: Camera, points: [V3; 4], color: Color32) {
    let depth = points
        .iter()
        .map(|p| p.sub(camera.target).dot(camera.basis().2))
        .sum::<f32>()
        / 4.0;
    faces.push(Face {
        surface: None,
        points,
        color,
        depth,
    });
}
fn append_box(faces: &mut Vec<Face>, camera: Camera, min: V3, max: V3, color: Color32) {
    let (a, b, c, d) = (
        V3::new(min.x, min.y, min.z),
        V3::new(max.x, min.y, min.z),
        V3::new(max.x, max.y, min.z),
        V3::new(min.x, max.y, min.z),
    );
    let (e, f, g, h) = (
        V3::new(min.x, min.y, max.z),
        V3::new(max.x, min.y, max.z),
        V3::new(max.x, max.y, max.z),
        V3::new(min.x, max.y, max.z),
    );
    let shade = |k: f32| {
        Color32::from_rgba_unmultiplied(
            (color.to_srgba_unmultiplied()[0] as f32 * k) as u8,
            (color.to_srgba_unmultiplied()[1] as f32 * k) as u8,
            (color.to_srgba_unmultiplied()[2] as f32 * k) as u8,
            color.a(),
        )
    };
    face(faces, camera, [a, b, c, d], shade(0.82));
    face(faces, camera, [e, h, g, f], shade(1.0));
    face(faces, camera, [a, e, f, b], shade(0.70));
    face(faces, camera, [d, c, g, h], shade(0.90));
    face(faces, camera, [a, d, h, e], shade(0.78));
    face(faces, camera, [b, f, g, c], shade(0.88));
}
fn append_wall_piece(
    faces: &mut Vec<Face>,
    camera: Camera,
    w: &Wall,
    u0: f32,
    u1: f32,
    y0: f32,
    y1: f32,
) {
    if u1 <= u0 || y1 <= y0 {
        return;
    }
    let dx = w.end.x - w.start.x;
    let dz = w.end.z - w.start.z;
    let len = (dx * dx + dz * dz).sqrt().max(1.0);
    let ux = dx / len;
    let uz = dz / len;
    let nx = -uz * w.thickness_mm as f32 / 2.0;
    let nz = ux * w.thickness_mm as f32 / 2.0;
    let pt = |u: f32, y: f32, side: f32| {
        V3::new(
            w.start.x + ux * u + (-uz) * side,
            y,
            w.start.z + uz * u + ux * side,
        )
    };
    let a = pt(u0, y0, -(w.thickness_mm as f32) / 2.0);
    let b = pt(u1, y0, -(w.thickness_mm as f32) / 2.0);
    let c = pt(u1, y1, -(w.thickness_mm as f32) / 2.0);
    let d = pt(u0, y1, -(w.thickness_mm as f32) / 2.0);
    let e = pt(u0, y0, w.thickness_mm as f32 / 2.0);
    let f = pt(u1, y0, w.thickness_mm as f32 / 2.0);
    let g = pt(u1, y1, w.thickness_mm as f32 / 2.0);
    let h = pt(u0, y1, w.thickness_mm as f32 / 2.0);
    let col = w.color;
    face(faces, camera, [a, b, c, d], col);
    face(faces, camera, [e, h, g, f], col);
    face(
        faces,
        camera,
        [a, e, f, b],
        Color32::from_rgb(190, 192, 190),
    );
    face(
        faces,
        camera,
        [d, c, g, h],
        Color32::from_rgb(210, 211, 208),
    );
    face(
        faces,
        camera,
        [a, d, h, e],
        Color32::from_rgb(200, 202, 200),
    );
    face(
        faces,
        camera,
        [b, f, g, c],
        Color32::from_rgb(200, 202, 200),
    );
    let _ = (nx, nz);
}
fn append_wall_faces(faces: &mut Vec<Face>, camera: Camera, w: &Wall, openings: &[Opening]) {
    let len = w.start.distance(w.end);
    let mut os: Vec<&Opening> = openings.iter().filter(|o| o.wall_id == w.id).collect();
    os.sort_by_key(|o| o.center_mm);
    let mut cursor = 0.0;
    for o in os {
        let half = o.width_mm as f32 / 2.0;
        let a = (o.center_mm as f32 - half).clamp(cursor, len);
        let b = (o.center_mm as f32 + half).clamp(a, len);
        append_wall_piece(faces, camera, w, cursor, a, 0.0, w.height_mm as f32);
        append_wall_piece(faces, camera, w, a, b, 0.0, o.sill_mm as f32);
        append_wall_piece(
            faces,
            camera,
            w,
            a,
            b,
            (o.sill_mm + o.height_mm) as f32,
            w.height_mm as f32,
        );
        cursor = b;
    }
    append_wall_piece(faces, camera, w, cursor, len, 0.0, w.height_mm as f32);
}
fn append_module_box(
    faces: &mut Vec<Face>,
    camera: Camera,
    m: &Module,
    min: V3,
    max: V3,
    color: Color32,
    door_angle: f32,
    pivot_x: f32,
) {
    let (sa, ca) = door_angle.to_radians().sin_cos();
    let (sm, cm) = m.rotation_deg.to_radians().sin_cos();
    let pivot = (m.x_mm as f32, m.z_mm as f32);
    let transform = |p: V3| {
        let mut x = p.x;
        let mut z = p.z;
        if door_angle.abs() > 0.01 {
            let lx = x - pivot_x;
            let lz = z - (m.z_mm as f32);
            x = pivot_x + lx * ca - lz * sa;
            z = m.z_mm as f32 + lx * sa + lz * ca;
        }
        let dx = x - pivot.0;
        let dz = z - pivot.1;
        V3::new(
            pivot.0 + dx * cm - dz * sm,
            p.y,
            pivot.1 + dx * sm + dz * cm,
        )
    };
    let (a, b, c, d) = (
        transform(V3::new(min.x, min.y, min.z)),
        transform(V3::new(max.x, min.y, min.z)),
        transform(V3::new(max.x, max.y, min.z)),
        transform(V3::new(min.x, max.y, min.z)),
    );
    let (e, f, g, h) = (
        transform(V3::new(min.x, min.y, max.z)),
        transform(V3::new(max.x, min.y, max.z)),
        transform(V3::new(max.x, max.y, max.z)),
        transform(V3::new(min.x, max.y, max.z)),
    );
    let shade = |k: f32| {
        Color32::from_rgba_unmultiplied(
            (color.to_srgba_unmultiplied()[0] as f32 * k) as u8,
            (color.to_srgba_unmultiplied()[1] as f32 * k) as u8,
            (color.to_srgba_unmultiplied()[2] as f32 * k) as u8,
            color.a(),
        )
    };
    face(faces, camera, [a, b, c, d], shade(0.82));
    face(faces, camera, [e, h, g, f], shade(1.0));
    face(faces, camera, [a, e, f, b], shade(0.70));
    face(faces, camera, [d, c, g, h], shade(0.90));
    face(faces, camera, [a, d, h, e], shade(0.78));
    face(faces, camera, [b, f, g, c], shade(0.88));
}
fn append_module_faces(
    faces: &mut Vec<Face>,
    camera: Camera,
    m: &Module,
    materials: &[MaterialData],
    selected: bool,
) {
    let x = m.x_mm as f32;
    let y = m.y_mm as f32;
    let z = m.z_mm as f32;
    let w = m.width_mm as f32;
    let h = m.height_mm as f32;
    let d = m.depth_mm as f32;
    let t = m.thickness_mm as f32;
    let base = material_color_for(&m.material, materials);
    let body = if selected {
        Color32::from_rgb(
            base.r().saturating_add(26),
            base.g().saturating_add(32),
            base.b().saturating_add(12),
        )
    } else {
        base
    };
    let zero = 0.0;
    let body_start = faces.len();
    for (a, b) in [
        (V3::new(x, y, z), V3::new(x + t, y + h, z + d)),
        (V3::new(x + w - t, y, z), V3::new(x + w, y + h, z + d)),
        (V3::new(x + t, y, z), V3::new(x + w - t, y + t, z + d)),
        (
            V3::new(x + t, y + t, z + d - 6.0),
            V3::new(x + w - t, y + h - t, z + d),
        ),
    ] {
        append_module_box(faces, camera, m, a, b, body, zero, zero);
    }
    if m.top_mode == 0 {
        append_module_box(
            faces,
            camera,
            m,
            V3::new(x + t, y + h - t, z),
            V3::new(x + w - t, y + h, z + d),
            body,
            zero,
            zero,
        );
    } else if m.top_mode == 2 {
        let rail = 80.0_f32.min(d / 3.);
        for zz in [z, z + d - rail] {
            append_module_box(
                faces,
                camera,
                m,
                V3::new(x + t, y + h - t, zz),
                V3::new(x + w - t, y + h, zz + rail),
                body,
                zero,
                zero,
            );
        }
    }
    let drawer_zone = if m.kind != ModuleKind::Drawer && m.drawer_count > 0 {
        m.internal_drawer_height
            .min(m.height_mm.saturating_sub(2 * m.thickness_mm)) as f32
    } else {
        0.
    };
    if drawer_zone > 0. {
        let count = m.drawer_count.min(12);
        let dh = drawer_zone / count as f32;
        let left = x + t + 13.;
        let right = x + w - t - 13.;
        for i in 0..count {
            let bottom = y + t + i as f32 * dh;
            let top = bottom + (dh - 20.).max(20.);
            let front = z + 35.;
            let back = z + d - 25.;
            for (a, b) in [
                (V3::new(left, bottom, front), V3::new(left + t, top, back)),
                (V3::new(right - t, bottom, front), V3::new(right, top, back)),
                (
                    V3::new(left + t, bottom, front),
                    V3::new(right - t, top, front + t),
                ),
                (
                    V3::new(left + t, bottom, back - t),
                    V3::new(right - t, top, back),
                ),
                (
                    V3::new(left, bottom, front),
                    V3::new(right, bottom + 6., back),
                ),
            ] {
                append_module_box(faces, camera, m, a, b, body, zero, zero);
            }
        }
    }
    let bay = (w - 2.0 * t - m.divider_count as f32 * t) / (m.divider_count + 1) as f32;
    for i in 0..m.divider_count {
        let xx = x + t + bay + (bay + t) * i as f32;
        append_module_box(
            faces,
            camera,
            m,
            V3::new(xx, y + t, z),
            V3::new(xx + t, y + h - t, z + d - 6.0),
            body,
            zero,
            zero,
        );
    }
    for j in 0..=m.divider_count {
        for i in 0..m.shelf_count {
            let yy = y
                + t
                + drawer_zone
                + (h - 2.0 * t - drawer_zone) * (i + 1) as f32 / (m.shelf_count + 1) as f32;
            let xx = x + t + (bay + t) * j as f32;
            append_module_box(
                faces,
                camera,
                m,
                V3::new(xx, yy, z + 20.0),
                V3::new(xx + bay, yy + t, z + d - 6.0),
                body,
                zero,
                zero,
            );
        }
    }

    visual::mark(&mut faces[body_start..], &m.material, materials, m.grain);
    fronts::draw(faces, camera, m, materials);
}

fn append_floor_tiles(
    faces: &mut Vec<Face>,
    camera: Camera,
    width: u32,
    depth: u32,
    texture: &str,
) {
    let base = match texture {
        "Madeira carvalho" => Color32::from_rgb(183, 143, 101),
        "Madeira freijó" => Color32::from_rgb(199, 154, 94),
        "Madeira nogueira" => Color32::from_rgb(112, 80, 56),
        "Madeira clara" => Color32::from_rgb(210, 189, 155),
        "Madeira escura" => Color32::from_rgb(105, 78, 60),
        "Mármore branco" => Color32::from_rgb(232, 229, 220),
        "Granito preto" => Color32::from_rgb(77, 79, 79),
        "Concreto queimado" => Color32::from_rgb(120, 122, 121),
        "Cerâmica terracota" => Color32::from_rgb(171, 99, 72),
        "Ardósia" => Color32::from_rgb(92, 101, 104),
        _ => Color32::from_rgb(212, 207, 195),
    };
    let wood = texture.contains("Madeira") || texture.contains("Taco");
    let sx = if wood { 1200.0 } else { 600.0 };
    let sz = if wood { 180.0 } else { 600.0 };
    let mut z = 0.0;
    let mut row = 0;
    while z < depth as f32 {
        let mut x = 0.0;
        let mut col = 0;
        while x < width as f32 {
            let x1 = (x + sx).min(width as f32);
            let z1 = (z + sz).min(depth as f32);
            let k = if (row + col) % 2 == 0 { 1.0 } else { 0.94 };
            let color = Color32::from_rgb(
                (base.r() as f32 * k) as u8,
                (base.g() as f32 * k) as u8,
                (base.b() as f32 * k) as u8,
            );
            face(
                faces,
                camera,
                [
                    V3::new(x, 1.0, z),
                    V3::new(x1, 1.0, z),
                    V3::new(x1, 1.0, z1),
                    V3::new(x, 1.0, z1),
                ],
                color,
            );
            x = x1;
            col += 1;
        }
        z += sz;
        row += 1;
    }
}
fn append_opening_faces(
    faces: &mut Vec<Face>,
    camera: Camera,
    w: &Wall,
    o: &Opening,
    materials: &[MaterialData],
) {
    let len = w.start.distance(w.end).max(1.0);
    let ux = (w.end.x - w.start.x) / len;
    let uz = (w.end.z - w.start.z) / len;
    let u0 = o.center_mm as f32 - o.width_mm as f32 / 2.0;
    let u1 = u0 + o.width_mm as f32;
    let side = -(w.thickness_mm as f32 / 2.0 + 3.0);
    let pt = |u: f32, y: f32| {
        V3::new(
            w.start.x + ux * u - uz * side,
            y,
            w.start.z + uz * u + ux * side,
        )
    };
    let frame = material_color_for(&o.material, materials);
    let jamb = 35.0_f32.min(o.width_mm as f32 / 6.0);
    append_wall_piece(
        faces,
        camera,
        w,
        u0,
        u0 + jamb,
        o.sill_mm as f32,
        (o.sill_mm + o.height_mm) as f32,
    );
    append_wall_piece(
        faces,
        camera,
        w,
        u1 - jamb,
        u1,
        o.sill_mm as f32,
        (o.sill_mm + o.height_mm) as f32,
    );
    append_wall_piece(
        faces,
        camera,
        w,
        u0,
        u1,
        (o.sill_mm + o.height_mm) as f32 - 35.0,
        (o.sill_mm + o.height_mm) as f32,
    );
    let is_glass = o.style.contains("Vidro") || o.kind == OpeningKind::Window;
    let color = if is_glass {
        Color32::from_rgba_unmultiplied(139, 194, 208, 190)
    } else {
        material_color_for(&o.material, materials)
    };
    let points = [
        pt(u0 + jamb, o.sill_mm as f32),
        pt(u1 - jamb, o.sill_mm as f32),
        pt(u1 - jamb, (o.sill_mm + o.height_mm) as f32 - 35.0),
        pt(u0 + jamb, (o.sill_mm + o.height_mm) as f32 - 35.0),
    ];
    face(faces, camera, points, color);
    if o.kind == OpeningKind::Window
        && !o.style.starts_with("Fixa")
        && !o.style.starts_with("Panorâmica")
    {
        let mid = (u0 + u1) / 2.0;
        face(
            faces,
            camera,
            [
                pt(mid - 8.0, o.sill_mm as f32),
                pt(mid + 8.0, o.sill_mm as f32),
                pt(mid + 8.0, (o.sill_mm + o.height_mm) as f32 - 35.0),
                pt(mid - 8.0, (o.sill_mm + o.height_mm) as f32 - 35.0),
            ],
            frame,
        );
    }
    let bottom = o.sill_mm as f32;
    let top = (o.sill_mm + o.height_mm) as f32 - 35.;
    let rail = |faces: &mut Vec<Face>, a: f32, b: f32, low: f32, high: f32| {
        face(
            faces,
            camera,
            [pt(a, low), pt(b, low), pt(b, high), pt(a, high)],
            frame,
        )
    };
    if o.style.contains("Veneziana") {
        let mut y = bottom + 30.;
        while y < top - 20. {
            rail(faces, u0 + jamb, u1 - jamb, y, y + 18.);
            y += 45.;
        }
    } else if o.style.contains("Basculante")
        || o.style.contains("Maxim-ar")
        || o.style.contains("Perfil horizontal")
    {
        for fraction in [0.33, 0.66] {
            let y = bottom + (top - bottom) * fraction;
            rail(faces, u0 + jamb, u1 - jamb, y - 7., y + 7.);
        }
    } else if o.style.contains("Provençal") {
        let inset = 80.0_f32.min(o.width_mm as f32 / 5.);
        for x in [u0 + inset, u1 - inset - 20.] {
            rail(faces, x, x + 20., bottom + inset, top - inset);
        }
        for y in [bottom + inset, (bottom + top) / 2., top - inset - 20.] {
            rail(faces, u0 + inset, u1 - inset, y, y + 20.);
        }
    } else if o.style.contains("Perfil vertical") {
        for fraction in [0.33, 0.66] {
            let x = u0 + (u1 - u0) * fraction;
            rail(faces, x - 7., x + 7., bottom, top);
        }
    }
}

fn scene_faces(
    camera: Camera,
    room: [u32; 3],
    walls: &[Wall],
    openings: &[Opening],
    modules: &[Module],
    panels: &[WoodPanel],
    gesso: &[GessoBlock],
    decor: &[DecorItem],
    materials: &[MaterialData],
    hidden: &[u32],
    floor_texture: &str,
) -> Vec<Face> {
    let mut faces = Vec::new();
    if !hidden.contains(&u32::MAX) {
        append_floor_tiles(&mut faces, camera, room[0], room[2], floor_texture);
    }
    for w in walls.iter().filter(|w| !hidden.contains(&w.id)) {
        let os: Vec<Opening> = openings
            .iter()
            .filter(|o| o.wall_id == w.id)
            .cloned()
            .collect();
        append_wall_faces(&mut faces, camera, w, &os);
        for o in os.iter().filter(|o| !hidden.contains(&o.id)) {
            append_opening_faces(&mut faces, camera, w, o, materials);
        }
    }
    for m in modules.iter().filter(|m| !hidden.contains(&m.id)) {
        append_module_faces(&mut faces, camera, m, materials, false);
    }
    for b in panels.iter().filter(|b| !hidden.contains(&b.id)) {
        automation::panel_faces(&mut faces, camera, b, materials);
    }
    for g in gesso.iter().filter(|g| !hidden.contains(&g.id)) {
        let y = (room[1].saturating_sub(g.drop_mm)) as f32;
        append_box(
            &mut faces,
            camera,
            V3::new(g.x_mm as f32, y, g.z_mm as f32),
            V3::new(
                (g.x_mm + g.width_mm) as f32,
                y + g.thickness_mm as f32,
                (g.z_mm + g.depth_mm) as f32,
            ),
            Color32::from_rgb(207, 194, 219),
        );
    }
    for d in decor.iter().filter(|d| !hidden.contains(&d.id)) {
        designers::decor_faces(&mut faces, camera, d);
    }
    faces.sort_by(|a, b| a.depth.total_cmp(&b.depth));
    faces
}
fn draw_scene(
    p: &egui::Painter,
    rect: Rect,
    camera: Camera,
    room: [u32; 3],
    walls: &[Wall],
    openings: &[Opening],
    modules: &[Module],
    panels: &[WoodPanel],
    gesso: &[GessoBlock],
    decor: &[DecorItem],
    materials: &[MaterialData],
    hidden: &[u32],
    floor_texture: &str,
    selected: Option<Selection>,
    mode: RenderMode,
    cutaway: bool,
) {
    p.rect_filled(rect, 0.0, Color32::from_rgb(235, 238, 240));
    let face_materials: &[MaterialData] = if mode == RenderMode::Colors {
        &[]
    } else {
        materials
    };
    let visible_walls: Vec<_> = walls
        .iter()
        .filter(|w| !cutaway || visual::visible_wall(w, camera, room))
        .cloned()
        .collect();
    let faces = scene_faces(
        camera,
        room,
        &visible_walls,
        openings,
        modules,
        panels,
        gesso,
        decor,
        face_materials,
        hidden,
        floor_texture,
    );
    if mode == RenderMode::Wireframe {
        for f in &faces {
            let pts = camera.project_polygon(&f.points, rect);
            for i in 0..pts.len() {
                p.line_segment(
                    [pts[i], pts[(i + 1) % pts.len()]],
                    Stroke::new(0.8, Color32::DARK_GRAY),
                );
            }
        }
    } else {
        visual::paint(p, rect, &faces, camera, mode);
    }
    if let Some(Selection::Module(id)) = selected {
        if let Some(m) = modules.iter().find(|m| m.id == id) {
            let corners = module_corners(m);
            for i in 0..4 {
                for y in [m.y_mm as f32, (m.y_mm + m.height_mm) as f32] {
                    if let (Some((a, _, _)), Some((b, _, _))) = (
                        camera.project(V3::new(corners[i].x, y, corners[i].z), rect),
                        camera.project(
                            V3::new(corners[(i + 1) % 4].x, y, corners[(i + 1) % 4].z),
                            rect,
                        ),
                    ) {
                        p.line_segment([a, b], Stroke::new(2.5, GREEN));
                    }
                }
                if let (Some((a, _, _)), Some((b, _, _))) = (
                    camera.project(V3::new(corners[i].x, m.y_mm as f32, corners[i].z), rect),
                    camera.project(
                        V3::new(corners[i].x, (m.y_mm + m.height_mm) as f32, corners[i].z),
                        rect,
                    ),
                ) {
                    p.line_segment([a, b], Stroke::new(2.5, GREEN));
                }
            }
            p.text(
                rect.left_top() + Vec2::new(12.0, 12.0),
                egui::Align2::LEFT_TOP,
                format!(
                    "{} · {} × {} × {} mm",
                    m.name, m.width_mm, m.height_mm, m.depth_mm
                ),
                egui::FontId::proportional(13.0),
                GREEN,
            );
        }
    } else if let Some(s) = selected {
        p.text(
            rect.left_top() + Vec2::new(12.0, 12.0),
            egui::Align2::LEFT_TOP,
            format!("Selecionado: {s:?}"),
            egui::FontId::proportional(12.0),
            GREEN,
        );
    }
    p.text(
        rect.left_top() + Vec2::new(12.0, 32.0),
        egui::Align2::LEFT_TOP,
        format!(
            "{} × {} × {} mm  ·  Piso: {}",
            room[0], room[1], room[2], floor_texture
        ),
        egui::FontId::proportional(12.0),
        Color32::DARK_GRAY,
    );
}
fn svg_hex(c: Color32) -> String {
    format!("#{:02x}{:02x}{:02x}", c.r(), c.g(), c.b())
}
fn scene_view_svg(
    room: [u32; 3],
    walls: &[Wall],
    openings: &[Opening],
    modules: &[Module],
    panels: &[WoodPanel],
    gesso: &[GessoBlock],
    decor: &[DecorItem],
    materials: &[MaterialData],
    hidden: &[u32],
    floor: &str,
    camera: Camera,
    mode: RenderMode,
) -> String {
    let width = 1200.0;
    let height = 800.0;
    let rect = Rect::from_min_size(Pos2::ZERO, Vec2::new(width, height));
    let mut s=format!("<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='800' viewBox='0 0 1200 800'><rect width='1200' height='800' fill='#f4f5f5'/><text x='24' y='32' font-family='sans-serif' font-size='18'>Vista do ambiente · {} × {} × {} mm · {}</text>",room[0],room[1],room[2],floor);
    let face_materials: &[MaterialData] = if mode == RenderMode::Colors {
        &[]
    } else {
        materials
    };
    for f in scene_faces(
        camera,
        room,
        walls,
        openings,
        modules,
        panels,
        gesso,
        decor,
        face_materials,
        hidden,
        floor,
    ) {
        let pts = camera.project_polygon(&f.points, rect);
        if pts.len() < 3 {
            continue;
        }
        let color = svg_hex(f.color);
        let points = pts
            .iter()
            .map(|p| format!("{:.2},{:.2}", p.x, p.y))
            .collect::<Vec<_>>()
            .join(" ");
        if mode == RenderMode::Wireframe {
            s.push_str(&format!(
                "<polygon points='{points}' fill='none' stroke='#333333' stroke-width='1'/>"
            ));
        } else {
            s.push_str(&format!(
                "<polygon points='{points}' fill='{color}' stroke='#464646' stroke-width='0.7'/>"
            ));
        }
    }
    s.push_str("</svg>");
    s
}
fn sheet_svg(app: &FurnitureApp) -> String {
    documentation::svg(app)
}

fn xml_escape(t: &str) -> String {
    t.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
}
fn pick_scene_any(
    p: Pos2,
    rect: Rect,
    camera: Camera,
    modules: &[Module],
    decor: &[DecorItem],
    hidden: &[u32],
) -> Option<Selection> {
    if let Some(id) = pick_module(p, rect, camera, modules, hidden) {
        return Some(Selection::Module(id));
    }
    decor
        .iter()
        .rev()
        .filter(|d| !hidden.contains(&d.id))
        .find(|d| {
            let pts = [
                V3::new(d.x_mm as f32, d.y_mm as f32, d.z_mm as f32),
                V3::new(
                    (d.x_mm + d.width_mm) as f32,
                    (d.y_mm + d.height_mm) as f32,
                    (d.z_mm + d.depth_mm) as f32,
                ),
            ];
            if let (Some(a), Some(b)) = (camera.project(pts[0], rect), camera.project(pts[1], rect))
            {
                Rect::from_two_pos(a.0, b.0).expand(12.0).contains(p)
            } else {
                false
            }
        })
        .map(|d| Selection::Decor(d.id))
}
fn pick_module(
    p: Pos2,
    rect: Rect,
    camera: Camera,
    modules: &[Module],
    hidden: &[u32],
) -> Option<u32> {
    visual::pick(p, rect, camera, modules, hidden)
}

#[cfg(test)]
fn ifc_for_project(
    room: [u32; 3],
    walls: &[Wall],
    openings: &[Opening],
    modules: &[Module],
    panels: &[WoodPanel],
    gesso: &[GessoBlock],
    decor: &[DecorItem],
) -> String {
    let mut app = FurnitureApp::default();
    app.room = room;
    app.walls = walls.to_vec();
    app.openings = openings.to_vec();
    app.modules = modules.to_vec();
    app.panels = panels.to_vec();
    app.gesso = gesso.to_vec();
    app.decor = decor.to_vec();
    ifc::project(&app)
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if bridge::run(&args) {
        return;
    }
    if args.get(1).map(String::as_str) == Some("--example-project") {
        fs::write(
            args.get(2).expect("caminho .mar"),
            project_to_mar(&FurnitureApp::default()),
        )
        .expect("salvar exemplo");
        return;
    }
    if args.get(1).map(String::as_str) == Some("--example-ifc") {
        let mut app = FurnitureApp::default();
        app.openings.push(Opening {
            id: 20,
            wall_id: 5,
            kind: OpeningKind::Door,
            center_mm: 1000,
            width_mm: 800,
            height_mm: 2100,
            sill_mm: 0,
            style: "Lisa".into(),
            material: "MDF branco".into(),
        });
        app.openings.push(Opening {
            id: 21,
            wall_id: 6,
            kind: OpeningKind::Window,
            center_mm: 1500,
            width_mm: 1200,
            height_mm: 1000,
            sill_mm: 900,
            style: "Vidro".into(),
            material: "Vidro".into(),
        });
        fs::write(args.get(2).expect("caminho IFC"), ifc::project(&app)).expect("exportar IFC");
        return;
    }
    if args.get(1).map(String::as_str) == Some("--render-demo") {
        let mut app = FurnitureApp::default();
        app.room = [8200, 2700, 3200];
        app.walls.clear();
        app.modules.clear();
        for (i, style) in [
            DoorStyle::Plain,
            DoorStyle::Provincial,
            DoorStyle::Horizontal,
            DoorStyle::Vertical,
            DoorStyle::Cava,
            DoorStyle::Glass,
            DoorStyle::Aluminum,
            DoorStyle::GlassHorizontal,
            DoorStyle::GlassVertical,
        ]
        .iter()
        .enumerate()
        {
            let mut m = make_module(
                i as u32 + 1,
                preset(
                    "Demonstração",
                    ModuleKind::Base,
                    800,
                    1100,
                    550,
                    100,
                    2,
                    2,
                    0,
                ),
                200 + i as u32 * 1100,
                1400,
            );
            m.door_style = *style;
            m.door_styles = vec![*style; 2];
            app.modules.push(m);
        }
        app.camera = Camera {
            target: V3::new(3900., 800., 1500.),
            yaw: 3.14,
            pitch: 0.16,
            distance: 12500.,
            projection: Projection::Perspective,
        };
        visual::save(&app, args.get(2).expect("caminho PNG")).expect("renderizar demonstração");
        return;
    }
    if args.get(1).map(String::as_str) == Some("--example-sheet") {
        let mut app = FurnitureApp::default();
        app.sheet_title = "Projeto demonstrativo".into();
        app.sheet_options.notes = "Conferir medidas no local antes da fabricação".into();
        let path = args.get(2).expect("caminho do SVG");
        if path.ends_with(".pdf") {
            fs::write(path, documentation::pdf(&app)).expect("exportar PDF");
        } else {
            write_file(path, &sheet_svg(&app)).expect("exportar SVG");
        }
        return;
    }
    let icon = image::load_from_memory(include_bytes!("../assets/logo.png"))
        .expect("logo bundled")
        .to_rgba8();
    let icon_data = egui::IconData {
        rgba: icon.as_raw().to_vec(),
        width: icon.width(),
        height: icon.height(),
    };
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1440.0, 940.0])
            .with_min_inner_size([1000.0, 760.0])
            .with_icon(std::sync::Arc::new(icon_data)),
        ..Default::default()
    };
    let _ = eframe::run_native(
        "Marcenaria Livre",
        options,
        Box::new(|_cc| Box::new(FurnitureApp::default())),
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn wall_projection_is_clamped() {
        let w = Wall {
            material: "Pintura branca".into(),
            color: Color32::from_rgb(220, 221, 218),
            id: 1,
            start: P2::new(0.0, 0.0),
            end: P2::new(1000.0, 0.0),
            thickness_mm: 150,
            height_mm: 2700,
        };
        assert_eq!(project_to_wall(P2::new(400.0, 100.0), &w).0, 400.0);
        assert_eq!(project_to_wall(P2::new(1200.0, 0.0), &w).0, 1000.0);
    }
    #[test]
    fn custom_module_produces_parts() {
        let m = make_module(
            1,
            preset("Teste", ModuleKind::Custom, 900, 800, 550, 0, 2, 2, 0),
            0,
            0,
        );
        assert!(parts_for_module(&m).iter().any(|p| p.name == "Porta"));
        assert!(parts_for_module(&m).iter().any(|p| p.name == "Prateleira"));
    }
    #[test]
    fn csv_quotes_semicolon_and_quotes() {
        assert_eq!(
            csv_escape("madeira; \"clara\""),
            "\"madeira; \"\"clara\"\"\""
        );
    }
    #[test]
    fn camera_projects_world_points() {
        let c = Camera::reset([4200, 2700, 3200]);
        assert!(c
            .project(
                V3::new(100.0, 100.0, 100.0),
                Rect::from_min_size(Pos2::ZERO, Vec2::new(800.0, 600.0))
            )
            .is_some());
    }
    #[test]
    fn method_changes_cutlist_thicknesses() {
        let m = make_module(
            1,
            preset("Teste", ModuleKind::Custom, 900, 800, 550, 0, 2, 2, 0),
            0,
            0,
        );
        let parts = parts_for_module_configured(&m, 25, 9, 4, "PVC 1 mm", "Encaixado");
        assert_eq!(
            parts
                .iter()
                .find(|p| p.name == "Base e tampo")
                .unwrap()
                .thickness_mm,
            25
        );
        assert_eq!(
            parts
                .iter()
                .find(|p| p.name == "Fundo")
                .unwrap()
                .thickness_mm,
            9
        );
    }
    #[test]
    fn automation_is_not_added_twice() {
        let mut app = FurnitureApp::default();
        app.run_automation("Tampo");
        let before = app.panels.len();
        app.run_automation("Tampo");
        assert_eq!(app.panels.len(), before);
    }
    #[test]
    fn wall_snap_aligns_module_to_wall() {
        let wall = Wall {
            material: "Pintura branca".into(),
            color: Color32::from_rgb(220, 221, 218),
            id: 1,
            start: P2::new(0.0, 0.0),
            end: P2::new(4200.0, 0.0),
            thickness_mm: 150,
            height_mm: 2700,
        };
        let mut m = make_module(
            1,
            preset("Teste", ModuleKind::Base, 800, 720, 550, 0, 2, 1, 0),
            1600,
            250,
        );
        snap_module_to_wall(&mut m, &[wall], [4200, 2700, 3200]);
        assert!((m.z_mm as i32 - 625).abs() < 2);
        assert!((m.rotation_deg.abs() - 180.0).abs() < 1.0);
    }
    #[test]
    fn door_window_and_material_libraries_have_twenty_entries() {
        assert_eq!(opening_presets(OpeningKind::Door).len(), 20);
        assert_eq!(opening_presets(OpeningKind::Window).len(), 20);
        assert!(default_materials().len() >= 120);
    }
    #[test]
    fn ifc_contains_spatial_model_and_solid_geometry() {
        let app = FurnitureApp::default();
        let text = ifc_for_project(
            app.room,
            &app.walls,
            &app.openings,
            &app.modules,
            &app.panels,
            &app.gesso,
            &app.decor,
        );
        assert!(text.starts_with("ISO-10303-21;"));
        assert!(text.contains("IFCPROJECT"));
        assert!(text.contains("IFCEXTRUDEDAREASOLID"));
        assert!(text.ends_with("END-ISO-10303-21;\n"));
        let mut ids = std::collections::HashSet::new();
        for line in text.lines().filter(|line| line.starts_with('#')) {
            let id = line.split('=').next().unwrap();
            assert!(ids.insert(id.to_string()), "duplicate IFC id {id}");
        }
    }
    #[test]
    fn decor_is_excluded_from_millwork_parts() {
        let mut app = FurnitureApp::default();
        app.add_decor("Cadeira", 450, 900, 450, Color32::GRAY);
        assert!(app.parts().iter().all(|part| part.name != "Cadeira"));
    }
}

#[cfg(test)]
mod regression;

fn project_identity() -> u64 {
    let time = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos();
    (time as u64) ^ ((std::process::id() as u64) << 32)
}

fn extra_presets(tab: CatalogTab) -> Vec<Preset> {
    match tab {
        CatalogTab::Kitchen => vec![
            preset(
                "Cozinha sem topo 400",
                ModuleKind::Base,
                400,
                720,
                550,
                0,
                1,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 450",
                ModuleKind::Base,
                450,
                720,
                550,
                0,
                1,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 500",
                ModuleKind::Base,
                500,
                720,
                550,
                0,
                1,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 550",
                ModuleKind::Base,
                550,
                720,
                550,
                0,
                1,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 600",
                ModuleKind::Base,
                600,
                720,
                550,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 650",
                ModuleKind::Base,
                650,
                720,
                550,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 700",
                ModuleKind::Base,
                700,
                720,
                550,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 750",
                ModuleKind::Base,
                750,
                720,
                550,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 800",
                ModuleKind::Base,
                800,
                720,
                550,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 850",
                ModuleKind::Base,
                850,
                720,
                550,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 900",
                ModuleKind::Base,
                900,
                720,
                550,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 1000",
                ModuleKind::Base,
                1000,
                720,
                550,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 1100",
                ModuleKind::Base,
                1100,
                720,
                550,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 1200",
                ModuleKind::Base,
                1200,
                720,
                550,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Cozinha sem topo 1400",
                ModuleKind::Base,
                1400,
                720,
                550,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Nicho forno 600 × 600",
                ModuleKind::OpenShelf,
                600,
                600,
                600,
                0,
                0,
                0,
                0,
            ),
            preset(
                "Nicho forno 600 × 720",
                ModuleKind::OpenShelf,
                600,
                720,
                600,
                0,
                0,
                0,
                0,
            ),
            preset(
                "Nicho forno 650 × 600",
                ModuleKind::OpenShelf,
                650,
                600,
                600,
                0,
                0,
                0,
                0,
            ),
            preset(
                "Nicho forno 650 × 720",
                ModuleKind::OpenShelf,
                650,
                720,
                600,
                0,
                0,
                0,
                0,
            ),
            preset(
                "Nicho forno 700 × 600",
                ModuleKind::OpenShelf,
                700,
                600,
                600,
                0,
                0,
                0,
                0,
            ),
            preset(
                "Nicho forno 700 × 720",
                ModuleKind::OpenShelf,
                700,
                720,
                600,
                0,
                0,
                0,
                0,
            ),
            preset(
                "Nicho forno 750 × 600",
                ModuleKind::OpenShelf,
                750,
                600,
                600,
                0,
                0,
                0,
                0,
            ),
            preset(
                "Nicho forno 750 × 720",
                ModuleKind::OpenShelf,
                750,
                720,
                600,
                0,
                0,
                0,
                0,
            ),
            preset(
                "Nicho forno 800 × 600",
                ModuleKind::OpenShelf,
                800,
                600,
                600,
                0,
                0,
                0,
                0,
            ),
            preset(
                "Nicho forno 800 × 720",
                ModuleKind::OpenShelf,
                800,
                720,
                600,
                0,
                0,
                0,
                0,
            ),
        ],
        CatalogTab::Bathroom => vec![
            preset(
                "Banheiro sem topo 400",
                ModuleKind::Base,
                400,
                720,
                450,
                0,
                1,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 450",
                ModuleKind::Base,
                450,
                720,
                450,
                0,
                1,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 500",
                ModuleKind::Base,
                500,
                720,
                450,
                0,
                1,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 550",
                ModuleKind::Base,
                550,
                720,
                450,
                0,
                1,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 600",
                ModuleKind::Base,
                600,
                720,
                450,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 650",
                ModuleKind::Base,
                650,
                720,
                450,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 700",
                ModuleKind::Base,
                700,
                720,
                450,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 750",
                ModuleKind::Base,
                750,
                720,
                450,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 800",
                ModuleKind::Base,
                800,
                720,
                450,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 850",
                ModuleKind::Base,
                850,
                720,
                450,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 900",
                ModuleKind::Base,
                900,
                720,
                450,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 1000",
                ModuleKind::Base,
                1000,
                720,
                450,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 1100",
                ModuleKind::Base,
                1100,
                720,
                450,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 1200",
                ModuleKind::Base,
                1200,
                720,
                450,
                0,
                2,
                0,
                0,
            ),
            preset(
                "Banheiro sem topo 1400",
                ModuleKind::Base,
                1400,
                720,
                450,
                0,
                2,
                0,
                0,
            ),
        ],
        CatalogTab::Office => vec![
            preset(
                "Arquivo baixo 600",
                ModuleKind::Base,
                600,
                740,
                450,
                0,
                2,
                1,
                0,
            ),
            preset(
                "Arquivo baixo 800",
                ModuleKind::Base,
                800,
                740,
                450,
                0,
                2,
                1,
                0,
            ),
            preset(
                "Arquivo baixo 1000",
                ModuleKind::Base,
                1000,
                740,
                450,
                0,
                2,
                1,
                0,
            ),
            preset(
                "Arquivo baixo 1200",
                ModuleKind::Base,
                1200,
                740,
                450,
                0,
                2,
                1,
                0,
            ),
            preset(
                "Arquivo baixo 1400",
                ModuleKind::Base,
                1400,
                740,
                450,
                0,
                2,
                1,
                0,
            ),
            preset(
                "Arquivo alto 600",
                ModuleKind::Tall,
                600,
                2100,
                450,
                0,
                2,
                5,
                0,
            ),
            preset(
                "Arquivo alto 800",
                ModuleKind::Tall,
                800,
                2100,
                450,
                0,
                2,
                5,
                0,
            ),
            preset(
                "Arquivo alto 1000",
                ModuleKind::Tall,
                1000,
                2100,
                450,
                0,
                2,
                5,
                0,
            ),
            preset(
                "Arquivo alto 1200",
                ModuleKind::Tall,
                1200,
                2100,
                450,
                0,
                2,
                5,
                0,
            ),
            preset(
                "Arquivo alto 1400",
                ModuleKind::Tall,
                1400,
                2100,
                450,
                0,
                2,
                5,
                0,
            ),
            preset(
                "Biblioteca 600",
                ModuleKind::OpenShelf,
                600,
                1800,
                350,
                0,
                0,
                5,
                0,
            ),
            preset(
                "Biblioteca 800",
                ModuleKind::OpenShelf,
                800,
                1800,
                350,
                0,
                0,
                5,
                0,
            ),
            preset(
                "Biblioteca 1000",
                ModuleKind::OpenShelf,
                1000,
                1800,
                350,
                0,
                0,
                5,
                0,
            ),
            preset(
                "Biblioteca 1200",
                ModuleKind::OpenShelf,
                1200,
                1800,
                350,
                0,
                0,
                5,
                0,
            ),
            preset(
                "Biblioteca 1400",
                ModuleKind::OpenShelf,
                1400,
                1800,
                350,
                0,
                0,
                5,
                0,
            ),
            preset(
                "Gaveteiro 350",
                ModuleKind::Drawer,
                350,
                700,
                550,
                0,
                0,
                0,
                4,
            ),
            preset(
                "Gaveteiro 400",
                ModuleKind::Drawer,
                400,
                700,
                550,
                0,
                0,
                0,
                4,
            ),
            preset(
                "Gaveteiro 450",
                ModuleKind::Drawer,
                450,
                700,
                550,
                0,
                0,
                0,
                4,
            ),
            preset(
                "Gaveteiro 500",
                ModuleKind::Drawer,
                500,
                700,
                550,
                0,
                0,
                0,
                4,
            ),
            preset(
                "Gaveteiro 600",
                ModuleKind::Drawer,
                600,
                700,
                550,
                0,
                0,
                0,
                4,
            ),
        ],
        _ => vec![],
    }
}
