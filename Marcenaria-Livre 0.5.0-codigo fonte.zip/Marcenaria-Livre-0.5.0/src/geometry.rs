use super::*;
#[derive(Clone)]
pub struct Designer {
    pub points: Vec<P2>,
    pub height: u32,
    pub width: u32,
    pub depth: u32,
    pub x: u32,
    pub y: u32,
    pub z: u32,
    pub closed: bool,
}
impl Default for Designer {
    fn default() -> Self {
        Self {
            points: vec![],
            height: 300,
            width: 1000,
            depth: 1000,
            x: 300,
            y: 0,
            z: 300,
            closed: false,
        }
    }
}
fn cross(a: P2, b: P2, c: P2) -> f32 {
    (b.x - a.x) * (c.z - a.z) - (b.z - a.z) * (c.x - a.x)
}
pub fn triangulate(points: &[P2]) -> Option<Vec<[usize; 3]>> {
    let n = points.len();
    if n < 3 || n > 256 {
        return None;
    }
    for i in 0..n {
        if points[i].distance(points[(i + 1) % n]) < 0.00001 {
            return None;
        }
        for j in i + 1..n {
            if j == i + 1 || (i == 0 && j == n - 1) {
                continue;
            }
            let (a, b, c, d) = (
                points[i],
                points[(i + 1) % n],
                points[j],
                points[(j + 1) % n],
            );
            if cross(a, b, c) * cross(a, b, d) <= 0. && cross(c, d, a) * cross(c, d, b) <= 0. {
                return None;
            }
        }
    }
    let area = (0..n)
        .map(|i| points[i].x * points[(i + 1) % n].z - points[(i + 1) % n].x * points[i].z)
        .sum::<f32>();
    if area.abs() < 0.00001 {
        return None;
    }
    let mut indices: Vec<_> = if area > 0. {
        (0..n).collect()
    } else {
        (0..n).rev().collect()
    };
    let mut triangles = vec![];
    while indices.len() > 3 {
        let mut found = false;
        for i in 0..indices.len() {
            let tri = [
                indices[(i + indices.len() - 1) % indices.len()],
                indices[i],
                indices[(i + 1) % indices.len()],
            ];
            let [a, b, c] = tri.map(|j| points[j]);
            if cross(a, b, c) <= 0.000001 {
                continue;
            }
            if indices.iter().filter(|j| !tri.contains(j)).any(|j| {
                let p = points[*j];
                cross(a, b, p) >= 0. && cross(b, c, p) >= 0. && cross(c, a, p) >= 0.
            }) {
                continue;
            }
            triangles.push(tri);
            indices.remove(i);
            found = true;
            break;
        }
        if !found {
            return None;
        }
    }
    triangles.push([indices[0], indices[1], indices[2]]);
    Some(triangles)
}
pub fn footprint(d: &DecorItem) -> Vec<P2> {
    let raw = if d.outline.len() >= 3 {
        d.outline.clone()
    } else {
        vec![
            P2::new(0., 0.),
            P2::new(1., 0.),
            P2::new(1., 1.),
            P2::new(0., 1.),
        ]
    };
    let (s, c) = d.rotation_deg.to_radians().sin_cos();
    raw.into_iter()
        .map(|p| {
            let (x, z) = (p.x * d.width_mm as f32, p.z * d.depth_mm as f32);
            P2::new(d.x_mm as f32 + c * x - s * z, d.z_mm as f32 + s * x + c * z)
        })
        .collect()
}
pub fn faces(out: &mut Vec<Face>, camera: Camera, d: &DecorItem) {
    let Some(tris) = triangulate(&d.outline) else {
        return;
    };
    let points = footprint(d);
    let lo = d.y_mm as f32;
    let hi = lo + d.height_mm as f32;
    for t in tris {
        let [a, b, c] = t.map(|i| points[i]);
        for y in [lo, hi] {
            face(
                out,
                camera,
                [
                    V3::new(a.x, y, a.z),
                    V3::new(b.x, y, b.z),
                    V3::new(c.x, y, c.z),
                    V3::new(c.x, y, c.z),
                ],
                d.color,
            );
        }
    }
    for i in 0..points.len() {
        let (a, b) = (points[i], points[(i + 1) % points.len()]);
        face(
            out,
            camera,
            [
                V3::new(a.x, lo, a.z),
                V3::new(b.x, lo, b.z),
                V3::new(b.x, hi, b.z),
                V3::new(a.x, hi, a.z),
            ],
            d.color,
        );
    }
}
impl FurnitureApp {
    pub fn geometry_designer(&mut self, ui: &mut egui::Ui) {
        ui.heading("Criador de geometria decorativa");
        ui.label("Desenhe o contorno por cliques, feche a forma e arraste a prévia para empurrar/puxar. Não modifica módulos.");
        ui.horizontal(|ui| {
            if ui.button("Fechar contorno").clicked() {
                self.geometry.closed = triangulate(&self.geometry.points).is_some();
                if !self.geometry.closed {
                    self.notice = "Use pelo menos três pontos e evite cruzar as linhas.".into();
                }
            }
            if ui.button("Voltar um ponto").clicked() {
                self.geometry.points.pop();
                self.geometry.closed = false;
            }
            if ui.button("Limpar").clicked() {
                self.geometry.points.clear();
                self.geometry.closed = false;
            }
        });
        ui.columns(2, |cols| {
            let width = cols[0].available_width();
            let (r, response) = cols[0].allocate_exact_size(Vec2::new(width, 300.), Sense::click());
            let p = cols[0].painter_at(r);
            p.rect_filled(r, 0., Color32::WHITE);
            for i in 0..=10 {
                let x = r.left() + r.width() * i as f32 / 10.;
                let z = r.top() + r.height() * i as f32 / 10.;
                p.line_segment(
                    [Pos2::new(x, r.top()), Pos2::new(x, r.bottom())],
                    Stroke::new(1., GRID),
                );
                p.line_segment(
                    [Pos2::new(r.left(), z), Pos2::new(r.right(), z)],
                    Stroke::new(1., GRID),
                );
            }
            if response.clicked() && !self.geometry.closed {
                if let Some(pos) = response.interact_pointer_pos() {
                    self.geometry.points.push(P2::new(
                        ((pos.x - r.left()) / r.width() * 20.).round() / 20.,
                        ((pos.y - r.top()) / r.height() * 20.).round() / 20.,
                    ));
                }
            }
            let screen: Vec<_> = self
                .geometry
                .points
                .iter()
                .map(|v| Pos2::new(r.left() + v.x * r.width(), r.top() + v.z * r.height()))
                .collect();
            for pair in screen.windows(2) {
                p.line_segment([pair[0], pair[1]], Stroke::new(2., GREEN));
            }
            for q in &screen {
                p.circle_filled(*q, 4., GREEN);
            }
            if self.geometry.closed {
                p.line_segment([*screen.last().unwrap(), screen[0]], Stroke::new(2., GREEN));
            }
            let width = cols[1].available_width();
            let (r, response) = cols[1].allocate_exact_size(Vec2::new(width, 300.), Sense::drag());
            if self.geometry.closed {
                if response.dragged() {
                    self.geometry.height = (self.geometry.height as f32
                        - cols[1].ctx().input(|i| i.pointer.delta().y) * 3.)
                        .clamp(1., 5000.) as u32;
                }
                let mut d = self.geometry_object(0);
                d.x_mm = 0;
                d.y_mm = 0;
                d.z_mm = 0;
                let cam = Camera {
                    target: V3::new(
                        d.width_mm as f32 / 2.,
                        d.height_mm as f32 / 2.,
                        d.depth_mm as f32 / 2.,
                    ),
                    yaw: 3.7,
                    pitch: 0.5,
                    distance: d.width_mm.max(d.height_mm).max(d.depth_mm) as f32 * 7.,
                    projection: Projection::Perspective,
                };
                let mut mesh = vec![];
                faces(&mut mesh, cam, &d);
                visual::paint(&cols[1].painter_at(r), r, &mesh, cam, RenderMode::Colors);
            }
        });
        ui.horizontal_wrapped(|ui| {
            let d = &mut self.geometry;
            for (label, value) in [
                ("Largura", &mut d.width),
                ("Profundidade", &mut d.depth),
                ("Extrusão", &mut d.height),
                ("X", &mut d.x),
                ("Y", &mut d.y),
                ("Z", &mut d.z),
            ] {
                ui.label(label);
                ui.add(
                    egui::DragValue::new(value)
                        .clamp_range(1..=20000)
                        .suffix(" mm"),
                );
            }
        });
        if ui
            .add_enabled(
                self.geometry.closed,
                egui::Button::new("Criar sólido decorativo"),
            )
            .clicked()
        {
            let d = self.geometry_object(self.next_id);
            self.next_id += 1;
            self.selected = Some(Selection::Decor(d.id));
            self.editing.selection.clear();
            self.decor.push(d);
            self.page = Page::Scene;
        }
        ui.label(&self.notice);
    }
    fn geometry_object(&self, id: u32) -> DecorItem {
        let d = &self.geometry;
        DecorItem {
            id,
            outline: d.points.clone(),
            rotation_deg: 0.,
            name: "Geometria decorativa extrudada".into(),
            material: "Pintura".into(),
            x_mm: d.x,
            y_mm: d.y,
            z_mm: d.z,
            width_mm: d.width,
            height_mm: d.height,
            depth_mm: d.depth,
            color: Color32::from_rgb(138, 182, 171),
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn concave_outline() {
        let p = [
            P2::new(0., 0.),
            P2::new(1., 0.),
            P2::new(1., 0.5),
            P2::new(0.5, 0.5),
            P2::new(0.5, 1.),
            P2::new(0., 1.),
        ];
        assert_eq!(triangulate(&p).unwrap().len(), 4);
    }
    #[test]
    fn crossing_rejected() {
        assert!(triangulate(&[
            P2::new(0., 0.),
            P2::new(1., 1.),
            P2::new(1., 0.),
            P2::new(0., 1.)
        ])
        .is_none());
    }
}
