//! File-based interface used by the Python host integrations.
use super::*;
fn q(s: &str) -> String {
    let mut v = String::from("\"");
    for c in s.chars() {
        match c {
            '"' => v.push_str("\\\""),
            '\\' => v.push_str("\\\\"),
            '\n' => v.push_str("\\n"),
            '\r' => v.push_str("\\r"),
            '\t' => v.push_str("\\t"),
            c if c < ' ' => v.push_str(&format!("\\u{:04x}", c as u32)),
            c => v.push(c),
        }
    }
    v.push('"');
    v
}
pub fn export(app: &FurnitureApp) -> String {
    let cam = Camera::reset(app.room);
    let mut objects = vec![];
    let hidden = app.effective_hidden();
    let mut add = |id: u32, name: &str, kind: &str, layer: usize, faces: Vec<Face>| {
        let geometry = faces
            .iter()
            .map(|f| {
                let vertices = f
                    .points
                    .iter()
                    .map(|v| format!("[{},{},{}]", v.x / 1000., v.z / 1000., v.y / 1000.))
                    .collect::<Vec<_>>()
                    .join(",");
                let c = f.color.to_srgba_unmultiplied();
                format!(
                    "{{\"vertices\":[{vertices}],\"color\":[{},{},{},{}]}}",
                    c[0] as f32 / 255.,
                    c[1] as f32 / 255.,
                    c[2] as f32 / 255.,
                    c[3] as f32 / 255.
                )
            })
            .collect::<Vec<_>>()
            .join(",");
        objects.push(format!("{{\"id\":{id},\"name\":{},\"kind\":{},\"layer\":{layer},\"visible\":{},\"locked\":{},\"faces\":[{geometry}]}}",q(name),q(kind),!hidden.contains(&id),app.layers.locked[layer]));
    };
    for w in &app.walls {
        let os = app
            .openings
            .iter()
            .filter(|o| o.wall_id == w.id)
            .cloned()
            .collect::<Vec<_>>();
        let mut f = vec![];
        append_wall_faces(&mut f, cam, w, &os);
        add(w.id, &format!("Parede {}", w.id), "IfcWall", 0, f);
        for o in os {
            let mut f = vec![];
            append_opening_faces(&mut f, cam, w, &o, &app.materials);
            add(
                o.id,
                &o.style,
                if o.kind == OpeningKind::Door {
                    "IfcDoor"
                } else {
                    "IfcWindow"
                },
                if o.kind == OpeningKind::Door { 4 } else { 3 },
                f,
            );
        }
    }
    for m in &app.modules {
        let mut f = vec![];
        append_module_faces(&mut f, cam, m, &app.materials, false);
        add(m.id, &m.name, "IfcFurniture", 5, f);
    }
    for p in &app.panels {
        let mut f = vec![];
        automation::panel_faces(&mut f, cam, p, &app.materials);
        add(p.id, &p.name, "IfcPlate", 5, f);
    }
    for g in &app.gesso {
        let mut f = vec![];
        let y = app.room[1].saturating_sub(g.drop_mm) as f32;
        append_box(
            &mut f,
            cam,
            V3::new(g.x_mm as f32, y, g.z_mm as f32),
            V3::new(
                (g.x_mm + g.width_mm) as f32,
                y + g.thickness_mm as f32,
                (g.z_mm + g.depth_mm) as f32,
            ),
            Color32::WHITE,
        );
        add(g.id, "Gesso", "IfcCovering", 1, f);
    }
    for d in &app.decor {
        let mut f = vec![];
        designers::decor_faces(&mut f, cam, d);
        add(d.id, &d.name, "IfcBuildingElementProxy", 6, f);
    }
    let mut f = vec![];
    append_box(
        &mut f,
        cam,
        V3::new(0., -20., 0.),
        V3::new(app.room[0] as f32, 0., app.room[2] as f32),
        Color32::LIGHT_GRAY,
    );
    add(u32::MAX, "Piso", "IfcSlab", 2, f);
    format!(
        "{{\"schema\":1,\"unit\":\"metre\",\"objects\":[{}]}}",
        objects.join(",")
    )
}
pub fn run(args: &[String]) -> bool {
    if args.get(1).map(String::as_str) != Some("--bridge") {
        return false;
    }
    let Some(input) = args.get(2) else {
        eprintln!("Uso: --bridge entrada.mar saida.json|ifc|csv");
        std::process::exit(2)
    };
    let Some(output) = args.get(3) else {
        std::process::exit(2)
    };
    let mut app = FurnitureApp::default();
    app.project_path = input.clone();
    app.open_project();
    if app.notice_error {
        eprintln!("{}", app.notice);
        std::process::exit(2);
    }
    let result = match Path::new(output).extension().and_then(|s| s.to_str()) {
        Some("ifc") => fs::write(output, ifc::project(&app)),
        Some("json") => fs::write(output, export(&app)),
        Some("csv") => {
            app.csv_path = output.clone();
            app.export_csv();
            if app.notice_error {
                Err(io::Error::new(io::ErrorKind::Other, app.notice))
            } else {
                Ok(())
            }
        }
        _ => Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "Formato de saída: JSON, IFC ou CSV",
        )),
    };
    if let Err(e) = result {
        eprintln!("{e}");
        std::process::exit(2);
    }
    true
}
