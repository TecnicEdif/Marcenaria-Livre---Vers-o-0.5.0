use super::*;
/// Small vector symbols independent of system fonts.
pub fn draw(p: &egui::Painter, r: Rect, label: &str, color: Color32) {
    let t = |x: f32, y: f32| r.min + Vec2::new(x, y) * r.width() / 32.0;
    let stroke = Stroke::new(2.0, color);
    let line = |a: (f32, f32), b: (f32, f32)| {
        p.line_segment([t(a.0, a.1), t(b.0, b.1)], stroke);
    };
    let path = |pts: &[(f32, f32)]| {
        for pair in pts.windows(2) {
            line(pair[0], pair[1]);
        }
    };
    let rect = |x: f32, y: f32, w: f32, h: f32| {
        p.rect_stroke(Rect::from_min_max(t(x, y), t(x + w, y + h)), 1.0, stroke);
    };
    match label {
        "Criar geometria" => {
            path(&[
                (4., 24.),
                (4., 10.),
                (14., 4.),
                (28., 10.),
                (28., 24.),
                (18., 29.),
                (4., 24.),
            ]);
            line((4., 10.), (18., 16.));
            line((18., 16.), (28., 10.));
            line((18., 16.), (18., 29.));
        }
        "Placa lisa" | "Reto" => {
            rect(4., 8., 24., 16.);
        }
        "Sanca perimetral" | "Escalonado" => {
            path(&[
                (4., 4.),
                (17., 4.),
                (17., 16.),
                (28., 16.),
                (28., 28.),
                (4., 28.),
                (4., 4.),
            ]);
        }
        "Sanca escalonada" | "Friso superior" => {
            path(&[
                (4., 4.),
                (24., 4.),
                (24., 10.),
                (29., 10.),
                (29., 16.),
                (24., 16.),
                (24., 28.),
                (4., 28.),
                (4., 4.),
            ]);
        }
        "Matriz" => {
            for x in [3., 13., 23.] {
                for y in [3., 13., 23.] {
                    rect(x, y, 6., 6.);
                }
            }
        }
        "Desselecionar" => {
            line((7., 7.), (25., 25.));
            line((25., 7.), (7., 25.));
        }
        "Desfazer" => {
            path(&[(12., 6.), (5., 13.), (12., 20.)]);
            path(&[(5., 13.), (21., 13.), (26., 18.), (26., 26.)]);
        }
        "Abrir .mar" => {
            path(&[
                (3., 25.),
                (3., 7.),
                (12., 7.),
                (15., 11.),
                (28., 11.),
                (28., 15.),
            ]);
            path(&[(3., 25.), (9., 15.), (30., 15.), (24., 25.), (3., 25.)]);
        }
        "Salvar .mar" => {
            rect(5., 4., 23., 24.);
            rect(10., 4., 12., 8.);
            rect(10., 19., 13., 9.);
        }
        "Preferências" | "Automatizações" => {
            for (x, y) in [(7., 11.), (16., 22.), (25., 15.)] {
                line((x, 4.), (x, 28.));
                p.circle_filled(t(x, y), 3.5, color);
                p.circle_filled(t(x, y), 1.5, Color32::WHITE);
            }
        }
        "Selecionar" => {
            path(&[
                (7., 3.),
                (7., 27.),
                (14., 21.),
                (20., 30.),
                (24., 27.),
                (18., 18.),
                (27., 16.),
                (7., 3.),
            ]);
        }
        "Mover" => {
            line((3., 16.), (29., 16.));
            line((16., 3.), (16., 29.));
            for (a, b, c) in [
                ((7., 12.), (3., 16.), (7., 20.)),
                ((25., 12.), (29., 16.), (25., 20.)),
                ((12., 7.), (16., 3.), (20., 7.)),
                ((12., 25.), (16., 29.), (20., 25.)),
            ] {
                path(&[a, b, c]);
            }
        }
        "Planta" => {
            path(&[(4., 27.), (4., 5.), (28., 5.), (28., 27.), (20., 27.)]);
            line((11., 27.), (4., 27.));
            line((16., 5.), (16., 17.));
            line((4., 17.), (12., 17.));
        }
        "Ambiente 3D" | "Ortogonal" => {
            path(&[
                (4., 10.),
                (16., 4.),
                (28., 10.),
                (28., 24.),
                (16., 30.),
                (4., 24.),
                (4., 10.),
                (16., 16.),
                (28., 10.),
            ]);
            line((16., 16.), (16., 30.));
        }
        "Criador de módulos" => {
            rect(4., 3., 24., 26.);
            line((16., 3.), (16., 29.));
            line((4., 16.), (28., 16.));
            p.circle_filled(t(12., 10.), 1.5, color);
            p.circle_filled(t(20., 10.), 1.5, color);
        }
        "Parede reta" => {
            rect(3., 11., 26., 10.);
            for x in [9., 19.] {
                line((x, 11.), (x, 16.));
            }
            line((3., 16.), (29., 16.));
            for x in [6., 15., 24.] {
                line((x, 16.), (x, 21.));
            }
        }
        "Parede contínua" => {
            path(&[
                (4., 27.),
                (4., 5.),
                (26., 5.),
                (26., 18.),
                (20., 18.),
                (20., 11.),
                (10., 11.),
                (10., 27.),
                (4., 27.),
            ]);
        }
        "Parede curva" => {
            let mut pts = vec![];
            for i in 0..=24 {
                let a = i as f32 / 24. * std::f32::consts::FRAC_PI_2;
                pts.push(t(28. - 24. * a.cos(), 28. - 24. * a.sin()));
            }
            p.add(egui::Shape::line(pts, Stroke::new(5., color)));
        }
        "Puxadores" => {
            rect(4., 3., 24., 26.);
            rect(21., 12., 3., 10.);
        }
        "Porta" | "Aberturas" => {
            rect(6., 3., 20., 26.);
            path(&[(6., 3.), (21., 9.), (21., 29.)]);
            p.circle_filled(t(17., 18.), 1.5, color);
        }
        "Janela" => {
            rect(3., 5., 26., 22.);
            line((16., 5.), (16., 27.));
            line((3., 16.), (29., 16.));
        }
        "Painel ripado" => {
            for x in [4., 10., 16., 22., 28.] {
                line((x, 4.), (x, 28.));
            }
        }
        "Painel TV" => {
            rect(3., 6., 26., 18.);
            line((16., 24.), (16., 28.));
            line((10., 28.), (22., 28.));
        }
        "Rebaixo de gesso" => {
            path(&[
                (3., 7.),
                (29., 7.),
                (29., 13.),
                (23., 13.),
                (23., 19.),
                (9., 19.),
                (9., 13.),
                (3., 13.),
                (3., 7.),
            ]);
        }
        "Rodapé decorativo" => {
            path(&[
                (4., 4.),
                (4., 28.),
                (29., 28.),
                (29., 20.),
                (10., 20.),
                (10., 4.),
            ]);
        }
        "Copiar material" => {
            rect(3., 4., 18., 20.);
            rect(11., 12., 18., 17.);
        }
        "Pintar material" => {
            rect(4., 4., 24., 10.);
            path(&[(28., 9.), (31., 9.), (31., 19.), (16., 19.), (16., 28.)]);
        }
        "Parede de fundo" => {
            rect(4., 3., 5., 26.);
            line((12., 16.), (28., 16.));
            path(&[(18., 10.), (12., 16.), (18., 22.)]);
        }
        "Materiais" => {
            for (x, y, c) in [
                (4., 4., Color32::from_rgb(173, 119, 68)),
                (18., 4., Color32::from_rgb(85, 117, 111)),
                (4., 18., Color32::from_rgb(211, 192, 151)),
                (18., 18., Color32::from_rgb(89, 96, 104)),
            ] {
                p.rect_filled(Rect::from_min_max(t(x, y), t(x + 10., y + 10.)), 2., c);
            }
        }
        "Pranchas" => {
            rect(5., 2., 22., 28.);
            rect(9., 7., 14., 12.);
            line((5., 23.), (27., 23.));
            line((17., 23.), (17., 30.));
        }
        "Método" | "Método Construtivo" => {
            rect(3., 8., 26., 18.);
            for x in [8., 13., 18., 23.] {
                line((x, 8.), (x, 14.));
            }
            line((8., 21.), (25., 21.));
        }
        "Orçamento" => {
            rect(6., 2., 20., 28.);
            rect(10., 6., 12., 5.);
            for x in [11., 16., 21.] {
                for y in [17., 23.] {
                    p.circle_filled(t(x, y), 1.5, color);
                }
            }
        }
        _ => {
            rect(5., 5., 22., 22.);
            line((9., 16.), (23., 16.));
            line((16., 9.), (16., 23.));
        }
    }
}
