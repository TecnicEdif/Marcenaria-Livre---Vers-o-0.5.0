use super::*;
#[derive(Clone, Debug)]
struct Body {
    id: u32,
    wall: bool,
    points: [P2; 4],
    low: f32,
    high: f32,
}
fn rect(id: u32, wall: bool, x: f32, y: f32, z: f32, w: f32, h: f32, d: f32, angle: f32) -> Body {
    let (s, c) = angle.to_radians().sin_cos();
    let p = |a: f32, b: f32| P2::new(x + c * a - s * b, z + s * a + c * b);
    Body {
        id,
        wall,
        points: [p(0., 0.), p(w, 0.), p(w, d), p(0., d)],
        low: y,
        high: y + h,
    }
}
fn module(m: &Module) -> Body {
    Body {
        id: m.id,
        wall: false,
        points: module_corners(m),
        low: m.y_mm as f32,
        high: (m.y_mm + m.height_mm) as f32,
    }
}
/// Separating-axis test for rotated vertical prisms. Contact is permitted.
fn penetration(a: &Body, b: &Body) -> f32 {
    let mut depth = a.high.min(b.high) - a.low.max(b.low);
    if depth <= 0.5 {
        return 0.;
    }
    for p in [&a.points, &b.points] {
        for i in 0..2 {
            let dx = p[i + 1].x - p[i].x;
            let dz = p[i + 1].z - p[i].z;
            let len = (dx * dx + dz * dz).sqrt();
            if len < 0.001 {
                return 0.;
            }
            let axis = (-dz / len, dx / len);
            let interval = |pts: &[P2; 4]| {
                let v = pts.map(|p| p.x * axis.0 + p.z * axis.1);
                (
                    v.iter().copied().fold(f32::INFINITY, f32::min),
                    v.iter().copied().fold(f32::NEG_INFINITY, f32::max),
                )
            };
            let (amin, amax) = interval(&a.points);
            let (bmin, bmax) = interval(&b.points);
            let overlap = amax.min(bmax) - amin.max(bmin);
            if overlap <= 0.5 {
                return 0.;
            }
            depth = depth.min(overlap);
        }
    }
    depth
}
fn bodies(s: &ProjectSnapshot) -> Vec<Body> {
    let mut out: Vec<_> = s.modules.iter().map(module).collect();
    for w in &s.walls {
        let len = w.start.distance(w.end);
        if len < 0.01 {
            continue;
        }
        let angle = (w.end.z - w.start.z).atan2(w.end.x - w.start.x);
        let t = w.thickness_mm as f32;
        // The opening owns its host-wall volume. Closed joinery still blocks passage.
        out.push(rect(
            w.id,
            true,
            w.start.x + angle.sin() * t / 2.,
            0.,
            w.start.z - angle.cos() * t / 2.,
            len,
            w.height_mm as f32,
            t,
            angle.to_degrees(),
        ));
    }
    for p in &s.panels {
        let horizontal = p.horizontal || p.name.starts_with("Bancada de pedra");
        out.push(rect(
            p.id,
            false,
            p.x_mm as f32,
            p.y_mm as f32,
            p.z_mm as f32,
            p.width_mm as f32,
            if horizontal {
                p.thickness_mm
            } else {
                p.height_mm
            } as f32,
            if horizontal {
                p.height_mm
            } else {
                p.thickness_mm
            } as f32,
            p.rotation_deg,
        ));
    }
    for g in &s.gesso {
        out.push(rect(
            g.id,
            false,
            g.x_mm as f32,
            s.room[1].saturating_sub(g.drop_mm) as f32,
            g.z_mm as f32,
            g.width_mm as f32,
            g.thickness_mm as f32,
            g.depth_mm as f32,
            0.,
        ));
    }
    for d in &s.decor {
        out.push(rect(
            d.id,
            false,
            d.x_mm as f32,
            d.y_mm as f32,
            d.z_mm as f32,
            d.width_mm as f32,
            d.height_mm as f32,
            d.depth_mm as f32,
            d.rotation_deg,
        ));
    }
    out
}
impl FurnitureApp {
    pub fn enforce_collisions(&mut self, before: &ProjectSnapshot) {
        if self.last_snapshot.is_none() {
            return;
        }
        let old = bodies(before);
        let now = bodies(&self.project_snapshot());
        let mut conflict = None;
        let same = |a: &Body, b: &Body| {
            a.low == b.low
                && a.high == b.high
                && a.points
                    .iter()
                    .zip(&b.points)
                    .all(|(a, b)| a.x == b.x && a.z == b.z)
        };
        let lookup: std::collections::HashMap<_, _> = old.iter().map(|b| (b.id, b)).collect();
        let changed: std::collections::HashSet<_> = now
            .iter()
            .filter(|b| lookup.get(&b.id).map(|old| !same(b, old)).unwrap_or(true))
            .map(|b| b.id)
            .collect();
        if changed.is_empty() {
            return;
        }
        'pairs: for (i, a) in now.iter().enumerate() {
            for b in &now[i + 1..] {
                if a.wall && b.wall || (!changed.contains(&a.id) && !changed.contains(&b.id)) {
                    continue;
                }
                let oa = lookup.get(&a.id).copied();
                let ob = lookup.get(&b.id).copied();
                let previous = oa.zip(ob).map(|(a, b)| penetration(a, b)).unwrap_or(0.);
                if penetration(a, b) > previous + 0.5 {
                    conflict = Some((a.id, b.id));
                    break 'pairs;
                }
                // Check the entire translation, including fast pointer movement across thin objects.
                if let (Some(oa), Some(ob)) = (oa, ob) {
                    let travel = a
                        .points
                        .iter()
                        .zip(&oa.points)
                        .map(|(a, b)| a.distance(*b))
                        .fold(0., f32::max)
                        .max((a.low - oa.low).abs());
                    let other = b
                        .points
                        .iter()
                        .zip(&ob.points)
                        .map(|(a, b)| a.distance(*b))
                        .fold(0., f32::max)
                        .max((b.low - ob.low).abs());
                    let steps = ((travel + other) / 10.).ceil() as usize;
                    for step in 1..steps {
                        let t = step as f32 / steps as f32;
                        let interpolate = |new: &Body, old: &Body| {
                            let mut n = new.clone();
                            for j in 0..4 {
                                n.points[j] = P2::new(
                                    old.points[j].x + (new.points[j].x - old.points[j].x) * t,
                                    old.points[j].z + (new.points[j].z - old.points[j].z) * t,
                                );
                            }
                            n.low = old.low + (new.low - old.low) * t;
                            n.high = old.high + (new.high - old.high) * t;
                            n
                        };
                        if penetration(&interpolate(a, oa), &interpolate(b, ob)) > previous + 0.5 {
                            conflict = Some((a.id, b.id));
                            break 'pairs;
                        }
                    }
                }
            }
        }
        if let Some((a, b)) = conflict {
            self.groups = before.groups.clone();
            self.next_id = before.next_id;
            self.modules = before.modules.clone();
            self.walls = before.walls.clone();
            self.openings = before.openings.clone();
            self.panels = before.panels.clone();
            self.gesso = before.gesso.clone();
            self.decor = before.decor.clone();
            self.room = before.room;
            self.scene_drag_offset = self
                .modules
                .iter()
                .find(|m| self.selected == Some(Selection::Module(m.id)))
                .map(|m| P2::new(m.x_mm as f32, m.z_mm as f32));
            self.notice=format!("Movimento impedido: os elementos {a} e {b} se cruzariam. Afaste o móvel antes de mudar de parede.");
            self.notice_error = true;
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn contact_allowed() {
        let a = rect(1, false, 0., 0., 0., 800., 720., 550., 0.);
        let b = rect(2, false, 800., 0., 0., 800., 720., 550., 0.);
        assert_eq!(penetration(&a, &b), 0.);
    }
    #[test]
    fn rotated_collision() {
        let a = rect(1, false, 0., 0., 0., 800., 720., 550., 30.);
        let b = rect(2, false, 300., 0., 0., 800., 720., 550., -20.);
        assert!(penetration(&a, &b) > 0.);
    }
    #[test]
    fn different_heights_allowed() {
        let a = rect(1, false, 0., 0., 0., 800., 720., 550., 0.);
        let b = rect(2, false, 0., 1320., 0., 800., 720., 550., 0.);
        assert_eq!(penetration(&a, &b), 0.);
    }
    #[test]
    fn fast_motion_cannot_cross_module() {
        let mut a = FurnitureApp::default();
        a.walls.clear();
        a.modules.truncate(1);
        a.modules[0].x_mm = 0;
        let mut obstacle = a.modules[0].clone();
        obstacle.id = 99;
        obstacle.x_mm = 900;
        obstacle.width_mm = 20;
        a.modules.push(obstacle);
        a.track_history();
        let before = a.project_snapshot();
        a.modules[0].x_mm = 1800;
        a.enforce_collisions(&before);
        assert_eq!(a.modules[0].x_mm, 0);
    }
}
