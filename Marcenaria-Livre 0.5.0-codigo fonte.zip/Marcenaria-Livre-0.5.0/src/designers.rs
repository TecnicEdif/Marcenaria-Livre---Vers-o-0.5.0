use super::*;
#[derive(Clone)]
pub struct PanelDesigner {
    pub slatted: bool,
    pub slat: u32,
    pub gap: u32,
    pub x: u32,
    pub y: u32,
    pub z: u32,
    pub backing: bool,
}
impl Default for PanelDesigner {
    fn default() -> Self {
        Self {
            slatted: true,
            slat: 40,
            gap: 20,
            x: 300,
            y: 0,
            z: 300,
            backing: true,
        }
    }
}
impl FurnitureApp {
    pub fn panel_designer(&mut self, ui: &mut egui::Ui) {
        ui.heading(if self.panel_designer.slatted {
            "Criador de painel ripado"
        } else {
            "Criador de painel para TV"
        });
        ui.label("Configure as medidas e confira a elevação antes de inserir. As peças entram na lista de fabricação.");
        ui.columns(2, |cols| {
            cols[0].group(|ui| {
                property_field(ui, "Largura total", &mut self.panel_width, 100..=6000);
                property_field(ui, "Altura total", &mut self.panel_height, 100..=4000);
                property_field(ui, "Espessura", &mut self.panel_thickness, 6..=60);
                property_field(ui, "Posição X", &mut self.panel_designer.x, 0..=20000);
                property_field(ui, "Elevação Y", &mut self.panel_designer.y, 0..=5000);
                property_field(ui, "Posição Z", &mut self.panel_designer.z, 0..=20000);
                if self.panel_designer.slatted {
                    property_field(
                        ui,
                        "Largura da ripa",
                        &mut self.panel_designer.slat,
                        10..=200,
                    );
                    property_field(ui, "Vão entre ripas", &mut self.panel_designer.gap, 1..=200);
                    ui.checkbox(&mut self.panel_designer.backing, "Chapa de fundo");
                }
                let choices = self
                    .materials
                    .iter()
                    .map(|m| m.name.clone())
                    .collect::<Vec<_>>();
                material_combo(ui, "Material", &mut self.panel_material, &choices);
                grain_combo(ui, "Sentido do veio", &mut self.panel_grain);
            });
            cols[1].group(|ui| {
                ui.strong("ELEVAÇÃO • PRÉVIA");
                let (r, _) =
                    ui.allocate_exact_size(Vec2::new(ui.available_width(), 340.), Sense::hover());
                let p = ui.painter_at(r);
                let scale =
                    (r.width() - 30.).min(380.) / self.panel_width.max(self.panel_height) as f32;
                let w = self.panel_width as f32 * scale;
                let h = self.panel_height as f32 * scale;
                let outline = Rect::from_center_size(r.center(), Vec2::new(w, h));
                let color = material_color_for(&self.panel_material, &self.materials);
                p.rect_filled(
                    outline,
                    0.,
                    if self.panel_designer.backing || !self.panel_designer.slatted {
                        color
                    } else {
                        Color32::from_gray(230)
                    },
                );
                p.rect_stroke(outline, 0., Stroke::new(1., Color32::BLACK));
                if self.panel_designer.slatted {
                    let step = self.panel_designer.slat + self.panel_designer.gap;
                    for x in (0..self.panel_width).step_by(step as usize) {
                        let a = outline.left_top() + Vec2::new(x as f32 * scale, 0.);
                        let b = a + Vec2::new(
                            self.panel_designer.slat.min(self.panel_width - x) as f32 * scale,
                            h,
                        );
                        p.rect_filled(Rect::from_min_max(a, b), 0., color);
                        p.rect_stroke(
                            Rect::from_min_max(a, b),
                            0.,
                            Stroke::new(1., Color32::BLACK),
                        );
                    }
                } else {
                    let tv =
                        Rect::from_center_size(outline.center(), Vec2::new(w * 0.65, h * 0.38));
                    p.rect_stroke(tv, 2., Stroke::new(2., GREEN));
                    p.text(
                        tv.center(),
                        egui::Align2::CENTER_CENTER,
                        "TV • referência",
                        egui::FontId::proportional(12.),
                        GREEN,
                    );
                }
                ui.label(format!("{} × {} mm", self.panel_width, self.panel_height));
            });
        });
        if ui
            .add_sized([260., 46.], egui::Button::new("Criar painel no ambiente"))
            .clicked()
        {
            self.create_designed_panel();
        }
        ui.label(&self.notice);
    }
    pub fn create_designed_panel(&mut self) {
        let before = self.project_snapshot();
        let d = self.panel_designer.clone();
        let mut ids = vec![];
        let mut add = |x: u32, z: u32, w: u32, name: &str| {
            let id = self.next_id;
            self.next_id += 1;
            ids.push(id);
            self.panels.push(WoodPanel {
                id,
                name: name.into(),
                rotation_deg: 0.,
                horizontal: false,
                x_mm: x,
                y_mm: d.y,
                z_mm: z,
                width_mm: w,
                height_mm: self.panel_height,
                thickness_mm: self.panel_thickness,
                material: self.panel_material.clone(),
                grain: self.panel_grain,
            });
        };
        if !d.slatted || d.backing {
            add(
                d.x,
                d.z,
                self.panel_width,
                if d.slatted {
                    "Fundo do painel ripado"
                } else {
                    "Painel para TV"
                },
            );
        }
        if d.slatted {
            let step = d.slat + d.gap;
            for x in (0..self.panel_width).step_by(step as usize) {
                add(
                    d.x + x,
                    if d.backing {
                        d.z.saturating_add(self.panel_thickness)
                    } else {
                        d.z
                    },
                    d.slat.min(self.panel_width - x),
                    "Ripa do painel",
                );
            }
        }
        self.enforce_layer_locks(&before);
        self.enforce_collisions(&before);
        ids.retain(|id| self.panels.iter().any(|p| p.id == *id));
        if ids.is_empty() {
            return;
        }
        if ids.len() > 1 {
            self.groups.push(ids.clone());
        }
        self.editing.selection = ids.clone();
        self.selected = ids.first().copied().map(Selection::Panel);
        self.page = Page::Scene;
        self.tool = Tool::Select;
        self.notice = "Painel criado com peças agrupadas e medidas de fabricação.".into();
    }
}

#[derive(Clone)]
pub struct FinishDesigner {
    pub plaster: bool,
    pub profile: usize,
    pub x: u32,
    pub z: u32,
    pub width: u32,
    pub depth: u32,
    pub band: u32,
    pub drop: u32,
    pub thickness: u32,
    pub upper: bool,
    pub height: u32,
    pub projection: u32,
}
impl Default for FinishDesigner {
    fn default() -> Self {
        Self {
            plaster: true,
            profile: 0,
            x: 250,
            z: 250,
            width: 3000,
            depth: 2200,
            band: 250,
            drop: 200,
            thickness: 60,
            upper: false,
            height: 120,
            projection: 20,
        }
    }
}
impl FurnitureApp {
    pub fn finish_designer(&mut self, ui: &mut egui::Ui) {
        ui.heading(if self.finish_designer.plaster {
            "Criador de rebaixo de gesso"
        } else {
            "Criador de rodapé decorativo"
        });
        ui.label("Escolha o perfil, ajuste as medidas e confira o corte esquemático. Elementos decorativos não entram no orçamento de marcenaria.");
        ui.horizontal_wrapped(|ui| {
            for (index, label) in (if self.finish_designer.plaster {
                ["Placa lisa", "Sanca perimetral", "Sanca escalonada"]
            } else {
                ["Reto", "Escalonado", "Friso superior"]
            })
            .iter()
            .enumerate()
            {
                if ribbon_button(ui, "", label, self.finish_designer.profile == index) {
                    self.finish_designer.profile = index;
                }
            }
        });
        ui.columns(2, |c| {
            c[0].group(|ui| {
                let d = &mut self.finish_designer;
                if d.plaster {
                    property_field(ui, "X", &mut d.x, 0..=20000);
                    property_field(ui, "Z", &mut d.z, 0..=20000);
                    property_field(ui, "Largura", &mut d.width, 300..=15000);
                    property_field(ui, "Profundidade", &mut d.depth, 300..=15000);
                    property_field(ui, "Faixa perimetral", &mut d.band, 50..=1000);
                    property_field(ui, "Distância abaixo do teto", &mut d.drop, 50..=1500);
                    property_field(ui, "Espessura do rebaixo", &mut d.thickness, 10..=300);
                } else {
                    property_field(ui, "Altura do rodapé", &mut d.height, 20..=400);
                    property_field(ui, "Projeção", &mut d.projection, 5..=100);
                    ui.checkbox(&mut d.upper, "Posicionar junto ao teto");
                    ui.label(
                        "Usa a parede selecionada; sem parede selecionada, usa todas as paredes.",
                    );
                }
            });
            c[1].group(|ui| {
                ui.strong("CORTE ESQUEMÁTICO");
                let (r, _) =
                    ui.allocate_exact_size(Vec2::new(ui.available_width(), 230.), Sense::hover());
                let p = ui.painter_at(r);
                let d = &self.finish_designer;
                let start = r.left_top() + Vec2::splat(24.);
                let h = 120.;
                let w = 160.;
                let profile = match d.profile {
                    1 => vec![
                        (0., 0.),
                        (w * 0.5, 0.),
                        (w * 0.5, h * 0.5),
                        (w, h * 0.5),
                        (w, h),
                        (0., h),
                    ],
                    2 => vec![
                        (0., 0.),
                        (w * 0.8, 0.),
                        (w * 0.8, h * 0.2),
                        (w, h * 0.2),
                        (w, h * 0.4),
                        (w * 0.8, h * 0.4),
                        (w * 0.8, h),
                        (0., h),
                    ],
                    _ => vec![(0., 0.), (w, 0.), (w, h), (0., h)],
                };
                for pair in profile
                    .iter()
                    .cycle()
                    .take(profile.len() + 1)
                    .collect::<Vec<_>>()
                    .windows(2)
                {
                    p.line_segment(
                        [
                            start + Vec2::new(pair[0].0, pair[0].1),
                            start + Vec2::new(pair[1].0, pair[1].1),
                        ],
                        Stroke::new(3., GREEN),
                    );
                }
                ui.label("Prévia do perfil • medidas informadas em milímetros");
            });
        });
        if ui
            .add_sized([260., 46.], egui::Button::new("Criar acabamento na cena"))
            .clicked()
        {
            self.create_finish();
        }
        ui.label(&self.notice);
    }
    pub fn create_finish(&mut self) {
        let before = self.project_snapshot();
        let d = self.finish_designer.clone();
        let mut ids = vec![];
        if d.plaster {
            let drop = d.drop.max(d.thickness).min(self.room[1]);
            let band = d.band.min(d.width / 3).min(d.depth / 3);
            let mut add = |x, z, width, depth, drop, thickness| {
                let id = self.next_id;
                self.next_id += 1;
                ids.push(id);
                self.gesso.push(GessoBlock {
                    id,
                    x_mm: x,
                    z_mm: z,
                    width_mm: width,
                    depth_mm: depth,
                    drop_mm: drop,
                    thickness_mm: thickness,
                });
            };
            if d.profile == 0 {
                add(d.x, d.z, d.width, d.depth, drop, d.thickness.min(drop));
            } else {
                for (x, z, w, h) in [
                    (d.x, d.z, d.width, band),
                    (d.x, d.z + d.depth - band, d.width, band),
                    (d.x, d.z + band, band, d.depth - 2 * band),
                    (d.x + d.width - band, d.z + band, band, d.depth - 2 * band),
                ] {
                    add(x, z, w, h, drop, d.thickness.min(drop));
                }
                if d.profile == 2 {
                    let inner = band / 2;
                    for (x, z, w, h) in [
                        (d.x + band, d.z + band, d.width - 2 * band, inner),
                        (
                            d.x + band,
                            d.z + d.depth - band - inner,
                            d.width - 2 * band,
                            inner,
                        ),
                        (
                            d.x + band,
                            d.z + band + inner,
                            inner,
                            d.depth - 2 * band - 2 * inner,
                        ),
                        (
                            d.x + d.width - band - inner,
                            d.z + band + inner,
                            inner,
                            d.depth - 2 * band - 2 * inner,
                        ),
                    ] {
                        add(
                            x,
                            z,
                            w,
                            h,
                            drop.saturating_sub(d.thickness / 2),
                            d.thickness / 2,
                        );
                    }
                }
            }
        } else {
            for w in &self.walls {
                if let Some(Selection::Wall(selected)) = self.selected {
                    if selected != w.id {
                        continue;
                    }
                }
                let len = w.start.distance(w.end);
                if len < 100. {
                    continue;
                }
                let angle = (w.end.z - w.start.z).atan2(w.end.x - w.start.x);
                let (mut nx, mut nz) = (-angle.sin(), angle.cos());
                let mid = P2::new((w.start.x + w.end.x) / 2., (w.start.z + w.end.z) / 2.);
                if nx * (self.room[0] as f32 / 2. - mid.x) + nz * (self.room[2] as f32 / 2. - mid.z)
                    < 0.
                {
                    nx = -nx;
                    nz = -nz;
                }
                let offset = w.thickness_mm as f32 / 2. + 1.;
                let reverse = nx * -angle.sin() + nz * angle.cos() < 0.;
                let mut origin = if reverse { w.end } else { w.start };
                let trim = w.thickness_mm as f32 / 2. + d.projection as f32 + 1.;
                let sign = if reverse { -1. } else { 1. };
                origin.x += angle.cos() * trim * sign;
                origin.z += angle.sin() * trim * sign;
                let rot = angle.to_degrees() + if reverse { 180. } else { 0. };
                let id = self.next_id;
                self.next_id += 1;
                ids.push(id);
                self.decor.push(DecorItem {
                    outline: vec![],
                    id,
                    name: format!("Rodapé decorativo • perfil {}", d.profile),
                    material: "Pintura branca".into(),
                    rotation_deg: rot,
                    x_mm: (origin.x + nx * offset).max(0.) as u32,
                    y_mm: if d.upper {
                        w.height_mm.saturating_sub(d.height)
                    } else {
                        0
                    },
                    z_mm: (origin.z + nz * offset).max(0.) as u32,
                    width_mm: (len - 2. * trim).max(1.) as u32,
                    height_mm: d.height,
                    depth_mm: d.projection,
                    color: Color32::from_rgb(230, 230, 223),
                });
            }
        }
        self.enforce_layer_locks(&before);
        self.enforce_collisions(&before);
        let existing: Vec<_> = self.all_selections().into_iter().map(editing::id).collect();
        ids.retain(|i| existing.contains(i));
        if ids.is_empty() {
            return;
        }
        if ids.len() > 1 {
            self.groups.push(ids.clone());
        }
        self.selected = self
            .all_selections()
            .into_iter()
            .find(|s| ids.contains(&editing::id(*s)));
        self.editing.selection = ids;
        self.page = Page::Scene;
        self.notice =
            "Acabamento decorativo criado. Use as propriedades para ajustar a posição.".into();
    }
}
pub fn decor_faces(faces: &mut Vec<Face>, camera: Camera, d: &DecorItem) {
    if !d.outline.is_empty() {
        geometry::faces(faces, camera, d);
        return;
    }
    let start = faces.len();
    let h = d.height_mm as f32;
    let w = d.width_mm as f32;
    let depth = d.depth_mm as f32;
    let profile = if d.name.starts_with("Rodapé decorativo") {
        d.name
            .chars()
            .last()
            .and_then(|c| c.to_digit(10))
            .unwrap_or(0)
    } else {
        0
    };
    let name = d.name.to_lowercase();
    let furniture = name.contains("decorativ") && !name.contains("rodapé");
    if furniture && (name.contains("mesa") || name.contains("banco") || name.contains("aparador")) {
        let t = 30.;
        append_box(
            faces,
            camera,
            V3::new(0., h - t, 0.),
            V3::new(w, h, depth),
            d.color,
        );
        for x in [30., (w - 60.).max(30.)] {
            for z in [25., (depth - 55.).max(25.)] {
                append_box(
                    faces,
                    camera,
                    V3::new(x, 0., z),
                    V3::new(x + 30., h - t, z + 30.),
                    d.color,
                );
            }
        }
    } else if furniture && (name.contains("estante") || name.contains("expositor")) {
        let t = 20.;
        for x in [0., w - t] {
            append_box(
                faces,
                camera,
                V3::new(x, 0., 0.),
                V3::new(x + t, h, depth),
                d.color,
            );
        }
        for i in 0..=4 {
            let yy = (h - t) * i as f32 / 4.;
            append_box(
                faces,
                camera,
                V3::new(t, yy, 0.),
                V3::new(w - t, yy + t, depth),
                d.color,
            );
        }
    } else {
        let boxes = match profile {
            1 => vec![(0., h * 0.7, depth), (h * 0.7, h, depth * 0.5)],
            2 => vec![
                (0., h * 0.65, depth * 0.8),
                (h * 0.65, h * 0.85, depth),
                (h * 0.85, h, depth * 0.8),
            ],
            _ => vec![(0., h, depth)],
        };
        for (a, b, z) in boxes {
            append_box(faces, camera, V3::new(0., a, 0.), V3::new(w, b, z), d.color);
        }
    }
    let (s, c) = d.rotation_deg.to_radians().sin_cos();
    for f in &mut faces[start..] {
        for p in &mut f.points {
            let (x, z) = (p.x, p.z);
            *p = V3::new(
                d.x_mm as f32 + c * x - s * z,
                d.y_mm as f32 + p.y,
                d.z_mm as f32 + s * x + c * z,
            );
        }
        f.depth = f
            .points
            .iter()
            .map(|p| p.sub(camera.target).dot(camera.basis().2))
            .sum::<f32>()
            / 4.;
    }
}
pub const DECOR_CATEGORIES: [&str; 7] = [
    "Todas",
    "Assentos",
    "Mesas e apoios",
    "Eletrodomésticos",
    "Vegetação e acessórios",
    "Armazenamento e exposição",
    "Quarto e têxteis",
];
pub fn decor_category(name: &str) -> usize {
    let s = name.to_lowercase();
    if ["cadeira", "sofá", "poltrona", "puff", "banco"]
        .iter()
        .any(|n| s.contains(n))
    {
        1
    } else if ["mesa", "escrivaninha", "aparador", "bancada", "pedestal"]
        .iter()
        .any(|n| s.contains(n))
    {
        2
    } else if ["geladeira", "fogão", "micro-ondas", "televisão"]
        .iter()
        .any(|n| s.contains(n))
    {
        3
    } else if ["planta", "vaso", "quadro", "luminária"]
        .iter()
        .any(|n| s.contains(n))
    {
        4
    } else if ["cama", "tapete"].iter().any(|n| s.contains(n)) {
        6
    } else {
        5
    }
}
pub fn extra_decor() -> Vec<(String, u32, u32, u32, Color32)> {
    let mut items = vec![];
    for (base, w, h, d) in [
        ("Mesa decorativa", 800, 740, 600),
        ("Banco decorativo", 700, 450, 350),
        ("Aparador decorativo", 900, 800, 350),
        ("Pedestal decorativo", 300, 800, 300),
        ("Expositor decorativo", 800, 1200, 350),
        ("Estante decorativa", 700, 1600, 300),
        ("Puff decorativo", 450, 400, 450),
        ("Mesa lateral decorativa", 400, 500, 400),
    ] {
        for i in 0..25 {
            let ww = w + (i % 5) * 100;
            let hh = h + (i / 5) * 40;
            let dd = d + (i % 3) * 50;
            items.push((
                format!("{base} {ww}×{hh}×{dd}"),
                ww,
                hh,
                dd,
                Color32::from_rgb(184, 153, 118),
            ));
        }
    }
    items
}
