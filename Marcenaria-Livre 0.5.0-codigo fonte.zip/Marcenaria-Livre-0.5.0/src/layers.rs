use super::*;
/// Visibility does not remove objects from manufacturing or collision calculations.
#[derive(Clone, Debug, PartialEq)]
pub struct Layers {
    pub visible: [bool; 7],
    pub locked: [bool; 7],
}
impl Default for Layers {
    fn default() -> Self {
        Self {
            visible: [true; 7],
            locked: [false; 7],
        }
    }
}
pub const NAMES: [&str; 7] = [
    "Paredes",
    "Tetos e gesso",
    "Pisos",
    "Janelas",
    "Portas do ambiente",
    "Móveis e painéis",
    "Decoração",
];
impl FurnitureApp {
    pub fn effective_hidden(&self) -> Vec<u32> {
        let mut ids = self.hidden_ids.clone();
        for w in &self.walls {
            if !self.layers.visible[0] {
                ids.push(w.id);
            }
        }
        for g in &self.gesso {
            if !self.layers.visible[1] {
                ids.push(g.id);
            }
        }
        if !self.layers.visible[2] {
            ids.push(u32::MAX);
        }
        for o in &self.openings {
            let i = if o.kind == OpeningKind::Window { 3 } else { 4 };
            if !self.layers.visible[i]
                || !self.layers.visible[0]
                || self.hidden_ids.contains(&o.wall_id)
            {
                ids.push(o.id);
            }
        }
        if !self.layers.visible[5] {
            ids.extend(self.modules.iter().map(|v| v.id));
            ids.extend(self.panels.iter().map(|v| v.id));
        }
        if !self.layers.visible[6] {
            ids.extend(self.decor.iter().map(|v| v.id));
        }
        ids
    }
    pub fn layers_editor(&mut self, ctx: &egui::Context) {
        egui::Window::new(i18n::tr("Camadas do projeto"))
            .open(&mut self.show_layers)
            .default_width(480.)
            .show(ctx, |ui| {
                ui.spacing_mut().interact_size.y = 34.;
                ui.label(i18n::tr(
                    "Ocultar muda a vista. Bloquear protege os elementos contra edição e exclusão.",
                ));
                egui::Grid::new("layers")
                    .striped(true)
                    .spacing([20., 10.])
                    .show(ui, |ui| {
                        ui.strong(i18n::tr("Categoria"));
                        ui.strong(i18n::tr("Visível"));
                        ui.strong(i18n::tr("Bloqueada"));
                        ui.end_row();
                        for (i, name) in NAMES.iter().enumerate() {
                            ui.label(i18n::tr(name));
                            ui.checkbox(&mut self.layers.visible[i], i18n::tr("Mostrar"));
                            ui.checkbox(&mut self.layers.locked[i], i18n::tr("Bloquear"));
                            ui.end_row();
                        }
                    });
                if ui.button(i18n::tr("Mostrar todas as camadas")).clicked() {
                    self.layers.visible.fill(true);
                }
            });
    }
    pub fn enforce_layer_locks(&mut self, before: &ProjectSnapshot) {
        // A document load starts a new history and must not inherit the previous document's locks.
        if self.last_snapshot.is_none() {
            return;
        }
        let mut rejected = false;
        macro_rules! restore {
            ($field:ident,$i:expr) => {
                if before.layers.locked[$i]
                    && format!("{:?}", self.$field) != format!("{:?}", before.$field)
                {
                    self.$field = before.$field.clone();
                    rejected = true;
                }
            };
        }
        restore!(walls, 0);
        restore!(gesso, 1);
        restore!(modules, 5);
        restore!(panels, 5);
        restore!(decor, 6);
        if before.layers.locked[2] && self.room != before.room {
            self.room = before.room;
            rejected = true;
        }
        for (idx, kind) in [(3, OpeningKind::Window), (4, OpeningKind::Door)] {
            if before.layers.locked[idx] || before.layers.locked[0] {
                let old: Vec<_> = before
                    .openings
                    .iter()
                    .filter(|o| o.kind == kind)
                    .cloned()
                    .collect();
                let now: Vec<_> = self
                    .openings
                    .iter()
                    .filter(|o| o.kind == kind)
                    .cloned()
                    .collect();
                if format!("{old:?}") != format!("{now:?}") {
                    self.openings.retain(|o| o.kind != kind);
                    self.openings.extend(old);
                    rejected = true;
                }
            }
        }
        if rejected {
            self.scene_drag_offset = None;
            self.notice =
                "Camada bloqueada. Desbloqueie-a em Camadas para editar seus elementos.".into();
            self.notice_error = true;
        }
    }
}
