use super::*;
#[derive(Clone, Debug)]
pub struct Handle {
    pub position: usize,
    pub vertical: bool,
    pub length: u32,
    pub inset: u32,
    pub enabled: bool,
    pub hinge_right: Option<bool>,
    pub open: bool,
}
impl Default for Handle {
    fn default() -> Self {
        Self {
            position: 5,
            vertical: true,
            length: 128,
            inset: 40,
            enabled: true,
            hinge_right: None,
            open: false,
        }
    }
}
pub fn encode(h: &[Handle]) -> String {
    h.iter()
        .map(|h| {
            format!(
                "{},{},{},{},{},{},{}",
                h.position,
                h.vertical,
                h.length,
                h.inset,
                h.enabled,
                h.hinge_right.map(|v| v.to_string()).unwrap_or_default(),
                h.open
            )
        })
        .collect::<Vec<_>>()
        .join(";")
}
pub fn decode(s: &str) -> Vec<Handle> {
    s.split(';')
        .filter_map(|v| {
            let p: Vec<_> = v.split(',').collect();
            Some(Handle {
                position: p.first()?.parse::<usize>().ok()?.min(8),
                vertical: p.get(1)?.parse().ok()?,
                length: p.get(2)?.parse::<u32>().ok()?.clamp(30, 800),
                inset: p.get(3)?.parse::<u32>().ok()?.clamp(10, 200),
                enabled: p.get(4)?.parse().ok()?,
                hinge_right: p.get(5).and_then(|s| s.parse().ok()),
                open: p.get(6).and_then(|s| s.parse().ok()).unwrap_or(false),
            })
        })
        .collect()
}
pub fn editor(m: &mut Module, ui: &mut egui::Ui) {
    egui::CollapsingHeader::new(i18n::tr("Posicionar puxadores"))
        .default_open(true)
        .show(ui, |ui| {
            let count = if m.kind == ModuleKind::Drawer {
                m.drawer_count.max(1)
            } else {
                m.door_count
            };
            while m.handles.len() < (count as usize) {
                let i = m.handles.len();
                m.handles.push(default_handle(m, i));
            }
            m.handles.truncate(count as usize);
            ui.label(i18n::tr(
                "Cada frente pode receber posição, orientação e tamanho próprios.",
            ));
            let mut apply = None;
            for (i, h) in m.handles.iter_mut().enumerate() {
                ui.push_id(i, |ui| {
                    ui.group(|ui| {
                        ui.strong(format!("Frente {}", i + 1));
                        if m.kind != ModuleKind::Drawer {
                            let mut right = h.hinge_right.unwrap_or(i % 2 == 1);
                            ui.horizontal(|ui| {
                                ui.label(i18n::tr("Dobradiça:"));
                                ui.selectable_value(&mut right, false, i18n::tr("← Esquerda"));
                                ui.selectable_value(&mut right, true, i18n::tr("Direita →"));
                            });
                            h.hinge_right = Some(right);
                            ui.add_enabled(
                                !m.door_open,
                                egui::Checkbox::new(&mut h.open, "Abrir esta porta"),
                            );
                            if m.door_open {
                                ui.small(i18n::tr(
                                    "Feche a abertura geral para controlar portas individualmente.",
                                ));
                            }
                        }
                        ui.checkbox(&mut h.enabled, i18n::tr("Puxador visível"));
                        egui::Grid::new("position").show(ui, |ui| {
                            for row in 0..3 {
                                for col in 0..3 {
                                    let index = row * 3 + col;
                                    if ui
                                        .add_sized(
                                            [36., 30.],
                                            egui::SelectableLabel::new(
                                                h.position == index,
                                                format!("{}", index + 1),
                                            ),
                                        )
                                        .clicked()
                                    {
                                        h.position = index;
                                    }
                                }
                                ui.end_row();
                            }
                        });
                        ui.checkbox(&mut h.vertical, i18n::tr("Vertical"));
                        property_field(ui, "Comprimento", &mut h.length, 30..=800);
                        property_field(ui, "Distância da borda", &mut h.inset, 10..=200);
                        if ui
                            .button(i18n::tr("Aplicar a todas as frentes deste módulo"))
                            .clicked()
                        {
                            apply = Some(h.clone());
                        }
                    });
                });
            }
            if let Some(h) = apply {
                m.handles.fill(h);
            }
        });
}
pub fn draw(faces: &mut Vec<Face>, camera: Camera, m: &Module, materials: &[MaterialData]) {
    let n = if m.kind == ModuleKind::Drawer {
        m.drawer_count.max(1)
    } else {
        m.door_count
    };
    if n == 0 {
        return;
    }
    let drawer = m.kind == ModuleKind::Drawer;
    let gap = 3.;
    let width = if drawer {
        m.width_mm as f32 - 2. * gap
    } else {
        (m.width_mm as f32 - gap * (n + 1) as f32) / n as f32
    };
    let height = if drawer {
        (m.height_mm as f32 - gap * (n + 1) as f32) / n as f32
    } else {
        m.height_mm as f32 - 2. * gap
    };
    for i in 0..n {
        let x = m.x_mm as f32 + gap + if drawer { 0. } else { i as f32 * (width + gap) };
        let y = m.y_mm as f32
            + gap
            + if drawer {
                i as f32 * (height + gap)
            } else {
                0.
            };
        let right = m
            .handles
            .get(i as usize)
            .and_then(|h| h.hinge_right)
            .unwrap_or(i % 2 == 1);
        let opened = m.door_open || m.handles.get(i as usize).map(|h| h.open).unwrap_or(false);
        let z = m.z_mm as f32
            - if drawer && opened {
                m.depth_mm as f32 * 0.65
            } else {
                0.
            };
        let t = m.thickness_mm as f32;
        let angle = if opened && !drawer {
            if !right {
                -95.
            } else {
                95.
            }
        } else {
            0.
        };
        let pivot = if !right { x } else { x + width };
        let style = m
            .door_styles
            .get(i as usize)
            .copied()
            .unwrap_or(m.door_style);
        let base = material_color_for(&m.door_material, materials);
        let start = faces.len();
        let mut box_ =
            |a: V3, b: V3, c: Color32| append_module_box(faces, camera, m, a, b, c, angle, pivot);
        match style {
            DoorStyle::Provincial => {
                let rail = 55.0_f32.min(width / 4.).min(height / 4.);
                box_(V3::new(x, y, z - t), V3::new(x + rail, y + height, z), base);
                box_(
                    V3::new(x + width - rail, y, z - t),
                    V3::new(x + width, y + height, z),
                    base,
                );
                for yy in [y, y + height - rail] {
                    box_(
                        V3::new(x + rail, yy, z - t),
                        V3::new(x + width - rail, yy + rail, z),
                        base,
                    );
                }
                box_(
                    V3::new(x + rail, y + rail, z - t + 6.),
                    V3::new(x + width - rail, y + height - rail, z - 2.),
                    Color32::from_rgb(
                        (base.r() as f32 * 0.84) as u8,
                        (base.g() as f32 * 0.84) as u8,
                        (base.b() as f32 * 0.84) as u8,
                    ),
                );
            }
            DoorStyle::Glass
            | DoorStyle::Aluminum
            | DoorStyle::GlassHorizontal
            | DoorStyle::GlassVertical => {
                let frame = if style == DoorStyle::Aluminum {
                    Color32::from_rgb(159, 164, 170)
                } else {
                    base
                };
                let rail = if style == DoorStyle::Aluminum {
                    22.
                } else {
                    45.
                };
                for xx in [x, x + width - rail] {
                    box_(
                        V3::new(xx, y, z - t),
                        V3::new(xx + rail, y + height, z),
                        frame,
                    );
                }
                for yy in [y, y + height - rail] {
                    box_(
                        V3::new(x + rail, yy, z - t),
                        V3::new(x + width - rail, yy + rail, z),
                        frame,
                    );
                }
                if style == DoorStyle::GlassHorizontal {
                    let yy = y + height / 2.;
                    box_(
                        V3::new(x + rail, yy - 10., z - t),
                        V3::new(x + width - rail, yy + 10., z),
                        frame,
                    );
                }
                if style == DoorStyle::GlassVertical {
                    let xx = x + width / 2.;
                    box_(
                        V3::new(xx - 10., y + rail, z - t),
                        V3::new(xx + 10., y + height - rail, z),
                        frame,
                    );
                }
                let glass = if m.door_material.to_lowercase().contains("vidro") {
                    base
                } else {
                    Color32::from_rgb(170, 210, 222)
                };
                box_(
                    V3::new(x + rail, y + rail, z - 6.),
                    V3::new(x + width - rail, y + height - rail, z - 2.),
                    Color32::from_rgba_unmultiplied(glass.r(), glass.g(), glass.b(), 70),
                );
            }
            _ => {
                box_(
                    V3::new(x, y, z - t),
                    V3::new(x + width, y + height, z),
                    base,
                );
            }
        }
        drop(box_);
        if !matches!(
            style,
            DoorStyle::Glass
                | DoorStyle::Aluminum
                | DoorStyle::GlassHorizontal
                | DoorStyle::GlassVertical
        ) {
            visual::mark(&mut faces[start..], &m.door_material, materials, m.grain);
        }
        let metal = Color32::from_rgb(125, 131, 137);
        if matches!(style, DoorStyle::Cava | DoorStyle::Horizontal) {
            append_module_box(
                faces,
                camera,
                m,
                V3::new(x + 5., y + height - 20., z - t - 4.),
                V3::new(x + width - 5., y + height - 7., z - t),
                if style == DoorStyle::Cava {
                    Color32::from_rgb(42, 39, 34)
                } else {
                    metal
                },
                angle,
                pivot,
            );
        } else if style == DoorStyle::Vertical {
            append_module_box(
                faces,
                camera,
                m,
                V3::new(x + width - 18., y + 5., z - t - 4.),
                V3::new(x + width - 5., y + height - 5., z - t),
                metal,
                angle,
                pivot,
            );
        } else {
            let default = Handle {
                position: if drawer {
                    4
                } else if i % 2 == 0 {
                    5
                } else {
                    3
                },
                vertical: !drawer,
                ..Handle::default()
            };
            let h = m.handles.get(i as usize).unwrap_or(&default);
            if h.enabled {
                let inset = (h.inset as f32).min(width / 2.).min(height / 2.);
                let len = (h.length as f32)
                    .min(if h.vertical {
                        height - 2. * inset
                    } else {
                        width - 2. * inset
                    })
                    .max(5.);
                let col = h.position % 3;
                let row = h.position / 3;
                let cx = x + match col {
                    0 => inset,
                    1 => width / 2.,
                    _ => width - inset,
                };
                let cy = y + match row {
                    0 => height - inset,
                    1 => height / 2.,
                    _ => inset,
                };
                let (hw, hh) = if h.vertical {
                    (5., len / 2.)
                } else {
                    (len / 2., 5.)
                };
                let cx = cx.clamp(x + hw + 3., x + width - hw - 3.);
                let cy = cy.clamp(y + hh + 3., y + height - hh - 3.);
                append_module_box(
                    faces,
                    camera,
                    m,
                    V3::new(cx - hw, cy - hh, z - t - 30.),
                    V3::new(cx + hw, cy + hh, z - t - 20.),
                    metal,
                    angle,
                    pivot,
                );
            }
        }
    }
}

pub fn default_handle(m: &Module, i: usize) -> Handle {
    let drawer = m.kind == ModuleKind::Drawer;
    Handle {
        position: if drawer {
            4
        } else if i % 2 == 0 {
            5
        } else {
            3
        },
        vertical: !drawer,
        ..Handle::default()
    }
}
