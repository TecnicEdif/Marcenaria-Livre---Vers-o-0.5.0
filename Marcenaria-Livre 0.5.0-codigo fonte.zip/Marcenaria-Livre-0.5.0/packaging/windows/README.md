# Windows — fonte de portabilidade

Execute `packaging/windows/build.ps1` em uma máquina Windows com Rust MSVC e Visual Studio Build Tools. O script cria um ZIP com o executável somente se a compilação local tiver sucesso.

Esta configuração não foi executada nem validada em Windows. Os diálogos de arquivo ainda usam Zenity (Linux) e devem ser adaptados para um seletor nativo. Não há instalador Windows, assinatura digital ou garantia de paridade funcional nesta entrega. O código principal e os recursos gráficos estão em `src` e `assets`.
