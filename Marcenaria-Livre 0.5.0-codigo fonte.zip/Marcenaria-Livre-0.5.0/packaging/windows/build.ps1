# Execute on Windows with Rust MSVC and Visual Studio Build Tools installed.
$ErrorActionPreference = 'Stop'
Push-Location (Join-Path $PSScriptRoot '../..')
try {
    cargo build --locked --release
    if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
    New-Item -ItemType Directory -Force -Path dist/windows | Out-Null
    Copy-Item target/release/marcenaria-livre.exe dist/windows/
    Copy-Item LICENSE dist/windows/
    Copy-Item packaging/windows/README.md dist/windows/
    Compress-Archive -Path dist/windows/* -DestinationPath dist/Marcenaria-Livre-Windows.zip -Force
} finally { Pop-Location }
