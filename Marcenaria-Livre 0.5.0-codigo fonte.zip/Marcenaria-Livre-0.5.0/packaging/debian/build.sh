#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
cargo build --release
TARGET_DIR=${CARGO_TARGET_DIR:-"$ROOT/target"}
mkdir -p "$ROOT/dist"
PKG="$ROOT/work/debian-package"
install -d "$PKG/DEBIAN" "$PKG/usr/bin" "$PKG/usr/share/applications" "$PKG/usr/share/icons/hicolor/512x512/apps"
install -m 0644 packaging/debian/control "$PKG/DEBIAN/control"
install -m 0755 "$TARGET_DIR/release/marcenaria-livre" "$PKG/usr/bin/marcenaria-livre"
install -m 0644 packaging/debian/marcenaria-livre.desktop "$PKG/usr/share/applications/marcenaria-livre.desktop"
install -m 0644 assets/logo.png "$PKG/usr/share/icons/hicolor/512x512/apps/marcenaria-livre-logo.png"
install -d "$PKG/usr/share/doc/marcenaria-livre"
install -m 0644 LICENSE "$PKG/usr/share/doc/marcenaria-livre/copyright"
dpkg-deb --root-owner-group --build "$PKG" "$ROOT/dist/marcenaria-livre_0.5.0_amd64.deb"
