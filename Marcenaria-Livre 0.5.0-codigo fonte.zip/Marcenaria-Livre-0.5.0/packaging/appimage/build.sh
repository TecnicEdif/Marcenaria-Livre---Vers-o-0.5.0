#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
cargo build --release
TARGET_DIR=${CARGO_TARGET_DIR:-"$ROOT/target"}
APPDIR="$TARGET_DIR/MarcenariaLivre.AppDir"
mkdir -p "$APPDIR/usr/bin" "$APPDIR/usr/share/applications" "$APPDIR/usr/share/icons/hicolor/512x512/apps" "$ROOT/dist"
install -m 0755 "$TARGET_DIR/release/marcenaria-livre" "$APPDIR/usr/bin/marcenaria-livre"
install -m 0644 packaging/appimage/marcenaria-livre.desktop "$APPDIR/usr/share/applications/marcenaria-livre.desktop"
install -m 0644 packaging/appimage/marcenaria-livre.desktop "$APPDIR/marcenaria-livre.desktop"
install -m 0644 assets/logo.png "$APPDIR/marcenaria-livre-logo.png"
install -m 0644 assets/logo.png "$APPDIR/usr/share/icons/hicolor/512x512/apps/marcenaria-livre-logo.png"
install -m 0755 packaging/appimage/AppRun "$APPDIR/AppRun"
ln -sfn marcenaria-livre-logo.png "$APPDIR/.DirIcon"
install -d "$APPDIR/usr/share/doc/marcenaria-livre"
install -m 0644 LICENSE "$APPDIR/usr/share/doc/marcenaria-livre/LICENSE"
TOOL=${APPIMAGETOOL:-appimagetool}
if case "$TOOL" in *.AppImage) true;; *) false;; esac; then
  if [ -n "${APPIMAGE_RUNTIME:-}" ]; then
    ARCH=x86_64 "$TOOL" --appimage-extract-and-run --runtime-file "$APPIMAGE_RUNTIME" "$APPDIR" "$ROOT/dist/Marcenaria-Livre-x86_64.AppImage"
  else
    ARCH=x86_64 "$TOOL" --appimage-extract-and-run "$APPDIR" "$ROOT/dist/Marcenaria-Livre-x86_64.AppImage"
  fi
else
  if [ -n "${APPIMAGE_RUNTIME:-}" ]; then
    ARCH=x86_64 "$TOOL" --runtime-file "$APPIMAGE_RUNTIME" "$APPDIR" "$ROOT/dist/Marcenaria-Livre-x86_64.AppImage"
  else
    ARCH=x86_64 "$TOOL" "$APPDIR" "$ROOT/dist/Marcenaria-Livre-x86_64.AppImage"
  fi
fi
