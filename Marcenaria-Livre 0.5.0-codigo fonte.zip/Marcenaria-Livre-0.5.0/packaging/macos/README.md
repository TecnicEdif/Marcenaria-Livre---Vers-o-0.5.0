# macOS — fonte de portabilidade

O script `build.sh` compila o mesmo código Rust no próprio macOS e organiza um pacote `.app` em ZIP. Exige Rust e Xcode Command Line Tools. Não executado nem testado nesta entrega. Não inclui assinatura, notarização, ícone ICNS nem adaptação dos seletores de arquivo Linux. Esses trabalhos ficam documentados para contribuição da comunidade.
