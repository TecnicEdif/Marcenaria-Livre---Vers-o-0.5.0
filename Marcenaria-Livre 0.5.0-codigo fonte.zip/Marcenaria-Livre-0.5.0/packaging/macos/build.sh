#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
case "$(uname -s)" in Darwin) ;; *) echo 'Execute este script no macOS.' >&2; exit 1;; esac
cargo build --locked --release
APP='dist/Marcenaria Livre.app'
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp target/release/marcenaria-livre "$APP/Contents/MacOS/"
cp assets/logo.png LICENSE "$APP/Contents/Resources/"
cp packaging/macos/Info.plist "$APP/Contents/Info.plist"
ditto -c -k --sequesterRsrc --keepParent "$APP" dist/Marcenaria-Livre-macOS.zip
